"""Checks for piece4.  python3 checks_piece4.py   |   --selftest"""
import json
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

import checks
import checks3
import checks_piece1 as c1
import checks_piece2 as c2
import checks_piece3 as c3
import dsp
import piece4 as P
from study4 import BEAT, BAR, HZ, tb

c1.P = P


def lvl(x, sr, a, b):
    return 10 * np.log10((x[int(a * sr):int(b * sr)] ** 2).mean() + 1e-20)


def engine_early(st):
    """Mark: the engine should be prominent well before 1:10. By bars 19-20
    (0:35-0:39) it is within 6 dB of its level in the solo (bars 33-44)."""
    sr = int(st['sr'])
    x = (st['droneL'] + st['droneR']) / 2
    d = lvl(x, sr, tb(19), tb(21)) - lvl(x, sr, tb(33), tb(45))
    return d >= -6, f'bars 19-20 at {d:+.1f} dB of the solo (starts {tb(19):.0f} s)'


def seam(st):
    """Mark's seam: after the solo it goes quieter, then builds. Bars 49-50:
    the plucks alone (no doots, no engine; plucks present); bars 51-52: the
    doots arrive, still no engine; bars 53-55: the engine wakes."""
    sr = int(st['sr'])
    e = (st['droneL'] + st['droneR']) / 2
    dl = lambda a, b: lvl(st['doots'], sr, tb(a), tb(b))
    el = lambda a, b: lvl(e, sr, tb(a), tb(b))
    ref_d, ref_e = dl(57, 61), el(33, 45)
    ks = lvl(st['ks'], sr, tb(49), tb(51))
    ok = (dl(49, 51) < ref_d - 30 and el(49.3, 53) < ref_e - 30 and ks > -80
          and dl(51, 53) > ref_d - 25 and el(54, 56) > ref_e - 15)
    return ok, (f'49-50: doots {dl(49, 51) - ref_d:+.0f} dB, engine {el(49.3, 53) - ref_e:+.0f} dB, plucks {ks:.0f} dBFS; '
                f'51-52 doots {dl(51, 53) - ref_d:+.0f}; 54-55 engine {el(54, 56) - ref_e:+.0f} dB')


def no_wall(mix, sr):
    """Mark: the doots' return should start with one note, not a wall. The mix
    rises no more than 2 dB per beat over bar 51's first two beats, relative
    to the plucks alone (bars 49-50). (v4.1 rose 5 dB in a beat and a half.)"""
    m = mix.mean(1)
    lv = lambda a, b: 10 * np.log10((m[int(a * sr):int(b * sr)] ** 2).mean() + 1e-20)
    base = lv(tb(49), tb(51))
    r = [lv(tb(51, k), tb(51, k + 1)) - base for k in range(4)]
    return max(r[:2]) <= 2.0, f'bar 51 per beat vs plucks alone: {np.round(r, 1)} dB'


def build(st):
    """The mechanism under 'no wall': the doots placed in bars 51-52, counted
    per half-bar from the dry stem (an onset is a 16th step whose next 40 ms
    are 6 dB above its last 40 ms). Planned: 1, 1, 2, 3, then 6 in bar 53.
    (v4.2's build asked for steps its bars didn't have and played 0, 0, 1, 0.)"""
    sr = int(st['sr'])
    x = st['doots'] ** 2
    e = lambda a, b: x[int(a * sr):int(b * sr)].mean() + 1e-20
    cnt = []
    for bar in (51, 52, 53):
        for half in (0, 1):
            n = 0
            for i in range(8 * half, 8 * half + 8):
                t = tb(bar) + i * BEAT / 4
                n += 10 * np.log10(e(t, t + 0.04) / e(t - 0.04, t)) > 6
            cnt.append(n)
    want = [1, 1, 2, 3]
    return cnt[:4] == want and sum(cnt[4:]) == 6, f'onsets per half-bar, bars 51-53: {cnt} (want {want} then 6)'


def chops(st):
    """The chopper gates: in every chop, the engine's closed parts sit >= 15 dB
    under its open parts (cells with < 12 ms open or closed skipped)."""
    sr = int(st['sr'])
    x = (st['droneL'] ** 2 + st['droneR'] ** 2) / 2
    ds = []
    for bar, beats, per, d0, d1, pat in P.CHOPS:
        a0, a1 = tb(bar), tb(bar) + beats * BEAT
        op, cl = [], []
        for a, o, e in P.chop_cells():
            if not (a0 <= a < a1):
                continue
            if o - a >= 0.012:
                op.append(x[int((a + 0.004) * sr):int((o - 0.004) * sr)].mean())
            if e - o >= 0.012:
                cl.append(x[int((o + 0.004) * sr):int((e - 0.004) * sr)].mean())
        ds.append(10 * np.log10(np.mean(op) / max(np.mean(cl), 1e-20)))
    return min(ds) >= 15, f'open/closed per chop {np.round(ds, 1)} dB'


def shares(mix, sr, a, b):
    m = mix.mean(1)[int(a * sr):int(b * sr)]
    f, S = signal.welch(m, sr, nperseg=8192)
    tot = S[(f > 30) & (f < 16000)].sum()
    sh = lambda lo, hi: 10 * np.log10(S[(f > lo) & (f < hi)].sum() / tot)
    return sh(120, 300), sh(2500, 6000)


def not_muddy(mix, sr):
    """Argon's mud, as measured against the references: the 120-300 Hz share
    of the total, the references' -8.4..-12.3 dB; ours <= -8.4 in the groove and climax."""
    a = shares(mix, sr, tb(9), tb(17))[0]
    b = shares(mix, sr, tb(61), tb(81))[0]
    return max(a, b) <= -8.4, f'120-300 Hz share: groove {a:.1f}, climax {b:.1f} dB'


def not_harsh(mix, sr):
    """Argon's harshness, measured: the 2.5-6 kHz share in the climax within
    2 dB of the references' brightest passage (-22 dB), i.e. <= -20."""
    h = shares(mix, sr, tb(61), tb(81))[1]
    return h <= -20, f'2.5-6 kHz share in the climax {h:.1f} dB (piece 3: -15.9)'


def balance(mix, sr):
    out, ok = [], True
    for a, b in ((9, 17), (61, 81)):
        m = mix.mean(1)[int(tb(a) * sr):int(tb(b) * sr)]
        f, S = signal.welch(m, sr, nperseg=8192)
        lo = 10 * np.log10(S[(f > 30) & (f < 120)].sum() / S[(f > 200) & (f < 4000)].sum())
        hi = 10 * np.log10(S[(f > 4000) & (f < 16000)].sum() / S[(f > 200) & (f < 4000)].sum())
        ok &= 7.0 <= lo <= 14.5 and -16.0 <= hi <= -6.8
        out.append(f'bars {a}-{b - 1}: low/mid {lo:+.1f}, high/mid {hi:+.1f}')
    return ok, '; '.join(out)


def plucks(st):
    sr, x = int(st['sr']), st['ks']
    errs = []
    for bar, beat, m in P.KS_NOTES:
        t = tb(bar, beat) + 0.05
        seg = x[int(t * sr):int((t + 0.5) * sr)]
        X = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), 1 << 20))
        f = np.fft.rfftfreq(1 << 20, 1 / sr)
        k = (f > HZ(m) * 2 ** -0.05) & (f < HZ(m) * 2 ** 0.05)
        errs.append(abs(1200 * np.log2(f[k][np.argmax(X[k])] / HZ(m))))
    return max(errs) <= 3, f'{len(errs)} plucks, worst {max(errs):.1f} c'


def run(stem):
    sr, mix = wavfile.read(stem + '.wav')
    mix = mix.astype(np.float64)
    st = np.load(stem + '_stems.npz')
    sc = json.load(open(stem + '_score.json'))
    kb = [tb(b) for b in P.KICK]
    kp = np.concatenate([mix[int(t * sr):int((t + BAR) * sr)] for t in kb])
    c = checks3.crest(kp, sr)
    L = dsp.lufs(mix, sr)
    res = [('engine early', *engine_early(st)), ('the seam', *seam(st)), ('no wall', *no_wall(mix, sr)), ('the build', *build(st)), ('chopper gates', *chops(st)),
           ('not muddy', *not_muddy(mix, sr)), ('not harsh', *not_harsh(mix, sr)), ('balance vs refs', *balance(mix, sr)),
           ('plucks in tune', *plucks(st)), ('clap short', *c2.clap_short(st, sc)),
           ('kick on the grid', *checks.kick_sync(st, sc)), ('claps on 2 and 4', *c1.claps_on_grid(st, sc)),
           ('bass line in tune', *c1.bass_pitch(st)),
           ('punch (kick bars)', c >= 8, f'{c:.1f} dB'), ('loudness', abs(L + 10) <= 0.6, f'{L:.2f} LUFS')]
    res += [r for r in checks.levels(mix, sr) if r[0] != 'loudness']
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    return {n: ok for n, ok, _ in res}


def render(brk=None):
    subprocess.check_call(['systemd-run', '--user', '--scope', '-q', '-p', 'MemoryMax=10G', '-p', 'MemorySwapMax=0',
                           sys.executable, 'piece4.py'] + (['--break', brk] if brk else []), stdout=subprocess.DEVNULL)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        for brk, which in (('no-chop', 'chopper gates'), ('cold-seam', 'the seam'),
                           ('muddy', 'not muddy'), ('harsh', 'not harsh'), ('wall', 'no wall'), ('old-build', 'the build')):
            render(brk)
            r = run(f'out/piece4_BROKEN-{brk}')
            print(f'== {brk}: {which}', 'caught' if not r[which] else 'NOT CAUGHT')
    else:
        r = run('out/piece4')
        print('ALL PASS' if all(r.values()) else 'SOME FAIL: ' + ', '.join(k for k, v in r.items() if not v))
