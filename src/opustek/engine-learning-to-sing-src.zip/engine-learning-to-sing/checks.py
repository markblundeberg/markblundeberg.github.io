"""Checks for a render, written before the render. Each must be seen to fail:
  python3 checks.py out/study1                 check a render
  python3 checks.py --selftest                 render each --break and expect a FAIL
"""
import json
import subprocess
import sys

import numpy as np
from scipy.io import wavfile

import dsp
import study1

LUFS_TARGET, LUFS_TOL = -10.5, 0.6
TP_MAX = -1.0


def sung_harmonics(st, score):
    """Each held sung note: the strongest partial in the singer stem must be
    harmonic n of the drone at that moment, within 15 cents, and stand at
    least 15 dB above its neighbours n-1 and n+1."""
    sr, x, tc, f0 = int(st['sr']), st['sing'], st['tc'], st['f0']
    bad, checked, skipped = [], 0, 0
    for e in score['sung']:
        a, b = e['hold']
        # find a 0.3 s window inside the hold where the drone is steady
        best = None
        for s in np.arange(a, b - 0.3, 0.05):
            m = (tc >= s) & (tc < s + 0.3)
            if m.sum() and np.ptp(np.log(f0[m])) < np.log(2 ** (2 / 1200)):
                best = s
                break
        if best is None:
            skipped += 1
            continue
        checked += 1
        f = float(np.mean(f0[(tc >= best) & (tc < best + 0.3)]))
        seg = x[int(best * sr):int((best + 0.3) * sr)]
        nf = 1 << 17
        X = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), nf))
        fr = np.fft.rfftfreq(nf, 1 / sr)
        n = e['n']
        lo, hi = (n - 1.5) * f, (n + 1.5) * f
        band = (fr > lo) & (fr < hi)
        i = np.argmax(np.where(band, X, 0))
        # parabolic interpolation of the peak
        y0, y1, y2 = np.log(X[i - 1:i + 2] + 1e-20)
        d = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2)
        fp = fr[i] + d * (fr[1] - fr[0])
        n_obs = fp / f
        cents = 1200 * np.log2(fp / (n * f))
        lev = lambda h: 20 * np.log10(X[np.argmin(np.abs(fr - h * f))] + 1e-20)
        prom = lev(n) - max(lev(n - 1), lev(n + 1))
        if round(n_obs) != n or abs(cents) > 15 or prom < 15:
            bad.append(f"t={e['t']:.2f} n={n}: heard {n_obs:.2f}, {cents:+.0f} c, {prom:.0f} dB above neighbours")
    ok = not bad and checked >= 0.6 * len(score['sung'])
    msg = f'{checked} notes checked, {skipped} skipped (drone moving)'
    return ok, msg + ('' if not bad else '; ' + '; '.join(bad[:4]))


def kick_sync(st, score):
    """Every scheduled kick starts within 2 ms of its grid time."""
    sr, x = int(st['sr']), np.abs(st['kick'])
    errs = []
    for t in score['kicks']:
        i0, i1 = max(0, int((t - 0.02) * sr)), int((t + 0.04) * sr)
        seg = x[i0:i1]
        j = np.argmax(seg > 0.3 * seg.max())
        errs.append((i0 + j) / sr - t)
    errs = np.array(errs) * 1000
    return np.all(np.abs(errs) < 2.0), f'{len(errs)} kicks, onset error {errs.min():+.2f} to {errs.max():+.2f} ms'


def levels(mix, sr):
    out = []
    l = dsp.lufs(mix, sr)
    out.append(('loudness', abs(l - LUFS_TARGET) <= LUFS_TOL, f'{l:.2f} LUFS (target {LUFS_TARGET} +/- {LUFS_TOL})'))
    tp = dsp.true_peak_db(mix)
    out.append(('true peak', tp <= TP_MAX, f'{tp:.2f} dBTP (max {TP_MAX})'))
    nan = not np.all(np.isfinite(mix))
    dc = float(np.abs(mix.mean(axis=0)).max())
    out.append(('finite, no DC', (not nan) and dc < 1e-3, f'nan={nan}, dc={dc:.1e}'))
    return out


def aliasing(brk=None):
    """The drone chain's off-harmonic energy (1-16 kHz) stays below -40 dB."""
    x, f = study1.drone_probe(brk)
    sr = study1.SR
    x = x[sr // 2:]
    X = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
    fr = np.fft.rfftfreq(len(x), 1 / sr)
    band = (fr > 1000) & (fr < 16000)
    k = fr / f
    near = np.abs(k - np.round(k)) * f < 4
    r = 10 * np.log10(X[band & ~near].sum() / X[band].sum())
    return r < -40, f'off-harmonic energy {r:.1f} dB'


def run(stem, brk=None):
    sr, mix = wavfile.read(stem + '.wav')
    st = np.load(stem + '_stems.npz')
    score = json.load(open(stem + '_score.json'))
    res = [('sung harmonics', *sung_harmonics(st, score)),
           ('kick on the grid', *kick_sync(st, score))]
    res += levels(mix.astype(np.float64), sr)
    res.append(('drone aliasing', *aliasing(brk)))
    for name, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {name}: {msg}")
    return all(ok for _, ok, _ in res), {n: ok for n, ok, _ in res}


EXPECT = {'wrong-harmonic': 'sung harmonics', 'wide-formant': 'sung harmonics',
          'late-kick': 'kick on the grid', 'naive-saw': 'drone aliasing', 'clip': 'true peak'}

if __name__ == '__main__':
    if sys.argv[1] == '--selftest':
        allgood = True
        for brk, which in EXPECT.items():
            print(f'== break: {brk} (expect {which} to FAIL)')
            subprocess.check_call([sys.executable, 'study1.py', '--break', brk], stdout=subprocess.DEVNULL)
            _, r = run(f'out/study1_BROKEN-{brk}', brk)
            caught = not r[which]
            allgood &= caught
            print('  ->', 'caught' if caught else 'NOT CAUGHT')
        print('selftest', 'OK' if allgood else 'FAILED')
    else:
        ok, _ = run(sys.argv[1])
        print('ALL PASS' if ok else 'SOME FAIL')
