"""Checks for piece3.  python3 checks_piece3.py   |   --selftest"""
import json
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

import checks_piece1 as c1
import checks_piece2 as c2
import piece3 as P
from study4 import BEAT, BAR, HZ, tb

c1.P = P


def repetition(doots, sr):
    """How much the doots repeat: mean correlation between each bar's
    envelope and the bar four later (bars 17-60 and 73-92)."""
    e = signal.resample_poly(np.abs(signal.hilbert(doots)), 1, 480)       # 100 Hz
    nb = int(BAR * 100)
    cs = []
    for b in list(range(17, 61)) + list(range(73, 93)):
        x = e[int(tb(b) * 100):int(tb(b) * 100) + nb]
        y = e[int(tb(b + 4) * 100):int(tb(b + 4) * 100) + nb]
        if x.std() > 1e-6 and y.std() > 1e-6:
            cs.append(np.corrcoef(x, y)[0, 1])
    return float(np.mean(cs))


def varied(st):
    """The doots repeat clearly less than piece 2's (whose bars repeat
    exactly): mean 4-bar-lag correlation at least 0.1 lower."""
    r3 = repetition(st['doots'], int(st['sr']))
    r2 = repetition(np.load('out/piece2_stems.npz')['doots'], int(st['sr']))
    return r3 <= r2 - 0.1, f'repetition {r3:.2f} (piece 2: {r2:.2f})'


def ks_tuned(st):
    """Every metal pluck within 3 cents of its note (Argon's trap: an integer
    delay puts them up to 12 cents off)."""
    sr, x = int(st['sr']), st['ks']
    errs = []
    for bar, beat, m in P.KS_NOTES:
        t = tb(bar, beat) + 0.05
        seg = x[int(t * sr):int((t + 0.5) * sr)]
        X = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), 1 << 20))
        f = np.fft.rfftfreq(1 << 20, 1 / sr)
        want = HZ(m)
        k = (f > want * 2 ** (-0.05)) & (f < want * 2 ** 0.05)
        fp = f[k][np.argmax(X[k])]
        errs.append(1200 * np.log2(fp / want))
    errs = np.abs(errs)
    return errs.max() <= 3, f'{len(errs)} plucks, worst {errs.max():.1f} c, median {np.median(errs):.1f} c'


def centroid(x, sr, a, b):
    f, S = signal.welch(x[int(a * sr):int(b * sr)], sr, nperseg=4096)
    k = (f > 100) & (f < 10000)
    return (f[k] * S[k]).sum() / S[k].sum()


def climax_sizzles(st):
    """The engine in the climax (bars 81-96) is at least 1.3x brighter than piece 2's."""
    sr = int(st['sr'])
    x = (st['droneL'] + st['droneR']) / 2
    p2 = np.load('out/piece2_stems.npz')
    y = (p2['droneL'] + p2['droneR']) / 2
    a, b = tb(81), tb(97)
    c3, c2_ = centroid(x, sr, a, b), centroid(y, sr, a, b)
    return c3 >= 1.3 * c2_, f'engine centroid {c3:.0f} Hz (piece 2: {c2_:.0f} Hz, x{c3 / c2_:.2f})'


def balance(mix, sr):
    """Kick vs mids and hats vs mids within the references' range, measured
    section by section (20 s windows over both whole tracks, full-texture
    sections): low/mid +7..+14.5 dB, high/mid -16..-6.8 dB. Piece 2's check
    used three average windows (+9.9..+12.9, -10.9..-15.8), which excluded the
    references' own brightest passages (-7.1 and -6.8)."""
    out, ok = [], True
    for a, b in ((21, 33), (77, 97)):
        m = mix.mean(1)[int(tb(a) * sr):int(tb(b) * sr)]
        f, S = signal.welch(m, sr, nperseg=8192)
        lo = 10 * np.log10(S[(f > 30) & (f < 120)].sum() / S[(f > 200) & (f < 4000)].sum())
        hi = 10 * np.log10(S[(f > 4000) & (f < 16000)].sum() / S[(f > 200) & (f < 4000)].sum())
        ok &= 7.0 <= lo <= 14.5 and -16.0 <= hi <= -6.8
        out.append(f'bars {a}-{b - 1}: low/mid {lo:+.1f}, high/mid {hi:+.1f}')
    return ok, '; '.join(out)


def sings(st, tw):
    """Against the no-sync twin: the sync voice lifts the engine's
    energy-weighted harmonic number by >= 2 on average (solo and climax), and
    tracks its ratio (r >= 0.35) in the solo, where it is exposed. In the
    last climax bars the grit and the warm tube smear the peak (r ~0.2);
    that's the price of the sick part, not a fault."""
    sr = int(st['sr'])
    x, y = (st['droneL'] + st['droneR']) / 2, (tw['droneL'] + tw['droneR']) / 2
    tc, f0, ratio = st['tc'], tw['f0'], st['ratio']
    res = {}
    for name, bars in (('solo', range(49, 65)), ('climax', range(73, 97))):
        d, r = [], []
        for b in bars:
            for k in (0, 2):
                a = tb(b, k) + 0.1
                m = (tc >= a) & (tc < a + 0.3)
                if np.ptp(np.log(f0[m])) > 0.01:
                    continue
                fz = float(f0[m].mean())
                hn = []
                for z in (x, y):
                    seg = z[int(a * sr):int((a + 0.3) * sr)]
                    X = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), 1 << 15)) ** 2
                    fr = np.fft.rfftfreq(1 << 15, 1 / sr)
                    e = np.array([X[np.argmin(np.abs(fr - h * fz))] for h in range(1, 41)])
                    hn.append((np.arange(1, 41) * e).sum() / e.sum())
                d.append(hn[0] - hn[1])
                r.append(float(ratio[m].mean()))
        rr = np.corrcoef(d, r)[0, 1] if np.std(d) > 1e-6 else 0.0
        res[name] = (float(np.mean(d)), rr)
    ok = all(v[0] >= 2 for v in res.values()) and res['solo'][1] >= 0.35
    return ok, '; '.join(f'{k}: shift {v[0]:+.2f} harmonics, r = {v[1]:.2f}' for k, v in res.items())


def run(stem):
    sr, mix = wavfile.read(stem + '.wav')
    mix = mix.astype(np.float64)
    st = np.load(stem + '_stems.npz')
    sc = json.load(open(stem + '_score.json'))
    res = [('backing varied', *varied(st)), ('plucks in tune', *ks_tuned(st)), ('climax sizzles', *climax_sizzles(st)),
           ('balance vs refs', *balance(mix, sr)), ('engine steady', *c2.steady(st)),
           ('sync sings', *sings(st, np.load('out/piece3_BROKEN-no-sync_stems.npz'))),
           ('clap short', *c2.clap_short(st, sc))]
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    print(' -- from piece 1:')
    r1 = c1.run(stem, twin='out/piece3_BROKEN-no-decor')
    r1.pop('flips', None)          # no flips any more
    return {**{n: ok for n, ok, _ in res}, **r1}


def render(brk=None):
    subprocess.check_call(['systemd-run', '--user', '--scope', '-q', '-p', 'MemoryMax=10G', '-p', 'MemorySwapMax=0',
                           sys.executable, 'piece3.py'] + (['--break', brk] if brk else []), stdout=subprocess.DEVNULL)


if __name__ == '__main__':
    for t in ('no-decor', 'no-sync'):
        render(t)
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        for brk, which, fn in (('static-backing', 'backing varied', varied), ('int-ks', 'plucks in tune', ks_tuned),
                               ('dark-climax', 'climax sizzles', climax_sizzles)):
            render(brk)
            ok, msg = fn(np.load(f'out/piece3_BROKEN-{brk}_stems.npz'))
            print(f'== {brk}: {which}', 'caught' if not ok else 'NOT CAUGHT', '-', msg)
        tw = np.load('out/piece3_BROKEN-no-sync_stems.npz')
        ok, msg = sings(tw, tw)
        print('== no-sync: sync sings', 'caught' if not ok else 'NOT CAUGHT', '-', msg)
    else:
        render()
        r = run('out/piece3')
        print('ALL PASS' if all(r.values()) else 'SOME FAIL: ' + ', '.join(k for k, v in r.items() if not v))
