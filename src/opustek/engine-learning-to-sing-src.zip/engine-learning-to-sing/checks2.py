"""Checks for study 2 renders: python3 checks2.py out/study2_scream
Reuses study 1's grid, level and alias checks; adds a tuning check for the
screaming lead (each held note's fundamental is n x the block's root, within
8 cents (power-weighted centre of the detuned pair)). The talking lead has no pitch of its own, so only levels apply."""
import json
import sys

import numpy as np
from scipy.io import wavfile

import checks
import study2
from study1 import BEAT, DRONE, SING


def lead_in_tune(st):
    sr, x = int(st['sr']), st['lead']
    bad, n_ok = [], 0
    ev = [e for e in study2.lead_events(None)]
    for i, (te, n, ch) in enumerate(ev):
        if n == 0 or i + 1 >= len(ev) or ev[i + 1][0] - te < 0.5:
            continue
        a = te + 0.15
        seg = x[int(a * sr):int((a + 0.3) * sr)]
        nf = 1 << 17
        X = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), nf))
        fr = np.fft.rfftfreq(nf, 1 / sr)
        want = n * DRONE[ch]
        # the pitch the ear fuses: power-weighted centre of the unison pair
        band = (fr > want * 2 ** (-60 / 1200)) & (fr < want * 2 ** (60 / 1200))
        P = X[band] ** 2
        fp = float((fr[band] * P).sum() / P.sum())
        c = 1200 * np.log2(fp / (n * DRONE[ch]))
        if abs(c) > 8:
            bad.append(f't={te:.2f} n={n}: {c:+.0f} c')
        else:
            n_ok += 1
    return not bad, f'{n_ok} held notes in tune' + ('' if not bad else '; off: ' + ', '.join(bad[:4]))


if __name__ == '__main__':
    if sys.argv[1] == '--selftest':   # a lead rendered 30 c flat must fail
        import subprocess
        subprocess.check_call([sys.executable, 'study2.py', '--lead', 'scream', '--break', 'flat-lead'],
                              stdout=subprocess.DEVNULL)
        ok, msg = lead_in_tune(np.load('out/study2_scream_BROKEN-flat-lead_stems.npz'))
        print('flat lead:', msg, '->', 'caught' if not ok else 'NOT CAUGHT')
        sys.exit(0)
    stem = sys.argv[1]
    sr, mix = wavfile.read(stem + '.wav')
    st = np.load(stem + '_stems.npz')
    sc = json.load(open(stem + '_score.json'))
    res = [('kick on the grid', *checks.kick_sync(st, sc))]
    res += checks.levels(mix.astype(np.float64), sr)
    res.append(('drone aliasing', *checks.aliasing()))
    if 'scream' in stem:
        res.append(('lead in tune', *lead_in_tune(st)))
    for name, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {name}: {msg}")
    print('ALL PASS' if all(r[1] for r in res) else 'SOME FAIL')
