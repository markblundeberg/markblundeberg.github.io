"""Study 1: an engine learning to sing.

One drone, a detuned sawtooth revved like a motor, runs the whole piece.
The lead is not another instrument: a narrow resonance moves across the
drone's own harmonics and lets one ring at a time, as an overtone singer's
mouth does. So every sung note is n * f0 for a whole number n.

  python3 study1.py            full render  -> out/study1.wav (+ stems, score)
  python3 study1.py --dry      the same notes with the texture stripped out
  python3 study1.py --break X  deliberately wrong render, to prove a check fails
"""
import argparse
import json
import os
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp

SR = 48000
OS = 2                      # oversampling for the drone and its formant
BPM = 122.0
BEAT = 60.0 / BPM
BAR = 4 * BEAT
NBARS = 32
TAIL = 4.5
DUR = NBARS * BAR + TAIL
N = int(DUR * SR)
CR = 1000                   # control rate (Hz) for slow curves
REV_UP, REV_DOWN = 1.1, 2.0  # seconds for the drone to rev up / fall back

HZ = lambda m: 440.0 * 2 ** ((m - 69) / 12)
t_bar = lambda b: (b - 1) * BAR          # bars are 1-based, like a score

# --- the score ---------------------------------------------------------------
# One chord per four-bar block; the drone revs to a new root with it.
BLOCKS = ['Fsm', 'D', 'A', 'E'] * 2
DRONE = {'Fsm': 55.0, 'D': HZ(38), 'A': 55.0, 'E': HZ(40)}   # A1, D2, A1, E2
PAD = {'Fsm': [54, 57, 61, 64], 'D': [50, 54, 57, 61],
       'A': [57, 61, 64, 71], 'E': [52, 56, 59, 66]}
PLUCK = {'Fsm': [73, 69, 76], 'D': [74, 69, 73], 'A': [76, 73, 71], 'E': [71, 68, 73]}

# Sung line, per block: (beat within the block, harmonic number of the drone).
# Over A1: 6=E4 8=A4 9=B4 10=C#5 12=E5.  Over D2: 6=A4 8=D5 9=E5 10=F#5.
# Over E2: 6=B4 8=E5 9=F#5 10=G#5 12=B5.  n=0 is a breath (the formant fades).
SING = {
    'Fsm': [(0, 8), (3, 9), (4, 10), (7, 9), (8, 8), (11, 6), (12, 8), (15.5, 0)],
    'D':   [(0, 6), (3, 8), (4, 9), (6, 10), (8, 9), (11, 8), (12, 6), (15.5, 0)],
    'A':   [(0, 10), (3, 12), (4, 10), (7, 9), (8, 8), (14, 9), (15.5, 0)],
    'E':   [(0, 8), (3, 9), (4, 10), (6, 9), (8, 8), (11, 6), (12, 8), (15.5, 0)],
}

# Sections (bars, inclusive). Kick out in the intro and the breakdown.
KICK_BARS = list(range(5, 25)) + list(range(29, 33))
HAT_BARS = list(range(7, 25)) + list(range(29, 33))
CLAP_BARS = list(range(13, 25)) + list(range(29, 33))
SING_FROM = 9
PLUCK_BARS = list(range(17, 25)) + list(range(29, 33))


def onepole_lag(target, tau_up, tau_down, rate):
    """First-order lag with different rise and fall times: a motor's inertia."""
    out = np.empty_like(target)
    y = target[0]
    a_up, a_dn = 1 - np.exp(-1 / (tau_up * rate)), 1 - np.exp(-1 / (tau_down * rate))
    for i, x in enumerate(target):
        y += (a_up if x > y else a_dn) * (x - y)
        out[i] = y
    return out


def glides(tc, start, events):
    """Piecewise curve: hold, then ease (smootherstep) to each new target."""
    y = np.full(len(tc), start)
    cur = start
    for ts, target, dur in events:
        u = np.clip((tc - ts) / dur, 0, 1)
        e = u * u * u * (u * (6 * u - 15) + 10)
        m = tc >= ts
        y[m] = cur + (target - cur) * e[m]
        cur = target
    return y


def drift(n, rate, cents, seed, tau=2.0):
    """Slow analog wander, in cents."""
    r = np.random.default_rng(seed).standard_normal(n)
    b, a = signal.butter(1, 1 / (2 * np.pi * tau), fs=rate)
    w = signal.filtfilt(b, a, np.cumsum(r) / np.sqrt(rate))
    w -= w.mean()
    return cents * w / (np.abs(w).max() + 1e-9)


def score(args):
    """Control curves at CR: drone f0, sung harmonic n(t), section levels."""
    nc = int(DUR * CR)
    tc = np.arange(nc) / CR
    # drone: holds, then revs to each block's root with an eased glide that
    # starts a beat early. Rising is quicker than falling, as with a motor.
    revs = []                                   # (start time, log f, seconds)
    for k, ch in enumerate(BLOCKS[1:], start=1):
        a, b = np.log(DRONE[BLOCKS[k - 1]]), np.log(DRONE[ch])
        if a != b:
            revs.append((t_bar(1 + 4 * k) - BEAT, b, REV_UP if b > a else REV_DOWN))
    # idle blips in the intro: a nudge of the throttle on beat 3 of each bar
    for bb in range(1, 5):
        s0 = t_bar(bb) + 2 * BEAT
        revs += [(s0, np.log(55.0 * 2 ** (3 / 12)), 0.18), (s0 + 0.25, np.log(55.0), 0.6)]
    tend = t_bar(NBARS + 1)
    revs += [(tend - BEAT, np.log(55.0), REV_DOWN), (tend + 1.2, np.log(24.0), 2.5)]
    lf0 = glides(tc, np.log(DRONE[BLOCKS[0]]), sorted(revs))
    f0 = np.exp(lf0)

    # sung harmonic number, glided in log-n so the resonance sweeps through
    # the harmonics in between, the overtone singer's flutter
    ntgt = np.zeros(nc)
    events = []
    cur = 8.0
    ampt = np.zeros(nc)
    for k, ch in enumerate(BLOCKS):
        bstart = t_bar(1 + 4 * k)
        for beat, n in SING[ch]:
            te = bstart + beat * BEAT
            if bstart < t_bar(SING_FROM):
                continue
            m = tc >= te
            if n == 0:
                ampt[m] = 0.25
            else:
                cur = float(n)
                ntgt[m] = np.log(cur)
                ampt[m] = 1.0
                events.append({'t': te, 'n': n, 'block': ch})
    ntgt[tc < t_bar(SING_FROM)] = np.log(8.0)
    if args.brk == 'wrong-harmonic':
        ntgt = ntgt + np.log(9 / 8) * (ntgt > 0)   # sing a neighbour instead
    ln = onepole_lag(ntgt, 0.035, 0.035, CR)
    n_t = np.exp(ln)
    amp = onepole_lag(ampt, 0.08, 0.25, CR)
    amp *= np.clip((tc - t_bar(SING_FROM)) / (2 * BAR), 0, 1)   # fade in
    amp *= np.clip(1 - (tc - tend) / 2.5, 0, 1)
    # held-note windows for the check: from glide end to next event
    for i, e in enumerate(events):
        nxt = events[i + 1]['t'] if i + 1 < len(events) else tend
        e['hold'] = [e['t'] + 0.15, nxt - 0.05]
        e['f0_mid'] = float(np.interp(np.mean(e['hold']), tc, f0))
    return tc, f0, n_t, amp, events


def bar_env(tc, bars, ramp=0.0):
    """1 inside the listed bars, 0 outside, optional linear ramps (s)."""
    on = np.zeros_like(tc)
    for b in bars:
        on[(tc >= t_bar(b)) & (tc < t_bar(b + 1))] = 1
    if ramp > 0:
        k = int(ramp * CR)
        on = np.convolve(on, np.ones(k) / k, mode='same')
    return on


def up(ctrl, tc, n, sr):
    return np.interp(np.arange(n) / sr, tc, ctrl)


def kick_hit(sr, dry):
    t = np.arange(int(0.5 * sr)) / sr
    f = 47 + 125 * np.exp(-t / 0.028)
    ph = 2 * np.pi * np.cumsum(f) / sr
    x = np.sin(ph) * np.exp(-t / 0.30) * np.clip(t / 0.001, 0, 1)
    if not dry:
        rng = np.random.default_rng(1)
        click = dsp.butter(rng.standard_normal(len(t)), 2500, sr, 'high') * np.exp(-t / 0.004)
        x = np.tanh(1.8 * (x + 0.18 * click)) / np.tanh(1.8)
    return x


def noise_hit(sr, dur, hp, decay, seed, bp=None):
    t = np.arange(int(dur * sr)) / sr
    r = np.random.default_rng(seed).standard_normal(len(t))
    x = dsp.butter(r, bp, sr, 'band') if bp else dsp.butter(r, hp, sr, 'high')
    return x * np.exp(-t / decay)


def place(dst, hit, times, sr, gain=1.0, shift=0.0):
    for t, g in times:
        i = int(round((t + shift) * sr))
        j = min(len(dst), i + len(hit))
        if 0 <= i < len(dst):
            dst[i:j] += gain * g * hit[:j - i]


def sidechain(times, n, sr, depth, rel=0.16):
    g = np.ones(n)
    t = np.arange(n) / sr
    for tk in times:
        i = int(tk * sr)
        j = min(n, i + int(6 * rel * sr))
        dt = t[i:j] - tk
        g[i:j] = np.minimum(g[i:j], 1 - depth * np.exp(-dt / rel) * np.clip(dt / 0.004, 0, 1))
    return g


def render(args):
    dry = args.dry
    t0 = time.time()
    tc, f0, n_t, sing_amp, events = score(args)
    nos = N * OS
    sro = SR * OS

    # --- drone: unison saws, revved, with drift ------------------------------
    detune = [0.0] if dry else [-7.0, 0.0, 6.0]
    voices = []
    for v, dc in enumerate(detune):
        cents = dc + (0 if dry else drift(len(tc), CR, 3.5, seed=10 + v))
        f = up(f0 * 2 ** (cents / 1200), tc, nos, sro)
        voices.append(dsp.saw(f, sro, phase=0.31 * v, blep=args.brk != 'naive-saw'))
    mono = sum(voices) / len(voices)

    # body: ladder lowpass whose cutoff opens with the sections and the revs
    sect = (300 + 500 * bar_env(tc, range(5, 9), 1.5) + 1100 * bar_env(tc, range(9, 25), 2.0)
            + 300 * bar_env(tc, range(17, 25), 3.0) + 250 * bar_env(tc, range(29, 33), 0.5))
    lfo = 1 + 0.25 * np.sin(2 * np.pi * tc / (8 * BAR))
    cut = sect * (f0 / 55.0) ** 1.4 * (1 if dry else lfo)
    cut *= 1 if dry else 2 ** (drift(len(tc), CR, 80, seed=20) / 1200)
    body = dsp.ladder(mono, up(cut, tc, nos, sro), sro,
                      res=0.0 if dry else 0.42, drive=0.0 if dry else 1.6)
    if not dry:
        # the motor's firing roughness: a little amplitude modulation at f0/2
        ph = 2 * np.pi * np.cumsum(up(f0, tc, nos, sro) / 2) / sro
        body *= 1 + 0.10 * np.sin(ph)
        body = np.tanh(1.3 * body) / np.tanh(1.3)

    # singer: the same drone through two narrow bandpasses at n(t) * f0(t)
    fc = up(n_t * f0, tc, nos, sro)
    q = 6.0 if args.brk == 'wide-formant' else 38.0
    sing = dsp.svf_bp(dsp.svf_bp(mono, fc, sro, q), fc, sro, q)
    sing *= up(sing_amp, tc, nos, sro) * 9.0
    if not dry:
        sing = np.tanh(1.2 * sing) / np.tanh(1.2)

    body = signal.resample_poly(body, 1, OS)[:N]
    sing = signal.resample_poly(sing, 1, OS)[:N]
    drone_on = up(np.clip(tc / 2.0, 0, 1) * np.clip(1 - (tc - t_bar(NBARS + 1) - 1.0) / 2.5, 0, 1), tc, N, SR)
    body *= drone_on

    # --- pad and plucks -------------------------------------------------------
    t = np.arange(N) / SR
    padL, padR = np.zeros(N), np.zeros(N)
    for k, ch in enumerate(BLOCKS):
        s, e = t_bar(1 + 4 * k), t_bar(5 + 4 * k)
        if e <= t_bar(3):
            continue
        i0, i1 = int(max(0, s - 0.3) * SR), min(N, int((e + 2.0) * SR))
        tt = t[i0:i1] - s
        env = np.clip(tt / 0.9, 0, 1) * np.clip(1 - (tt - (e - s)) / 1.6, 0, 1)
        for j, m in enumerate(PAD[ch]):
            for d in ([0.0] if dry else [-9.0, 9.0]):
                f = np.full(len(tt), HZ(m) * 2 ** (d / 1200))
                x = dsp.saw(f, SR, phase=0.17 * j + (d > 0) * 0.5) * env
                pan = 0.5 + (0 if dry else (0.35 if (j + (d > 0)) % 2 else -0.35))
                padL[i0:i1] += x * (1 - pan)
                padR[i0:i1] += x * pan
    pcut = 900 if dry else up(1000 + 400 * np.sin(2 * np.pi * tc / (16 * BAR)), tc, N, SR)
    padL = dsp.ladder(padL, pcut, SR, res=0.1, drive=0.0 if dry else 0.8)
    padR = dsp.ladder(padR, pcut, SR, res=0.1, drive=0.0 if dry else 0.8)
    padg = up(bar_env(tc, range(3, 33), 3.0) * (1 - 0.0 * tc), tc, N, SR) * 0.06
    padL *= padg; padR *= padg

    pluck = np.zeros(N)
    pl_times = []
    for k, ch in enumerate(BLOCKS):
        for b in range(4):
            bar = 1 + 4 * k + b
            if bar not in PLUCK_BARS:
                continue
            for beat, m in zip((0, 1.5, 3.0), PLUCK[ch]):
                pl_times.append((t_bar(bar) + beat * BEAT, m))
    for te, m in pl_times:
        tt = np.arange(int(1.2 * SR)) / SR
        fm = HZ(m)
        idx = 2.2 * np.exp(-tt / 0.12)
        x = np.sin(2 * np.pi * fm * tt + idx * np.sin(2 * np.pi * 2 * fm * tt)) * np.exp(-tt / 0.35)
        place(pluck, x, [(te, 1.0)], SR)
    pluck *= 0.10

    # --- drums ----------------------------------------------------------------
    kicks = [t_bar(b) + i * BEAT for b in KICK_BARS for i in range(4)]
    kick = np.zeros(N)
    shift = 0.015 if args.brk == 'late-kick' else 0.0
    place(kick, kick_hit(SR, dry), [(k, 1.0) for k in kicks], SR, gain=0.85, shift=shift)
    hats = np.zeros(N)
    ohat = noise_hit(SR, 0.25, 7500, 0.055, 2)
    chat = noise_hit(SR, 0.08, 9000, 0.012, 3)
    place(hats, ohat, [(t_bar(b) + (i + 0.5) * BEAT, 1.0) for b in HAT_BARS for i in range(4)], SR, 0.16)
    if not dry:
        place(hats, chat, [(t_bar(b) + i * BEAT / 4, (0.6, 0.25, 0.0, 0.35)[i % 4])
                           for b in range(13, 25) for i in range(16)] +
              [(t_bar(b) + i * BEAT / 4, (0.6, 0.25, 0.0, 0.35)[i % 4])
               for b in range(29, 33) for i in range(16)], SR, 0.09)
    clap = np.zeros(N)
    c1 = noise_hit(SR, 0.3, None, 0.11, 4, bp=(900, 3200))
    burst = np.zeros(int(0.3 * SR))
    for o in (0, 0.009, 0.019):
        burst[int(o * SR):] += c1[:len(burst) - int(o * SR)] * (0.6 if o < 0.019 else 1.0)
    place(clap, burst, [(t_bar(b) + i * BEAT, 1.0) for b in CLAP_BARS for i in (1, 3)], SR, 0.22)

    # --- mix ------------------------------------------------------------------
    if not dry:
        body *= sidechain(kicks, N, SR, 0.55)
        sc_pad = sidechain(kicks, N, SR, 0.6, rel=0.2)
        padL *= sc_pad; padR *= sc_pad
        sing *= sidechain(kicks, N, SR, 0.22)
        pluck *= sidechain(kicks, N, SR, 0.3)
    body *= 0.42
    sing *= 0.30
    L = body + kick + hats * 0.9 + clap + padL + sing * 0.95 + pluck * 0.7
    R = body + kick + hats * 1.1 + clap + padR + sing * 0.95 + pluck * 1.3
    if not dry:
        dL, dR = dsp.pingpong(sing * 0.22 + pluck * 0.5, sing * 0.05, 0.75 * BEAT, SR, fb=0.42)
        sL = sing * 0.30 + padL * 0.8 + pluck * 0.6 + clap * 0.35 + body * 0.05 + dL * 0.5
        sR = sing * 0.30 + padR * 0.8 + pluck * 0.6 + clap * 0.35 + body * 0.05 + dR * 0.5
        rL, rR = dsp.reverb(sL, sR, SR, rt60=4.0, damp_hz=4500)
        L += dL + rL * 0.9
        R += dR + rR * 0.9
        # bus glue: gentle saturation
        L, R = np.tanh(1.1 * L) / 1.1, np.tanh(1.1 * R) / 1.1
    mix = np.stack([L, R], axis=1)
    mix -= mix.mean(axis=0)
    mix = dsp.limiter(mix, SR, ceiling_db=-1.5)
    target = -10.5
    for _ in range(3):   # loudness to target, re-limited after each gain step
        g = 10 ** ((target - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.5)
    print(f'render {time.time() - t0:.1f} s')
    return mix, {'kick': kick, 'sing': sing, 'body': body}, events, kicks, (tc, f0, n_t)


def drone_probe(brk=None, secs=2.0, f=82.407):
    """A steady drone through the real body chain (oversampled saw, ladder,
    tanh, decimation), for the alias check."""
    n, sro = int(secs * SR * OS), SR * OS
    x = dsp.saw(np.full(n, f), sro, blep=brk != 'naive-saw')
    x = dsp.ladder(x, 6000.0, sro, res=0.42, drive=1.6)
    x = np.tanh(1.3 * x) / np.tanh(1.3)
    return signal.resample_poly(x, 1, OS), f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry', action='store_true')
    ap.add_argument('--break', dest='brk', default=None,
                    choices=['wrong-harmonic', 'wide-formant', 'late-kick', 'naive-saw', 'clip'])
    args = ap.parse_args()
    name = 'study1' + ('_dry' if args.dry else '') + (f'_BROKEN-{args.brk}' if args.brk else '')
    mix, stems, events, kicks, (tc, f0, n_t) = render(args)
    if args.brk == 'clip':
        mix = np.clip(mix * 1.6, -1.0, 1.0)
    os.makedirs('out', exist_ok=True)
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, **stems, tc=tc, f0=f0, n_t=n_t)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'sr': SR, 'bpm': BPM, 'kicks': kicks, 'sung': events}, fh, indent=1)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
