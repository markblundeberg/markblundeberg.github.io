# Engine, Learning to Sing

A techno track (3:14) and its film, both made entirely in code by Claude
(Anthropic's Opus 5.5) for Mark Lundeberg, 14-15 October 2026, under the name
Opustek. No samples, no DAW, no plugins, no generative audio or image models:
the sound is numpy and scipy plus 280 lines of C, the film is drawn with
pycairo, and everything that moves in the film is driven by the score that
makes the sound.

More about how it was made: https://marklundeberg.com/opustek/

## Running it

Needs Python 3 with numpy, scipy, pycairo and Pillow; gcc (`dsp.py` compiles
`dsp.c` on first import); ffmpeg; and two fonts, FreeSerif (GNU FreeFont) and
Z003 (URW base35), which most Linux distributions ship. The `--selftest` runs
render each broken version under `systemd-run --user --scope` with a 10 GB
memory cap; on a system without systemd, drop that prefix in `render()`.

    mkdir -p out/video
    python3 piece4.py                       # the track -> out/piece4.wav (+ stems, score)
    python3 checks_piece4.py                # the checks on it
    python3 checks_piece4.py --selftest     # each check against a render broken on purpose
    python3 video/export.py                 # the score's curves and events for the film
    python3 video/film.py --workers 4       # the film -> out/video/film.mp4
    python3 video/check_film.py out/video/film_frames 0

Built with Python 3.12, numpy 1.26, scipy 1.11, pycairo 1.25. The track takes
about 40 s and 4.6 GB of memory to render, and this zip reproduces our
master WAV bit for bit on that setup. The film takes a few minutes with 4
workers (5830 frames, written as PNGs before ffmpeg joins them).

## The files

- `dsp.c`, `dsp.py`: the signal processing, written from scratch: polyBLEP and
  hard-sync saws, a ladder filter with tanh saturation, a state-variable
  bandpass, a phaser, tape and ping-pong delays, an 8-line feedback-delay
  reverb, Karplus-Strong with a fractional delay, a true-peak lookahead
  limiter and BS.1770 loudness.
- `study1.py` ... `study5.py`: five studies, each a single question (the drone,
  how a voice could sing over it, width, an arc, how the engine is played).
- `piece1.py` ... `piece4.py`: the track's four versions. Later ones import
  earlier ones (piece 4 reuses piece 3's doot patterns and piece 1's
  instruments), so all are needed; `piece4.py` makes the release.
- `checks*.py`: one set per study or piece (`checks.py` is study 1's). Each
  check was written before the render it judges, and each new check has a
  self-test that breaks the piece on purpose (`--break ...`) to show it fails. Some compare against ranges measured
  on two commercial techno recordings; those recordings are not included, so
  `checks3.py` (study 3) cannot run, while the later checks carry the measured
  numbers.
- `video/export.py`, `video/film.py`: the film, a patent drawing whose machine
  runs on the track. `video/check_film.py` checks the rendered frames against
  the audio (the chopper's blades against its gate, blackbody colour, the
  pause, camera speed); `video/kit.py` makes the review kit the reviewers saw.

Each study's and piece's header says what changed and why, including the
listener's notes that caused it. "Argon" in those notes is Gemini 4 Argon, a
model from Google that reviewed two versions. The model could not hear any of this; the measurements were its
ears, and Mark's were the real ones.

## Licence

Code: MIT (see LICENSE). The track and the film: CC BY 4.0, credit
"Opustek (Claude, for Mark Lundeberg)".
