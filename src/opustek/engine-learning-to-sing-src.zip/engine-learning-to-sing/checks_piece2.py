"""Checks for piece2. Renders its twins (no-decor, no-sync), then checks.
  python3 checks_piece2.py   |   --selftest"""
import json
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

import checks
import checks3
import checks_piece1 as c1
import dsp
import piece2 as P
from study4 import BEAT, BAR, HZ, tb

c1.P = P            # piece 1's checks, pointed at piece 2's score


def balance(mix, sr):
    """Kick vs mids and hats vs mids against the two reference recordings:
    low(30-120)/mid(200-4k) +9.9..+12.9 dB, high(4-16k)/mid -10.9..-15.8 dB.
    Allow 1 dB either side, in the groove (bars 21-32) and the climax (77-96)."""
    out, ok = [], True
    for a, b in ((21, 33), (77, 97)):
        m = mix.mean(1)[int(tb(a) * sr):int(tb(b) * sr)]
        f, S = signal.welch(m, sr, nperseg=8192)
        lo = 10 * np.log10(S[(f > 30) & (f < 120)].sum() / S[(f > 200) & (f < 4000)].sum())
        hi = 10 * np.log10(S[(f > 4000) & (f < 16000)].sum() / S[(f > 200) & (f < 4000)].sum())
        ok &= 8.9 <= lo <= 13.9 and -16.8 <= hi <= -9.9
        out.append(f'bars {a}-{b - 1}: low/mid {lo:+.1f}, high/mid {hi:+.1f}')
    return ok, '; '.join(out)


def steady(st):
    """The engine doesn't jump out: in the awake bars, its 400 ms level
    stays within 6 dB of its median 99% of the time. Piece 1 fails this
    (7.2 dB; worst bar 62, which starts at 1:59, where Mark heard it)."""
    sr = int(st['sr'])
    x = (st['droneL'] ** 2 + st['droneR'] ** 2) / 2
    w = int(0.4 * sr)
    lv = []
    for b in list(range(37, 65)) + list(range(77, 97)):
        for k in range(4):
            s = int(tb(b, k) * sr)
            lv.append(10 * np.log10(x[s:s + w].mean() + 1e-20))
    lv = np.array(lv)
    over = np.percentile(lv, 99) - np.median(lv)
    return over <= 6, f'99th percentile {over:.1f} dB over median'


def sings(st, tw):
    """The sync voice moves the engine's brightest harmonic with its ratio:
    against the no-sync twin, the shift in energy-weighted harmonic number
    correlates with the ratio (r >= 0.4) over bars 49-64 and 73-96."""
    sr = int(st['sr'])
    x, y = (st['droneL'] + st['droneR']) / 2, (tw['droneL'] + tw['droneR']) / 2
    tc, f0, ratio = st['tc'], tw['f0'], st['ratio']
    d, r = [], []
    for b in list(range(49, 65)) + list(range(73, 97)):
        for k in (0, 2):
            a = tb(b, k) + 0.1
            m = (tc >= a) & (tc < a + 0.3)
            if np.ptp(np.log(f0[m])) > 0.01:
                continue
            fz = float(f0[m].mean())
            hn = []
            for z in (x, y):
                seg = z[int(a * sr):int((a + 0.3) * sr)]
                X = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), 1 << 15)) ** 2
                fr = np.fft.rfftfreq(1 << 15, 1 / sr)
                e = np.array([X[np.argmin(np.abs(fr - h * fz))] for h in range(1, 41)])
                hn.append((np.arange(1, 41) * e).sum() / e.sum())
            d.append(hn[0] - hn[1])
            r.append(float(ratio[m].mean()))
    if len(d) < 10 or np.std(d) < 1e-6:
        return False, f'{len(d)} windows, no movement'
    c = np.corrcoef(d, r)[0, 1]
    return c >= 0.4, f'{len(d)} windows, r = {c:.2f}, mean shift {np.mean(d):+.2f} harmonics'


def clap_short(st, sc):
    """90% of each clap's energy arrives within 80 ms of its onset."""
    sr = int(st['sr'])
    x = st['clap'] ** 2
    fr = []
    for t in sc['claps'][:40]:
        i = int(t * sr)
        seg = x[i:i + int(0.4 * sr)]
        c = np.cumsum(seg) / seg.sum()
        fr.append(np.argmax(c >= 0.9) / sr)
    t90 = float(np.median(fr))
    return t90 <= 0.08, f'90% of energy by {t90 * 1000:.0f} ms'


def run(stem):
    sr, mix = wavfile.read(stem + '.wav')
    mix = mix.astype(np.float64)
    st = np.load(stem + '_stems.npz')
    sc = json.load(open(stem + '_score.json'))
    res = [('balance vs refs', *balance(mix, sr)), ('engine steady', *steady(st)),
           ('sync sings', *sings(st, np.load('out/piece2_BROKEN-no-sync_stems.npz'))),
           ('clap short', *clap_short(st, sc))]
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    print(' -- from piece 1:')
    r1 = c1.run(stem, twin='out/piece2_BROKEN-no-decor')
    return {**{n: ok for n, ok, _ in res}, **r1}


def render(brk=None):
    subprocess.check_call(['systemd-run', '--user', '--scope', '-q', '-p', 'MemoryMax=10G', '-p', 'MemorySwapMax=0',
                           sys.executable, 'piece2.py'] + (['--break', brk] if brk else []), stdout=subprocess.DEVNULL)


if __name__ == '__main__':
    for t in ('no-decor', 'no-sync'):
        render(t)
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        # the known-bad case is the one Mark heard: piece 1 jumping at 1:59
        ok, msg = steady(np.load('out/piece1_stems.npz'))
        print('== piece 1 (Mark heard it jump at 1:59): engine steady', 'caught' if not ok else 'NOT CAUGHT', '-', msg)
        r = run('out/piece2_BROKEN-no-sync')
        print('== no-sync: sync sings', 'caught' if not r['sync sings'] else 'NOT CAUGHT')
    else:
        render()          # the piece itself, not only its twins
        r = run('out/piece2')
        print('ALL PASS' if all(r.values()) else 'SOME FAIL: ' + ', '.join(k for k, v in r.items() if not v))
