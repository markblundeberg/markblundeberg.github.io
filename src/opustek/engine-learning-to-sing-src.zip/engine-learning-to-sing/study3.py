"""Study 3: the lead as a wide, smeared wall, from measuring two reference tracks.

Mark on study 2: neither lead worked (whistle, talking, screaming). All three
were one thin voice in the centre, and all played the same busy line.
Measured against the references:
  - their upper layers are almost as wide as they are loud (side/mid -5..-8 dB
    above 200 Hz; ours -15..-17), with the bass mono;
  - their richness is a smeared layer: partials ~70 cents wide, i.e. many
    detuned voices, strong in the side channel;
  - their mixes keep ~9-10 dB crest at -9..-10 LUFS; ours were squashed to 5;
  - ~10 dB more air above 5 kHz.
So: the drone stays; the lead becomes nine saws spread +/-35 cents across
the stereo field, playing a few long notes, moving by filter; no bus
saturation; brighter top.

  python3 study3.py [--break mono-lead|squash]
"""
import argparse
import json
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import study1 as s1
import study2 as s2
from study1 import SR, OS, BEAT, BAR, NBARS, N, CR, BLOCKS, t_bar, bar_env, up, place, sidechain, drift

HZ = s1.HZ
LEAD_FROM = 9
# few, long notes per four-bar block: (beat, MIDI)
LEAD = {'Fsm': [(0, 73), (10, 71)], 'D': [(0, 69), (10, 73)],
        'A': [(0, 76), (8, 73), (12, 71)], 'E': [(0, 71), (10, 68)]}
VOICES = 9
SPREAD = 35.0            # cents, outermost voices


def drone_stereo(tc, f0):
    """Study 1's drone, split into two decorrelated sides above 150 Hz; the
    bass below stays mono."""
    nos, sro = N * OS, SR * OS
    vs = []
    for v, dc in enumerate([-7.0, 0.0, 6.0]):
        cents = dc + drift(len(tc), CR, 3.5, seed=10 + v)
        vs.append(dsp.saw(up(f0 * 2 ** (cents / 1200), tc, nos, sro), sro, phase=0.31 * v))
    sect = (300 + 500 * bar_env(tc, range(5, 9), 1.5) + 1100 * bar_env(tc, range(9, 25), 2.0)
            + 300 * bar_env(tc, range(17, 25), 3.0) + 250 * bar_env(tc, range(29, 33), 0.5))
    lfo = 1 + 0.25 * np.sin(2 * np.pi * tc / (8 * BAR))
    cut = up(sect * (f0 / 55.0) ** 1.4 * lfo * 2 ** (drift(len(tc), CR, 80, seed=20) / 1200), tc, nos, sro)
    ph = 2 * np.pi * np.cumsum(up(f0, tc, nos, sro) / 2) / sro
    out = []
    for w in ((0.55, 0.3, 0.15), (0.15, 0.3, 0.55)):
        x = sum(a * v for a, v in zip(w, vs))
        b = dsp.ladder(x, cut, sro, res=0.42, drive=1.6) * (1 + 0.10 * np.sin(ph))
        out.append(signal.resample_poly(np.tanh(1.3 * b) / np.tanh(1.3), 1, OS)[:N])
    L, R = out
    mid = (L + R) / 2
    low = dsp.butter(mid, 150, SR, 'low', 4)
    L = low + dsp.butter(L, 150, SR, 'high', 4)
    R = low + dsp.butter(R, 150, SR, 'high', 4)
    env = up(np.clip(tc / 2.0, 0, 1) * np.clip(1 - (tc - t_bar(NBARS + 1) - 1.0) / 2.5, 0, 1), tc, N, SR)
    return L * env, R * env


def wall_lead(tc, mono=False):
    """Nine saws spread +/-SPREAD cents, each with its own drift and pan,
    through a resonant ladder per side whose cutoff breathes over 8 bars and
    swells a little on each note. One octave-down voice pair for body."""
    nos, sro = N * OS, SR * OS
    ptgt = np.full(len(tc), np.log(HZ(73)))
    on = np.zeros(len(tc))
    swell = np.zeros(len(tc))
    for k, ch in enumerate(BLOCKS):
        b0 = t_bar(1 + 4 * k)
        if b0 < t_bar(LEAD_FROM):
            continue
        for beat, m in LEAD[ch]:
            te = b0 + beat * BEAT
            sel = tc >= te
            ptgt[sel] = np.log(HZ(m))
            on[sel] = 1.0
            swell = np.where(sel, np.exp(-np.clip(tc - te, 0, None) / 1.2), swell)
    f = np.exp(s1.onepole_lag(ptgt, 0.09, 0.09, CR))
    amp = np.clip((tc - t_bar(LEAD_FROM)) / (4 * BAR), 0, 1) ** 1.5 * on
    amp *= np.clip(1 - (tc - t_bar(NBARS + 1)) / 3.0, 0, 1)
    # breakdown: lead stays, everything else drops; the filter opens slowly
    phrase = 0.5 - 0.5 * np.cos(2 * np.pi * (tc - t_bar(LEAD_FROM)) / (8 * BAR))
    cut = 500 + 2600 * phrase + 900 * swell + 1200 * bar_env(tc, range(29, 33), 2.0)
    cut_os = up(cut, tc, nos, sro)
    L, R = np.zeros(nos), np.zeros(nos)
    for i in range(VOICES):
        u = i / (VOICES - 1) * 2 - 1                      # -1 .. 1
        c = SPREAD * u + drift(len(tc), CR, 4, seed=60 + i)
        x = dsp.saw(up(f * 2 ** (c / 1200), tc, nos, sro), sro, phase=(0.37 * i) % 1)
        pan = 0.5 if mono else 0.5 + 0.48 * u * (1 if i % 2 else -1)
        L += x * (1 - pan)
        R += x * pan
    for sgn, p in ((-1, 0.2), (1, 0.8)):                 # octave-down pair
        x = dsp.saw(up(f / 2 * 2 ** (sgn * 6 / 1200), tc, nos, sro), sro, 0.11)
        p = 0.5 if mono else p
        L += 1.5 * x * (1 - p)
        R += 1.5 * x * p
    L, R = L / VOICES, R / VOICES
    out = []
    for x in (L, R):
        y = dsp.ladder(x, cut_os, sro, res=0.35, drive=1.8)
        y = np.tanh(1.4 * y) / np.tanh(1.4)
        out.append(signal.resample_poly(y * up(amp, tc, nos, sro), 1, OS)[:N])
    return out


HATS = float(__import__("os").environ.get("HATS", "0.5"))
BED = float(__import__("os").environ.get("BED", "0.7"))   # level of sustained layers vs kick


def kick_hit(sr):
    """Shorter and less saturated than study 2's, matched to reference A's averaged
    kick: its low band falls to half 72 ms after the peak and to a tenth by
    200 ms, tail tuned to the key root (its ~52.8 Hz on G#; ours A1)."""
    t = np.arange(int(0.4 * sr)) / sr
    f = 55 + 150 * np.exp(-t / 0.018) + 25 * np.exp(-t / 0.08)
    env = np.exp(-np.clip(t - 0.03, 0, None) / 0.085) * np.clip(t / 0.0006, 0, 1)
    x = np.sin(2 * np.pi * np.cumsum(f) / sr) * env
    click = dsp.butter(np.random.default_rng(1).standard_normal(len(t)), (2000, 7000), sr, 'band') * np.exp(-t / 0.0025)
    return np.tanh(1.2 * (x + 0.15 * click)) / np.tanh(1.2)


def render(brk=None):
    t0 = time.time()

    class A:
        brk = None
    tc, f0, _, _, _ = s1.score(A)
    bL, bR = drone_stereo(tc, f0)
    lL, lR = wall_lead(tc, mono=brk == 'mono-lead')

    kicks = [t_bar(b) + i * BEAT for b in s1.KICK_BARS for i in range(4)]
    kick = np.zeros(N)
    place(kick, kick_hit(SR), [(k, 1.0) for k in kicks], SR, gain=1.0)
    hats = np.zeros(N)
    place(hats, s2.hat_hit(SR, 0.08, 2), [(t_bar(b) + (i + 0.5) * BEAT, 1.0) for b in s1.HAT_BARS for i in range(4)], SR, 0.8)
    place(hats, s2.hat_hit(SR, 0.02, 3), [(t_bar(b) + i * BEAT / 4, (0.0, 0.4, 0.0, 0.6)[i % 4])
                                         for b in list(range(13, 25)) + list(range(29, 33)) for i in range(16)], SR, 0.55)
    clap = np.zeros(N)
    place(clap, s2.clap_hit(SR), [(t_bar(b) + i * BEAT, 1.0) for b in s1.CLAP_BARS for i in (1, 3)], SR, 0.13)

    sc_b = sidechain(kicks, N, SR, 0.6)
    sc_l = sidechain(kicks, N, SR, 0.45, rel=0.2)
    bL, bR = bL * sc_b * 0.38 * BED, bR * sc_b * 0.38 * BED
    lL, lR = lL * sc_l * 0.30 * BED, lR * sc_l * 0.30 * BED
    hL = (dsp.butter(hats, 8000, SR, 'high', 1) * 0.4 + hats * 0.8) * HATS
    L = bL + kick + hL * 0.8 + clap + lL
    R = bR + kick + hL * 1.2 + clap + lR
    dL, dR = dsp.pingpong(lL * 0.15, lR * 0.05, 0.75 * BEAT, SR, fb=0.4, damp_hz=4000)
    rL, rR = dsp.reverb(lL * 0.45 + clap * 0.5 + dL * 0.5 + bL * 0.05, lR * 0.45 + clap * 0.5 + dR * 0.5 + bR * 0.05,
                        SR, rt60=5.0, damp_hz=7500)
    L, R = L + dL + rL, R + dR + rR
    if brk == 'squash':
        L, R = np.tanh(3 * L) / 3, np.tanh(3 * R) / 3
    if brk == 'mono-mix':
        L = R = (L + R) / 2
    mix = np.stack([L, R], axis=1)
    mix -= mix.mean(axis=0)
    for _ in range(3):
        g = 10 ** ((-10.0 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.2, rel_ms=60)
    print(f'render {time.time() - t0:.1f} s')
    return mix, {'kick': kick, 'leadL': lL, 'leadR': lR}, kicks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--break', dest='brk', choices=['mono-lead', 'squash', 'mono-mix'])
    a = ap.parse_args()
    mix, stems, kicks = render(a.brk)
    name = 'study3' + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, **stems)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'kicks': kicks}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
