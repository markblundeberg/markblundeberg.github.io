"""Checks for piece1.  python3 checks_piece1.py   |   --selftest"""
import json
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

import checks
import checks3
import checks5
import dsp
import piece1 as P
from study4 import BEAT, BAR, HZ, tb


def centroid(x, sr, a, b):
    f, S = signal.welch(x[int(a * sr):int(b * sr)], sr, nperseg=4096)
    k = (f > 200) & (f < 8000)
    return (f[k] * S[k]).sum() / S[k].sum()


def intro_clears(st):
    """The doots open up over the intro, as reference A's do (245 -> 360 Hz, +47%):
    centroid of the doots' own stem in bars 13-16 at least 40% above bars
    1-4. (Measured on the stem: on the mix, the hats arriving at bar 9 pass
    this even when the doots stay muffled.)"""
    sr, m = int(st['sr']), st['doots']
    a, b = centroid(m, sr, tb(1), tb(5)), centroid(m, sr, tb(13), tb(17))
    return b / a >= 1.4, f'centroid {a:.0f} -> {b:.0f} Hz ({100 * (b / a - 1):+.0f}%)'


def claps_on_grid(st, sc):
    ok, msg = checks.kick_sync({'sr': st['sr'], 'kick': st['clap']}, {'kicks': [tb(b, i) for b in P.CLAP for i in (1, 3)]})
    return ok, msg.replace('kicks', 'claps')


def bass_pitch(st):
    sr = int(st['sr'])
    x = (st['droneL'] + st['droneR']) / 2
    bad, n = [], 0
    for i, (bar, beat, m) in enumerate(P.BASS):
        a = tb(bar, beat) + 0.45
        b = tb(*P.BASS[i + 1][:2]) - 0.1 if i + 1 < len(P.BASS) else a + 1.5
        # avoid the flips: use the first beat and a half after the glide
        b = min(b, a + 0.6)
        if b - a < 0.3 or any(tb(fb, fbt) - 0.05 < b and tb(fb, fbt) + 0.3 > a for fb, fbt in P.FLIPS.items()):
            continue
        seg = x[int(a * sr):int(b * sr)]
        if np.abs(seg).max() < 1e-3:
            continue
        got = checks5.f0_at(x, sr, a, b, HZ(m))
        c = 1200 * np.log2(got / HZ(m))
        n += 1
        if abs(c) > 25:
            bad.append(f'bar {bar}: {c:+.0f} c')
    return (not bad and n >= 15), f'{n} notes checked' + ('' if not bad else '; off: ' + ', '.join(bad[:4]))


def flips(st):
    sr, x = int(st['sr']), (st['droneL'] + st['droneR']) / 2
    tc, f0 = st['tc'], st['f0']
    ok, n = 0, 0
    for bar, beat in P.FLIPS.items():
        s = tb(bar, beat)
        base = float(np.interp(s - 0.15, tc, f0))
        n += 1
        fb = checks5.f0_at(x, sr, s - 0.26, s - 0.02, base)
        ff = checks5.f0_at(x, sr, s + 0.03, s + 0.5 * BEAT - 0.02, base * 2)
        ok += abs(1200 * np.log2(ff / fb) - 1200) <= 60
    return ok >= 0.8 * n, f'{ok}/{n} flips an octave up'


def decorations(st, tw):
    sr = int(st['sr'])
    x, y = (st['droneL'] + st['droneR']) / 2, (tw['droneL'] + tw['droneR']) / 2
    good, out = 0, []
    for bar, beat, kind, att, hold, dec, amt in P.DECOR:
        a = None
        for s0 in np.arange(tb(bar, beat) + att * 0.7, tb(bar, beat) + att + hold + 0.2, 0.02):
            m = (tw['tc'] >= s0) & (tw['tc'] < s0 + 0.3)
            if np.ptp(np.log(tw['f0'][m])) < 0.01:
                a = s0
                break
        if a is None:
            out.append(f'{kind}@{bar}:?')
            continue
        f0 = float(np.interp(a, tw['tc'], tw['f0']))
        if kind == 'growl':
            d = checks5.features(x, sr, a, a + 0.3, f0)[1] - checks5.features(y, sr, a, a + 0.3, f0)[1]
            g = d >= 6
        else:
            d = checks5.spec_change(x, y, sr, a, a + 0.3)
            g = d >= 1.5
        good += g
        out.append(f'{kind}@{bar}:{d:+.1f}')
    return good >= len(P.DECOR) - 1, f'{good}/{len(P.DECOR)} audible: ' + ' '.join(out)


def run(stem, twin='out/piece1_BROKEN-no-decor'):
    sr, mix = wavfile.read(stem + '.wav')
    mix = mix.astype(np.float64)
    st = np.load(stem + '_stems.npz')
    sc = json.load(open(stem + '_score.json'))
    kb = [tb(b) for b in P.KICK]
    kp = np.concatenate([mix[int(t * sr):int((t + BAR) * sr)] for t in kb])
    c = checks3.crest(kp, sr)
    w = checks3.side_mid(mix, sr, 300, 3000, tb(73), tb(97))
    bm = checks3.side_mid(mix, sr, 30, 100, tb(73), tb(97))
    L = dsp.lufs(mix, sr)
    res = [('kick on the grid', *checks.kick_sync(st, sc)),
           ('claps on 2 and 4', *claps_on_grid(st, sc)),
           ('intro clears', *intro_clears(st)),
           ('bass line in tune', *bass_pitch(st)),
           ('flips', *flips(st))]
    try:
        res.append(('decorations audible', *decorations(st, np.load(twin + '_stems.npz'))))
    except FileNotFoundError:
        pass
    res += [('punch (kick bars)', c >= 8, f'{c:.1f} dB'), ('wide above 300 Hz', w >= -10, f'{w:.1f} dB'),
            ('mono bass', bm <= -20, f'{bm:.1f} dB'), ('loudness', abs(L + 10) <= 0.6, f'{L:.2f} LUFS')]
    res += [r for r in checks.levels(mix, sr) if r[0] != 'loudness']
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    return {n: ok for n, ok, _ in res}


def render(brk=None):
    subprocess.check_call(['systemd-run', '--user', '--scope', '-q', '-p', 'MemoryMax=9G', '-p', 'MemorySwapMax=0',
                           sys.executable, 'piece1.py'] + (['--break', brk] if brk else []), stdout=subprocess.DEVNULL)


if __name__ == '__main__':
    render('no-decor')
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        for brk, which in (('muffled', 'intro clears'), ('late-clap', 'claps on 2 and 4')):
            render(brk)
            r = run(f'out/piece1_BROKEN-{brk}')
            print(f'== {brk}: {which}', 'caught' if not r[which] else 'NOT CAUGHT')
        r = run('out/piece1_BROKEN-no-decor')
        print('== no-decor: decorations audible', 'caught' if not r['decorations audible'] else 'NOT CAUGHT')
    else:
        r = run('out/piece1')
        print('ALL PASS' if all(r.values()) else 'SOME FAIL: ' + ', '.join(k for k, v in r.items() if not v))
