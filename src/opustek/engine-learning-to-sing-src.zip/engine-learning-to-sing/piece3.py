"""Engine, Learning to Sing (v3).

Mark on v2: "Pretty good. The backing sounds need more variation, somehow too
repetitive. Lower the kick a bit more. And if you can make the engine sound
even more sick, always good."
Argon on v2 (it had the MP3 and piece2.py): the octave flips sound like "a
basset hound barking" (Mark heard them as a shriek in v1); the cloog is "still
polite", let the climax open to 2.5-4 kHz and sizzle; ideas taken: Karplus-
Strong metal plucks (with fractional delay, or high notes go out of tune: true,
up to 12 cents), a shimmer in the breakdown, 3-over-4 mechanical percussion,
and evolving the doots (pattern, register, echo damping dark -> bright).
Argon's theory for the shriek: a flip doubles f0, so the sync peak (ratio x f0)
jumps into the ear's 2-4 kHz zone. So: no flips, and the sync peak is capped
below 1.8 kHz everywhere. Instead of hiccups, the engine climbs an octave once,
in the climax, and stays up for two bars.

  python3 piece3.py [--break static-backing|int-ks|dark-climax|no-sync|no-decor|late-clap|muffled]
"""
import argparse
import json
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import piece1 as p1
import piece2 as p2
import study1 as s1
import study4 as s4
import study5 as s5
from piece1 import R, mask, ramp, NBARS, TAIL, KICK, HATS, HAT16, DOOTS, SWEEPS, ENGINE_IDLE
from study4 import SR, OS, CR, BEAT, BAR, HZ, tb

# the line: piece 1's, except bar 89 climbs an octave (B1 -> B2) and holds two bars
BASS = [(b, bt, (47 if (b, bt) == (89, 0) else m)) for b, bt, m in p1.BASS]
FLIPS = {}
DECOR = p2.DECOR
SYNC_PEAK_MAX = 1800.0                     # Hz: keep the sync peak out of the 2-4 kHz zone
GRIT_BAND = (300, 4000)                    # Hz: the parallel distortion send's band
GAIN = dict(p2.GAIN, kick=0.70)

CLAP = [b for b in p1.CLAP if b not in (32, 48, 64, 96)]     # breathe before section changes
SECTION_ENDS = (16, 32, 48, 64, 96)

# metal plucks (Karplus-Strong): sparse phrases, (bar, beat, MIDI)
KS_NOTES = []
_ph = [(0, 85), (1.5, 81), (3, 83)], [(0.5, 88), (2, 85)], [(0, 90), (1, 88), (2.5, 85), (3.5, 81)], [(1, 83), (3, 78)]
for start, bars in ((9, 8), (25, 8), (65, 7), (99, 10)):
    for k in range(bars):
        if k % 2 == 0:
            for beat, m in _ph[(start + k) // 2 % 4]:
                KS_NOTES.append((start + k, beat, m))

# 3-over-4 machine: a steam valve every three eighths, a gear click after it
MECH_BARS = R(25, 32) + R(49, 64) + R(81, 96)


def doot_pattern(bar, brk=None):
    """The doots evolve. Act 1 alternates piece 1's two bars, with a fill every
    8th bar and the accents rotating every 4 bars; the breakdown keeps only
    the accented notes; act 3 (from bar 73) lifts some notes an octave and
    swaps in new tails. Returns [(step, MIDI, accent, velocity)]."""
    pat = p1.DOOT_B if bar % 4 == 0 else p1.DOOT_A
    if brk == 'static-backing':
        return [(i, m, p1.ACCENT[i], 0.75 + 0.25 * p1.ACCENT[i]) for i, m in enumerate(pat)]
    rng = np.random.default_rng(1000 + bar)
    rot = (bar // 4) % 3
    acc = p1.ACCENT[rot:] + p1.ACCENT[:rot]
    out = []
    act3 = bar >= 73
    tails = [[71, 69, 64, 61], [73, 71, 69, 66], [69, 66, 64, 61], [76, 73, 71, 69]]
    for i, m in enumerate(pat):
        if act3:
            if i >= 12:
                m = tails[(bar // 2) % 4][i - 12]
            if acc[i] and (bar // 4) % 2 == 1:
                m += 12
        if bar % 8 == 0 and i >= 8 and i % 2 == 1:
            continue                                   # fill: thin out the second half
        if 65 <= bar <= 71 and not acc[i]:
            continue                                   # breakdown: accents only
        v = (0.72 + 0.28 * acc[i]) * rng.uniform(0.85, 1.0)
        out.append((i, m, acc[i], v))
    return out


def ks_note(sr, hz, brk=None):
    """A struck metal bar: a band-passed click into a fractional-delay
    Karplus-Strong loop with little averaging (bright, long ring)."""
    n = int(2.5 * sr)
    t = np.arange(n) / sr
    click = dsp.butter(np.random.default_rng(int(hz)).standard_normal(n), (1500, 6000), sr, 'band') * np.exp(-t / 0.002)
    y = dsp.ks(click, sr, hz, fb=0.9975, bright=0.35, int_delay=(brk == 'int-ks'))
    return y * np.exp(-t / 1.2)


def mech(sr, kind, rng):
    t = np.arange(int(0.35 * sr)) / sr
    if kind == 'valve':
        # a pneumatic sigh: noise through a band-pass sweeping down 6 -> 1.5 kHz
        nz = rng.standard_normal(len(t))
        fc = 1500 + 4500 * np.exp(-t / 0.09)
        y = dsp.svf_bp(nz, fc, sr, 2.5)
        env = (1 - np.exp(-t / 0.025)) * np.exp(-t / 0.12)
        return y * env
    # gear click: two inharmonic sines, 8 ms decay
    return (np.sin(2 * np.pi * 1840 * t) + 0.7 * np.sin(2 * np.pi * 2910 * t)) * np.exp(-t / 0.008)


def cloog(tc, f0, cut, amp, dc, ratio, blend, dist):
    """Piece 2's engine with the sync peak capped, a parallel distortion
    send (band-passed 300 Hz-4 kHz, hard tanh) for the sick part, and the
    tube held a little warm in the climax."""
    nos, sro = int(len(tc) / CR * SR) * OS, SR * OS
    n = nos // OS
    U = lambda c: s1.up(c, tc, nos, sro)
    vs = []
    for v, dct in enumerate([-7.0, 0.0, 6.0]):
        cents = dct + s1.drift(len(tc), CR, 3.5, seed=10 + v)
        vs.append(dsp.saw(U(f0 * 2 ** (cents / 1200)), sro, phase=0.31 * v))
    sync = dsp.syncsaw(U(f0 * 2 ** (s1.drift(len(tc), CR, 2.5, seed=31) / 1200)), U(ratio), sro, 0.13)
    bl = U(blend)
    sq = dc['squelch']
    cut_os = U(cut * (1 + p2.SQ_LIFT * sq))
    sqo = U(sq)
    drive, fold, growl = U(dc['drive']), U(dc['fold']), U(0.10 + 0.75 * dc['growl'])
    fold_gain = 1.5 + 4.5 * fold
    ph = 2 * np.pi * np.cumsum(U(f0) / 2) / sro
    ds = U(dist)
    out = []
    for w in ((0.55, 0.3, 0.15), (0.15, 0.3, 0.55)):
        x = sum(a * v for a, v in zip(w, vs)) * (1 - 0.5 * bl) + sync * bl * 1.1
        b = dsp.ladder(x, cut_os, sro, res=0.42, drive=1.6)
        if sq.max() > 0:
            b = b * (1 - sqo) + dsp.ladder(x, cut_os, sro, res=p2.SQ_RES, drive=1.6) * sqo
        b = b * (1 + growl * np.sin(ph)) / (1 + 0.5 * growl)
        y = s5.tube(b, drive)
        y = y * (1 - fold) + np.sin(fold_gain * b) * fold
        grit = np.tanh(6.0 * dsp.butter(y, GRIT_BAND, sro, 'band', 2)) * 0.5
        y = y + ds * grit
        out.append(signal.resample_poly(y, 1, OS)[:n])
    L, Rr = out
    low = dsp.butter((L + Rr) / 2, 150, SR, 'low', 4)
    f_line = s4.glide_curve(tc, BASS, s4.GLIDE)
    sub = np.sin(2 * np.pi * np.cumsum(s1.up(np.minimum(f0, f_line) / 2, tc, n, SR)) / SR)
    low = low + 0.35 * dsp.butter(sub, 120, SR, 'low', 2)
    hiL = dsp.phaser(dsp.butter(L, 150, SR, 'high', 4), SR, rate=0.045, fmin=250, fmax=2600, stages=6, fb=0.5, phase=0.0)
    hiR = dsp.phaser(dsp.butter(Rr, 150, SR, 'high', 4), SR, rate=0.045, fmin=250, fmax=2600, stages=6, fb=0.5, phase=1.9)
    a = s1.up(amp, tc, n, SR)
    return (low + hiL) * a, (low + hiR) * a


def engine(tc, brk=None):
    f_line = s4.glide_curve(tc, BASS, s4.GLIDE)
    f0 = f_line.copy()
    idle = mask(tc, R(*ENGINE_IDLE), 2.0) * 0.6
    awake = mask(tc, R(33, 64) + R(73, 96), 0.5) * ramp(tc, tb(33), tb(35))
    wake2 = mask(tc, R(66, 71), 0.5) * ramp(tc, tb(66), tb(71), 0.0, 0.9)
    outro = mask(tc, R(97, 112), 0.5) * ramp(tc, tb(97), tb(109), 1.0, 0.75)
    lvl = np.maximum.reduce([idle, awake, wake2, outro])
    climax_open = 1000 if brk == 'dark-climax' else 2600
    base = (220 + 300 * mask(tc, R(33, 48), 2) + 800 * mask(tc, R(49, 64), 2) + 300 * mask(tc, R(66, 71), 2)
            * ramp(tc, tb(66), tb(71)) + climax_open * mask(tc, R(73, 96), 1) * ramp(tc, tb(73), tb(89), 0.4, 1.0)
            + 400 * mask(tc, R(97, 112), 2) * ramp(tc, tb(97), tb(109), 1, 0))
    base *= 1 + 0.2 * np.sin(2 * np.pi * tc / (16 * BAR) + 1.3)
    sw = np.zeros(len(tc))
    for bar, up_, dn, octv in SWEEPS:
        a, p, z = tb(bar), tb(bar + up_), tb(bar + up_ + dn)
        sw += octv * np.where(tc < p, ramp(tc, a, p), 1 - ramp(tc, p, z)) * (tc >= a) * (tc < z)
    depth = s5.womp_depth(tc) * mask(tc, R(33, 96), 4)
    w = s5.womp_curve(tc, depth)
    cut = base * 2 ** sw * (0.6 + 0.4 * w) * (np.minimum(f_line, HZ(42)) / HZ(30)) ** 0.8
    tend = tb(NBARS - 3)
    off = tc >= tend
    dk = np.exp(-np.clip(tc - tend, 0, None) / 1.6)
    f0 = np.where(off, f0 * dk + 24 * (1 - dk), f0)
    lvl = lvl * np.where(off, np.clip(1 - (tc - tend) / 5.0, 0, 1), 1)
    dc = {k: np.zeros(len(tc)) for k in s5.KINDS}
    if brk != 'no-decor':
        for bar, beat, kind, att, hold, dec, amt in DECOR:
            dc[kind] = np.maximum(dc[kind], amt * s5.analog_env(tc, tb(bar, beat), att, hold, dec))
        dc['drive'] = np.maximum(dc['drive'], 0.25 * mask(tc, R(77, 96), 4))   # a warm tube under the climax
    ratio, blend = p2.sync_ratio(tc, s4.glide_curve(tc, BASS, s4.GLIDE), 'no-sync' if brk == 'no-sync' else None)
    ratio = np.minimum(ratio, np.maximum(1.0, SYNC_PEAK_MAX / f0))
    dist = 0.08 * mask(tc, R(33, 48), 2) + 0.2 * mask(tc, R(49, 64), 1) + 0.2 * mask(tc, R(77, 96), 2)
    return f0, cut, lvl * w, dc, ratio, blend, dist


def render(brk=None):
    t0 = time.time()
    dur = NBARS * BAR + TAIL
    N = int(dur * SR)
    tc = np.arange(int(dur * CR)) / CR
    pad = lambda z: np.pad(z, (0, max(0, N - len(z))))[:N]
    rng = np.random.default_rng(5)

    f0, cut, amp, dc, ratio, blend, dist = engine(tc, brk)
    eL, eR = (pad(z) for z in cloog(tc, f0, cut, amp, dc, ratio, blend, dist))
    eL, eR = p2.leveler(eL, eR, SR)

    # doots, evolving; their echoes darken -> brighten over the piece
    cl = p1.clarity(tc, brk)
    doots = np.zeros(N)
    cache = {}
    for bar in DOOTS:
        for i, m, acc, v in doot_pattern(bar, brk):
            te = tb(bar) + i * BEAT / 4
            o = round(float(np.interp(te, tc, cl)), 2)
            key = (m, o, acc)
            if key not in cache:
                cache[key] = p1.doot(SR, HZ(m), o, acc)
            s1.place(doots, cache[key], [(te, v)], SR)
    lift = 1 + 0.45 * mask(tc, R(17, 32), 1.0)
    doots *= s1.up(ramp(tc, 0, tb(3), 0.3, 1.0) * ramp(tc, tb(105), tb(109), 1.0, 0.0) * lift, tc, N, SR) * GAIN['doots']
    bright = s1.up(np.clip(ramp(tc, tb(1), tb(89)) - ramp(tc, tb(97), tb(109)), 0, 1), tc, N, SR)
    if brk == 'static-backing':
        bright = np.full(N, 0.4)
    ech = {}
    for tag, damp in (('d', 1200), ('b', 4500)):
        ech[tag] = (dsp.tapedelay(doots, SR, 0.5 * BEAT, wow_ms=1.5, wow_hz=0.4, fb=0.5, damp_hz=damp, phase=0.0),
                    dsp.tapedelay(doots, SR, 0.5 * BEAT + 0.011, wow_ms=1.8, wow_hz=0.47, fb=0.5, damp_hz=damp, phase=1.7))
    eL8 = ech['d'][0] * (1 - bright) + ech['b'][0] * bright
    eR8 = ech['d'][1] * (1 - bright) + ech['b'][1] * bright
    wl = dsp.tapedelay(doots, SR, 0.75 * BEAT, wow_ms=3.5, wow_hz=0.55, fb=0.6, damp_hz=2200, phase=0.4)
    wr = dsp.tapedelay(doots, SR, 1.0 * BEAT, wow_ms=4.0, wow_hz=0.71, fb=0.58, damp_hz=2000, phase=2.3)

    # shimmer in the breakdown: the doots an octave and a fifth up, all wet
    shim = np.zeros(N)
    for bar in R(65, 72):
        if bar not in DOOTS and bar != 72:
            continue
        for i, m, acc, v in doot_pattern(min(bar, 71), brk):
            te = tb(bar) + i * BEAT / 4
            for mult, g in ((2.0, 0.6), (1.5, 0.4)):
                s1.place(shim, p1.doot(SR, HZ(m) * mult, 0.6, 1), [(te, v * g)], SR)
    shim = dsp.butter(shim, 2800, SR, 'low', 2) * GAIN['doots'] * 0.8

    # metal plucks
    ksig = np.zeros(N)
    kc = {}
    for bar, beat, m in KS_NOTES:
        if m not in kc:
            kc[m] = ks_note(SR, HZ(m), brk)
        s1.place(ksig, kc[m], [(tb(bar, beat), rng.uniform(0.7, 1.0))], SR)
    ksig *= 0.05
    kL, kR = dsp.pingpong(ksig * 0.7, ksig * 0.3, 0.75 * BEAT, SR, fb=0.45, damp_hz=5000)

    # 3-over-4 machine
    mv = np.zeros(N)
    mg = np.zeros(N)
    for b in MECH_BARS:
        for e in range(8):
            g = (b - 1) * 8 + e                     # global eighth index
            t = tb(b, e / 2)
            if g % 3 == 0 and not (b % 4 == 0 and e >= 6):
                s1.place(mv, mech(SR, 'valve', rng), [(t, rng.uniform(0.7, 1.0))], SR)
            if g % 3 == 1 and b >= 49:
                s1.place(mg, mech(SR, 'gear', rng), [(t, rng.uniform(0.6, 1.0))], SR)
    mv *= 0.045
    mg *= 0.03
    gL, gR = dsp.pingpong(mg, mg * 0.2, 0.25 * BEAT, SR, fb=0.35, damp_hz=7000)

    # drums
    kicks = [tb(b, i) for b in KICK for i in range(4)]
    kick = np.zeros(N)
    s1.place(kick, p1.kick_hit(SR), [(k, 1.0) for k in kicks], SR, GAIN['kick'])
    claps = [tb(b, i) + (0.012 if brk == 'late-clap' else 0.0) for b in CLAP for i in (1, 3)]
    clap = np.zeros(N)
    s1.place(clap, p2.clap_hit(SR), [(c, 1.0) for c in claps], SR, GAIN['clap'])
    ghost = [tb(b, 3.75) for b in CLAP if b % 4 == 2]
    s1.place(clap, p2.clap_hit(SR), [(c, 0.35) for c in ghost], SR, GAIN['clap'])
    hL, hR = np.zeros(N), np.zeros(N)
    for b in HATS:
        lv = 0.6 if b < 17 else 1.0
        for i in range(8):
            if b in SECTION_ENDS and i >= 6:
                continue                              # a gap before each new section
            h = s4.spaghetti(SR, rng)
            if b % 2 == 0 and i == 7:
                h = np.concatenate([h, np.zeros(len(h))]) * 1.0
                h = h * np.exp(-np.arange(len(h)) / SR / 0.25) * 2.2   # an open hat on the last "and"
            g = (0.5, 1.0)[i % 2] * rng.uniform(0.8, 1.0) * lv
            p = 0.5 + rng.uniform(-0.25, 0.25)
            s1.place(hL, h, [(tb(b, i / 2), g * (1 - p))], SR)
            s1.place(hR, h, [(tb(b, i / 2), g * p)], SR)
    for b in HAT16:
        for i in range(16):
            if i % 2 == 1 and rng.uniform() < 0.7:
                h = s4.spaghetti(SR, rng) * 0.3
                p = 0.5 + rng.uniform(-0.4, 0.4)
                s1.place(hL, h, [(tb(b, i / 4) + 0.006, 1 - p)], SR)   # a touch late: swing
                s1.place(hR, h, [(tb(b, i / 4) + 0.006, p)], SR)

    # mix
    sc = s1.sidechain(kicks, N, SR, 0.55, rel=0.18)
    eL, eR = eL * sc * GAIN['engine'], eR * sc * GAIN['engine']
    dt = doots * s1.sidechain(kicks, N, SR, 0.25)
    echo = s1.sidechain(kicks, N, SR, 0.35)
    rl, rr = dsp.reverb(wl * 0.8 + doots * 0.2 + kL * 0.5, wr * 0.8 + doots * 0.2 + kR * 0.5, SR, rt60=6.5, damp_hz=3500)
    sl, sr_ = dsp.reverb(shim, shim, SR, rt60=8.0, damp_hz=5000, mod=6.0)
    hg = GAIN['hats'] * s1.up(1 - 0.25 * mask(tc, R(73, 96), 2), tc, N, SR)
    L = (kick + eL + dt * 0.9 + (eL8 * 0.45 + wl * 0.3 + rl * 0.5) * echo + hL * hg + clap
         + ksig * 0.5 + kL + sl * 0.9 + mv * 0.8 + gL)
    Rr = (kick + eR + dt * 1.1 + (eR8 * 0.45 + wr * 0.3 + rr * 0.5) * echo + hR * hg + clap
          + ksig * 0.5 + kR + sr_ * 0.9 + mv * 1.2 + gR)
    cl_, cr_ = dsp.reverb(clap * 0.25 + eL * 0.04 + hL * 0.06 + mv * 0.3, clap * 0.25 + eR * 0.04 + hR * 0.06 + mv * 0.3,
                          SR, rt60=1.5, damp_hz=7000)
    mix = np.stack([L + cl_, Rr + cr_], 1)
    mix -= mix.mean(0)
    for _ in range(6):
        g = 10 ** ((-10.0 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.2, rel_ms=60)
    mix *= s1.up(np.clip((dur - tc) / 1.5, 0, 1), tc, N, SR)[:, None]
    print(f'render {time.time() - t0:.1f} s')
    backing = doots + ksig + mv + mg + (hL + hR) * hg
    stems = {'kick': kick, 'clap': clap, 'droneL': eL, 'droneR': eR, 'doots': doots, 'ks': ksig, 'backing': backing}
    return mix, stems, kicks, claps, tc, f0, ratio, blend


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--break', dest='brk', choices=['static-backing', 'int-ks', 'dark-climax', 'no-sync', 'no-decor',
                                                   'late-clap', 'muffled'])
    a = ap.parse_args()
    mix, stems, kicks, claps, tc, f0, ratio, blend = render(a.brk)
    name = 'piece3' + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, tc=tc, f0=f0, ratio=ratio, blend=blend, **stems)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'kicks': kicks, 'claps': claps, 'ks': KS_NOTES}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
