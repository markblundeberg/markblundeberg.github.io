"""Study 4: reference A's 3:40-4:41 arc, with our own notes.

Mark walked us through it: kick, doots, "spaghetti" hats and a warbling echo
wash; strip to doots + wash; the engine wakes as a bass line that climbs with
glides and pulses (womp womp); doots and drone open up; the kick returns;
the drone keeps climbing; a short pause; the full texture again.
Measured on reference A: 123.0 bpm; bass holds 1-8 s and
glides in ~0.3 s; doots are mid-range plucks (fund. ~165-250 Hz) at half level
after ~200 ms; hats are eighths, each a flam of grains, ~9.5 kHz, ~0.2 s tail;
the wash sits in the side channel.

  python3 study4.py                      the arc  -> out/study4.wav
  python3 study4.py --womptest           24 s: three womp rates in a row
  python3 study4.py --womp bar|half|dotted
  python3 study4.py --break no-strip|wrong-bass|no-womp
"""
import argparse
import json
import os
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import study1 as s1
import study3 as s3

SR, OS, CR = 48000, 2, 1000
BPM = 123.0
BEAT = 60 / BPM
BAR = 4 * BEAT
NBARS = 31
TAIL = 5.0
HZ = s1.HZ
tb = lambda bar, beat=0.0: (bar - 1) * BAR + beat * BEAT

# --- arrangement (bars, inclusive ranges) -----------------------------------
KICK = list(range(1, 9)) + list(range(19, 27)) + list(range(28, 32))
HATS = list(range(1, 9)) + list(range(21, 27)) + list(range(28, 32))
DOOTS = list(range(1, 27)) + list(range(28, 32))
DRONE_FROM, OPEN_AT, PAUSE = 13, 17, 27

# bass line: (bar, beat, MIDI); glides between, climbing, an octave fall into
# the pause, back low for the return.  F#1=30 A1=33 B1=35 C#2=37 D#2=39 E2=40 F#2=42
BASS = [(13, 0, 30), (15, 2, 37), (17, 0, 33), (19, 0, 30), (21, 0, 35), (22, 2, 37),
        (23, 0, 39), (24, 0, 40), (25, 0, 42), (26, 3, 30), (28, 0, 30), (30, 0, 33), (31, 0, 37)]
GLIDE = 0.28

# doots: a two-bar motif in sixteenths, grouped 3+3+2 (step, MIDI); F# Dorian
DOOT = [(0, 54), (3, 57), (6, 61), (8, 59), (10, 57), (12, 52), (14, 54),
        (16, 54), (19, 57), (22, 59), (24, 61), (26, 64), (28, 59), (30, 57)]


def glide_curve(tc, events, glide):
    y = np.full(len(tc), np.log(HZ(events[0][2])))
    cur = y[0]
    for bar, beat, m in events:
        ts = tb(bar, beat)
        tgt = np.log(HZ(m))
        u = np.clip((tc - ts) / glide, 0, 1)
        e = u * u * (3 - 2 * u)
        sel = tc >= ts
        y[sel] = cur + (tgt - cur) * e[sel]
        cur = tgt
    return np.exp(y)


def womp_curve(tc, mode, depth_db=12.0):
    """Rhythmic swell: each cycle rises from a floor to full and falls back.
    Locked to the grid; mode sets the cycle length."""
    if mode == 'none':
        return np.ones(len(tc))
    cyc = {'bar': BAR, 'half': BAR / 2, 'dotted': 0.75 * BEAT}[mode]
    u = (tc / cyc) % 1
    shape = np.sin(np.pi * np.clip(u / 0.85, 0, 1)) ** 1.3
    floor = 10 ** (-depth_db / 20)
    return floor + (1 - floor) * shape


def drone(tc, f0, cut, amp):
    """Our engine (studies 1-3): three detuned band-limited saws, ladder with
    resonance and drive, f0/2 roughness, tanh; two decorrelated sides above
    150 Hz, mono below."""
    nos, sro = int(len(tc) / CR * SR) * OS, SR * OS
    n = nos // OS
    vs = []
    for v, dc in enumerate([-7.0, 0.0, 6.0]):
        cents = dc + s1.drift(len(tc), CR, 3.5, seed=10 + v)
        vs.append(dsp.saw(s1.up(f0 * 2 ** (cents / 1200), tc, nos, sro), sro, phase=0.31 * v))
    cut_os = s1.up(cut, tc, nos, sro)
    ph = 2 * np.pi * np.cumsum(s1.up(f0, tc, nos, sro) / 2) / sro
    out = []
    for w in ((0.55, 0.3, 0.15), (0.15, 0.3, 0.55)):
        x = sum(a * v for a, v in zip(w, vs))
        b = dsp.ladder(x, cut_os, sro, res=0.42, drive=1.6) * (1 + 0.10 * np.sin(ph))
        out.append(signal.resample_poly(np.tanh(1.3 * b) / np.tanh(1.3), 1, OS)[:n])
    L, R = out
    low = dsp.butter((L + R) / 2, 150, SR, 'low', 4)
    a = s1.up(amp, tc, n, SR)
    L = (low + dsp.butter(L, 150, SR, 'high', 4)) * a
    R = (low + dsp.butter(R, 150, SR, 'high', 4)) * a
    return L, R


def doot(sr, hz, bright):
    """Round pluck: saw + a sub square, lowpass with a quick filter blip,
    amplitude at half after ~0.2 s."""
    t = np.arange(int(0.9 * sr)) / sr
    x = 0.7 * dsp.saw(np.full(len(t), hz), sr) + 0.3 * np.sign(np.sin(np.pi * hz * t))
    cut = 350 + bright * 2200 * np.exp(-t / 0.05) + bright * 500
    y = dsp.ladder(x, cut, sr, res=0.25, drive=1.3)
    env = np.exp(-np.clip(t - 0.01, 0, None) / 0.28) * np.clip(t / 0.002, 0, 1)
    return y * env


def spaghetti(sr, rng):
    """One hat hit as a bundle: 4-7 grains a few ms apart, then a noisy tail."""
    t = np.arange(int(0.35 * sr)) / sr
    x = np.zeros(len(t))
    g = rng.integers(4, 8)
    offs = np.cumsum(rng.uniform(0.0015, 0.006, g)) - 0.0015
    for o in offs:
        i = int(o * sr)
        burst = rng.standard_normal(int(0.0012 * sr)) * rng.uniform(0.5, 1.0)
        x[i:i + len(burst)] += burst
    x += rng.standard_normal(len(t)) * 0.25 * np.exp(-np.clip(t - offs[-1], 0, None) / 0.07) * (t > offs[-1])
    return dsp.butter(dsp.butter(x, (5500, 15000), sr, 'band', 2), 4500, sr, 'high', 2)


def bar_mask(tc, bars, ramp=0.05):
    m = np.zeros(len(tc))
    for b in bars:
        m[(tc >= tb(b)) & (tc < tb(b + 1))] = 1
    k = max(1, int(ramp * CR))
    return np.convolve(m, np.ones(k) / k, mode='same')


def render(womp='half', brk=None, womptest=False):
    t0 = time.time()
    dur = 24.0 if womptest else NBARS * BAR + TAIL
    N = int(dur * SR)
    tc = np.arange(int(dur * CR)) / CR
    bass = BASS if brk != 'wrong-bass' else [(b, bt, m + 1) for b, bt, m in BASS]

    if womptest:
        # 8 s each: half bar, bar, dotted eighth, on a held F#1, filter half open
        f0 = np.full(len(tc), HZ(30))
        w = np.where(tc < 8, womp_curve(tc, 'half'), np.where(tc < 16, womp_curve(tc, 'bar'), womp_curve(tc, 'dotted')))
        cut = 300 + 900 * w
        L, R = drone(tc, f0, cut, 0.9 * w * np.clip(tc / 0.5, 0, 1) * np.clip((dur - tc) / 0.5, 0, 1))
        mix = np.stack([L, R], 1)
        g = 10 ** ((-14 - dsp.lufs(mix, SR)) / 20)
        return dsp.limiter(mix * g, SR, -1.5), {}, [], tc, f0, bass

    # --- the engine ----------------------------------------------------------
    f0 = glide_curve(tc, bass, GLIDE)
    wake = np.clip((tc - tb(DRONE_FROM)) / (2 * BAR), 0, 1)
    opened = np.clip((tc - tb(OPEN_AT - 1)) / (2 * BAR), 0, 1)
    climb = np.clip((tc - tb(19)) / (8 * BAR), 0, 1)
    w = womp_curve(tc, 'none' if brk == 'no-womp' else womp)
    cut = (220 + 500 * wake + 900 * opened + 700 * climb) * (0.45 + 0.55 * w) * (f0 / HZ(30)) ** 0.8
    present = (tc >= tb(DRONE_FROM)) & ~((tc >= tb(PAUSE)) & (tc < tb(PAUSE + 1)))
    pres = np.convolve(present.astype(float), np.ones(40) / 40, mode='same')
    end = np.clip(1 - (tc - tb(NBARS + 1)) / 3.0, 0, 1)
    amp = wake ** 1.5 * w * pres * end
    dL, dR = (np.pad(z, (0, max(0, N - len(z))))[:N] for z in drone(tc, f0, cut, amp))

    # --- doots, their wash ---------------------------------------------------
    doots = np.zeros(N)
    cache = {}
    for bar in DOOTS:
        for st, m in DOOT:
            te = tb(bar) + (st % 16) * BEAT / 4
            if (st >= 16) != ((bar - 1) % 2 == 1):
                continue
            br = 0.35 + 0.65 * float(np.interp(te, tc, opened)) + 0.15 * (st % 8 == 0)
            key = (m, round(br, 2))
            if key not in cache:
                cache[key] = doot(SR, HZ(m), min(br, 1.0))
            s1.place(doots, cache[key], [(te, 0.9 + 0.1 * (st % 3 == 0))], SR)
    doots *= 0.16
    wl = dsp.tapedelay(doots, SR, 0.75 * BEAT, wow_ms=3.5, wow_hz=0.55, fb=0.62, damp_hz=2400, phase=0.0)
    wr = dsp.tapedelay(doots, SR, 1.0 * BEAT, wow_ms=4.0, wow_hz=0.71, fb=0.6, damp_hz=2200, phase=2.0)
    rl, rr = dsp.reverb(wl * 0.8 + doots * 0.2, wr * 0.8 + doots * 0.2, SR, rt60=6.0, damp_hz=3500)
    washL, washR = wl * 0.55 + rl, wr * 0.55 + rr

    # --- drums ---------------------------------------------------------------
    kicks = [tb(b, i) for b in KICK for i in range(4)]
    kick = np.zeros(N)
    s1.place(kick, s3.kick_hit(SR), [(k, 1.0) for k in kicks], SR)
    hatbars = HATS if brk != 'no-strip' else list(range(1, 32))
    rng = np.random.default_rng(5)
    hL, hR = np.zeros(N), np.zeros(N)
    for b in hatbars:
        for i in range(8):
            h = spaghetti(SR, rng)
            g = (0.55, 1.0)[i % 2] * rng.uniform(0.85, 1.0)
            p = 0.5 + rng.uniform(-0.2, 0.2)
            s1.place(hL, h, [(tb(b, i / 2), g * (1 - p))], SR)
            s1.place(hR, h, [(tb(b, i / 2), g * p)], SR)

    # --- mix -----------------------------------------------------------------
    sc = s1.sidechain(kicks, N, SR, 0.6, rel=0.18)
    dL, dR = dL * sc * 0.42, dR * sc * 0.42
    dt = doots * s1.sidechain(kicks, N, SR, 0.25)
    L = kick + dL + dt * 0.95 + washL * 0.5 + hL * 0.5
    R = kick + dR + dt * 1.05 + washR * 0.5 + hR * 0.5
    rL, rR = dsp.reverb(dL * 0.05 + hL * 0.1, dR * 0.05 + hR * 0.1, SR, rt60=2.5, damp_hz=8000)
    L, R = L + rL, R + rR
    mix = np.stack([L, R], 1)
    mix -= mix.mean(0)
    for _ in range(6):
        g = 10 ** ((-10.0 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.2, rel_ms=60)
    print(f'render {time.time() - t0:.1f} s')
    stems = {'kick': kick, 'droneL': dL, 'droneR': dR, 'hats': hL + hR, 'doots': doots}
    return mix, stems, kicks, tc, f0, bass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--womp', default='half', choices=['half', 'bar', 'dotted'])
    ap.add_argument('--womptest', action='store_true')
    ap.add_argument('--break', dest='brk', choices=['no-strip', 'wrong-bass', 'no-womp'])
    a = ap.parse_args()
    mix, stems, kicks, tc, f0, bass = render(a.womp, a.brk, a.womptest)
    name = 'study4_womptest' if a.womptest else 'study4' + (f'_{a.womp}' if a.womp != 'half' else '') + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    if not a.womptest:
        np.savez_compressed(f'out/{name}_stems.npz', sr=SR, tc=tc, f0=f0, **stems)
        with open(f'out/{name}_score.json', 'w') as fh:
            json.dump({'kicks': kicks, 'bass': bass, 'womp': a.womp, 'bpm': BPM}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
