"""Checks for study 4.  python3 checks4.py out/study4   |   --selftest"""
import json
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

import checks
import checks3
import dsp
import study4 as s4


def env(x, sr, lo, hi, rate=1000):
    y = dsp.butter(x, (lo, hi), sr, 'band', 4)
    return signal.resample_poly(np.abs(signal.hilbert(y)), rate, sr)


def strip(mix, sr):
    """The hats really leave: 6-16 kHz in bars 9-12 (doots and wash alone) is
    >= 30 dB under bars 1-8."""
    e = env(mix.mean(1), sr, 6000, 16000) ** 2
    lvl = lambda a, b: 10 * np.log10(e[int(s4.tb(a) * 1000):int(s4.tb(b + 1) * 1000)].mean() + 1e-20)
    d = lvl(1, 8) - lvl(9, 12)
    return d >= 30, f'high band drops {d:.1f} dB in the strip (reference A ~50; need >= 30)'


def bass_pitch(st, sc):
    """Each held bass note is within 25 cents of its target."""
    sr = int(st['sr'])
    x = (st['droneL'] + st['droneR']) / 2
    bass = s4.BASS   # the composed line, not the render's own record
    bad, n = [], 0
    for i, (bar, beat, m) in enumerate(bass):
        a = s4.tb(bar, beat) + s4.GLIDE + 0.15
        b = s4.tb(*bass[i + 1][:2]) - 0.1 if i + 1 < len(bass) else a + 1.5
        if s4.tb(s4.PAUSE) <= a < s4.tb(s4.PAUSE + 1) or b - a < 0.5:
            continue
        seg = x[int(a * sr):int(b * sr)]
        if np.abs(seg).max() < 1e-4:
            continue
        y = signal.resample_poly(seg, 1, 8)
        nf = 1 << 18
        X = np.log(np.abs(np.fft.rfft(y * np.hanning(len(y)), nf)) + 1e-12)
        f = np.fft.rfftfreq(nf, 8 / sr)
        want = s4.HZ(m)
        c = np.linspace(want * 2 ** (-150 / 1200), want * 2 ** (150 / 1200), 601)
        H = [sum(X[int(round(cc * h / f[1]))] for h in (1, 2, 3, 4)) for cc in c]
        got = c[int(np.argmax(H))]
        cents = 1200 * np.log2(got / want)
        n += 1
        if abs(cents) > 25:
            bad.append(f'bar {bar}: {cents:+.0f} c')
    return (not bad and n >= 6), f'{n} held notes' + ('' if not bad else '; off: ' + ', '.join(bad[:4]))


def womp(st, sc):
    """The drone's level pulses at the intended rate, >= 6 dB deep (bars
    13-18: no kick, so no sidechain pumping to confuse it)."""
    sr = int(st['sr'])
    x = (st['droneL'] + st['droneR']) / 2
    a, b = s4.tb(15), s4.tb(19)
    e = env(x[int(a * sr):int(b * sr)], sr, 30, 2000)
    depth = 20 * np.log10(np.percentile(e, 95) / max(np.percentile(e, 10), 1e-9))
    e0 = e - e.mean()
    E = np.abs(np.fft.rfft(e0 * np.hanning(len(e0)), 1 << 17))
    f = np.fft.rfftfreq(1 << 17, 1 / 1000)
    k = (f > 0.3) & (f < 8)
    pk = f[k][np.argmax(E[k])]
    want = {'half': 2 / s4.BAR, 'bar': 1 / s4.BAR, 'dotted': 1 / (0.75 * s4.BEAT)}[sc['womp']]
    ok = abs(pk / want - 1) < 0.1 and depth >= 6
    return ok, f'pulse {pk:.2f} Hz (want {want:.2f}), depth {depth:.1f} dB'


def run(stem):
    sr, mix = wavfile.read(stem + '.wav')
    mix = mix.astype(np.float64)
    st = np.load(stem + '_stems.npz')
    sc = json.load(open(stem + '_score.json'))
    kb = [s4.tb(b) for b in s4.KICK]
    kick_part = np.concatenate([mix[int(t * sr):int((t + s4.BAR) * sr)] for t in kb])
    w = checks3.side_mid(mix, sr, 300, 3000, s4.tb(19), s4.tb(27))
    bm = checks3.side_mid(mix, sr, 30, 100, s4.tb(19), s4.tb(27))
    c = checks3.crest(kick_part, sr)
    L = dsp.lufs(mix, sr)
    res = [('kick on the grid', *checks.kick_sync(st, sc)),
           ('strip', *strip(mix, sr)),
           ('bass line in tune', *bass_pitch(st, sc)),
           ('womp', *womp(st, sc)),
           ('punch (kick bars)', c >= 8, f'median crest {c:.1f} dB (need >= 8)'),
           ('wide above 300 Hz', w >= -10, f'{w:.1f} dB'),
           ('mono bass', bm <= -20, f'{bm:.1f} dB'),
           ('loudness', abs(L + 10) <= 0.6, f'{L:.2f} LUFS')]
    res += [r for r in checks.levels(mix, sr) if r[0] != 'loudness']
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    return {n: ok for n, ok, _ in res}


if __name__ == '__main__':
    if sys.argv[1] == '--selftest':
        for brk, which in (('no-strip', 'strip'), ('wrong-bass', 'bass line in tune'), ('no-womp', 'womp')):
            subprocess.check_call([sys.executable, 'study4.py', '--break', brk], stdout=subprocess.DEVNULL)
            r = run(f'out/study4_BROKEN-{brk}')
            print(f'== {brk}: {which}', 'caught' if not r[which] else 'NOT CAUGHT')
    else:
        r = run(sys.argv[1])
        print('ALL PASS' if all(r.values()) else 'SOME FAIL')
