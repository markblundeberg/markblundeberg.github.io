"""OPUSTEK - Engine, Learning to Sing. The music video (v2).

A patent sheet that comes alive (references: 1890s gas-engine patents, and modern
cutaway drawings with one spot colour). Dark ink on aged paper, shade lines on lower-right
edges, section hatching on cut walls only, italic numerals on leader lines,
five figures on one sheet. One spot colour, the head's heat: true blackbody
colour (Planck x CIE 1931). Everything moves by the score (video/export.py).

v2 acts on three reviews (a patent draftsman, an engineer-physicist, a
music-video editor; see README): hatching only where cut; ink only, no greys;
every part grounded and plumbed; ports in the clearance volume; real
slider-crank proportions; a radiative cooling law (time-compressed); a
finite coast-down; f0/60 against the wagon wheel; the chopper's blades in
phase with the gate; the chopper now chops the head's own radiation into a
thermopile (a chopped radiation pyrometer), so every colour is a blackbody's.

Sheet (3200 x 1800 units): Fig. 1 elevation of the engine on its bed;
Fig. 2 the resonator; Fig. 3 the chopper disc; Fig. 4 the tank in plan;
Fig. 5 the gauge.

  python3 video/film.py [--from T0 --to T1] [--name N]
  FILM_BREAK=no-beam|flat-heat|no-freeze|blade-phase  (for the checks' self-tests)
"""
import argparse
import json
import math
import os
import subprocess
from multiprocessing import Pool

import cairo
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'out', 'video')
W, H, FPS = 1920, 1080, 30
CR = 1000

INK = (0.13, 0.11, 0.10)
PAPER = (0.95, 0.925, 0.855)

C = dict(np.load(os.path.join(OUT, 'curves.npz')))     # read fully before forking
E = json.load(open(os.path.join(OUT, 'events.json')))
TC = C['tc']
BAR, BEAT, DUR = E['bar'], E['beat'], E['dur']
tb = lambda bar, beat=0.0: (bar - 1) * BAR + beat * BEAT
BRK = os.environ.get('FILM_BREAK', '')


def at(name, t):
    return float(np.interp(t, TC, C[name]))


# --- physics -----------------------------------------------------------------

def _g(l, mu, s1, s2):
    s = np.where(l < mu, s1, s2)
    return np.exp(-0.5 * ((l - mu) / s) ** 2)


LAM = np.linspace(380, 780, 401)
CMF = (1.056 * _g(LAM, 599.8, 37.9, 31.0) + 0.362 * _g(LAM, 442.0, 16.0, 26.7) - 0.065 * _g(LAM, 501.1, 20.4, 26.2),
       0.821 * _g(LAM, 568.8, 46.9, 40.5) + 0.286 * _g(LAM, 530.9, 16.3, 31.1),
       1.217 * _g(LAM, 437.0, 11.8, 36.0) + 0.681 * _g(LAM, 459.0, 26.0, 13.8))   # CIE 1931 (Wyman et al. 2013)


def blackbody(T):
    """sRGB colour (max channel 1) and luminance Y of a blackbody at T kelvin."""
    l = LAM * 1e-9
    B = 1 / (l ** 5 * (np.exp(1.4388e-2 / (l * T)) - 1))
    X, Y, Z = (np.trapz(B * c, LAM) for c in CMF)
    rgb = np.clip([3.2406 * X - 1.5372 * Y - 0.4986 * Z, -0.9689 * X + 1.8758 * Y + 0.0415 * Z,
                   0.0557 * X - 0.2040 * Y + 1.0570 * Z], 0, None)
    rgb = rgb / rgb.max()
    gam = lambda c: 12.92 * c if c <= 0.0031308 else 1.055 * c ** (1 / 2.4) - 0.055
    return tuple(gam(c) for c in rgb), Y


T_MAX = 1150.0                         # cherry red: brighter than a working hot bulb's dull red, for the screen
Y_DRAPER, Y_HOT = blackbody(798)[1], blackbody(T_MAX)[1]


def glow(T):
    """Spot colour and strength 0..1: none below the Draper point (~800 K),
    strength the log of visible luminance. Dull heat is a deep, dark red, so
    the colour is darkened as the strength falls (see fig1)."""
    if BRK == 'flat-heat':
        return (1.0, 0.45, 0.1), 0.8
    if T < 798:
        return (0, 0, 0), 0.0
    col, Y = blackbody(T)
    b = float(np.clip((math.log10(Y) - math.log10(Y_DRAPER)) / (math.log10(Y_HOT) - math.log10(Y_DRAPER)), 0, 1))
    return col, b


def heat_curve():
    """The head's temperature: dT/dt = q*HOT - a(T^4 - Ta^4) - b(T - Ta), with
    radiation and convection to a 300 K room. One physical law gives a fast
    rise and a slow dull-red tail. Time-compressed about 100x (a real 25 mm
    cast-iron wall has tau ~ 10 min at 1000 K); a, b give tau ~ 3 s at 1000 K.
    q is set so the hottest moment reaches T_MAX."""
    hot = np.clip(C['env'], 0, 1.5) * (0.35 + 0.8 * C['dc_drive'] + 1.5 * C['dist'] + 0.6 * C['dc_fold']
                                        + 0.3 * C['dc_growl'] + 0.4 * C['dc_squelch'])
    a, b, Ta, dt = 7.7e-11, 0.026, 300.0, 1 / CR

    def run(q):
        T = np.empty_like(hot)
        y = Ta
        for i, h in enumerate(hot):
            y += dt * (q * h - a * (y ** 4 - Ta ** 4) - b * (y - Ta))
            T[i] = y
        return T
    lo, hi = 10.0, 2000.0
    for _ in range(30):
        q = 0.5 * (lo + hi)
        if run(q).max() > T_MAX:
            hi = q
        else:
            lo = q
    return run(lo)


def flywheel_speed():
    """rev/s. Driven at f0/60 while the engine runs (f0/40 strobed: 18.5
    spoke passes/s at the peak, past the 15/s limit at 30 fps; now 12.35).
    Off, it coasts: dw/dt = -w/4 - 0.73 sign(w) (viscous plus bearing
    friction), so it stops in finite time. On, the engine can only push: a
    quiet engine never brakes it harder than friction (v2 did, during chops;
    the engineer's round 2)."""
    on = np.clip(C['env'] * 3, 0, 1)
    drive = C['f0'] / 60.0 * 2 * np.pi
    w = np.empty_like(on)
    y, dt = 0.0, 1 / CR
    on = np.convolve(on, np.ones(int(BEAT * CR)) / int(BEAT * CR), mode='same')   # over a beat
    for i in range(len(on)):
        brake = -(y / 4.0 + (0.73 if y > 0 else 0.0))
        push = (drive[i] * on[i] - y) / 0.4 if on[i] > 0.05 else brake
        y = max(0.0, y + dt * max(push, brake))      # the engine only pushes; friction is the only brake
        w[i] = y
    return w / (2 * np.pi)


TEMP = heat_curve()
SPEED = flywheel_speed()
THETA = 2 * np.pi * np.cumsum(SPEED) / CR


# --- the clock of the film: the pause freezes it ------------------------------

PAUSE = (tb(56), tb(57))


def film_t(t):
    if BRK != 'no-freeze' and PAUSE[0] <= t < PAUSE[1]:
        return PAUSE[0]
    return t


# --- camera ------------------------------------------------------------------

FIG = {'sheet': (1600, 900, 0.6), 'f1': (1060, 800, 0.97), 'f1close': (1180, 790, 1.3),
       'head': (1400, 770, 1.5), 'flywheel': (640, 860, 1.4), 'f2': (2580, 500, 1.45),
       'f3pair': (2250, 1020, 1.4), 'f4': (760, 1500, 1.7), 'f5': (1580, 1480, 1.9), 'f1x': (1180, 800, 0.8)}
# (bar, beats, target). Beats 0 is a cut, on the beat (big jumps between
# figures); smooth moves only where they can stay under ~30 px a frame.
CAM = [(1, 0, 'sheet'),
       (9, 0, 'f1'),               # cut on the first kick
       (16.5, 3, 'f1close'),       # the engine wakes: barrel, head, valve, resonator
       (25, 0, 'f2'),              # the sync voice starts learning
       (31, 0, 'f1'),
       (39.75, 0, 'f3pair'),       # a beat before the tresillo chop: head, rays, both views of the disc
       (41, 0, 'f1'),
       (43.75, 0, 'f3pair'),
       (46, 0, 'head'),            # the engine's last bars, then it cools and ticks
       (52, 0, 'f4'),              # the first doot back: one ring in the tank
       (53, 0, 'f1'),              # the engine wakes
       (54.75, 0, 'f3pair'),       # the chop that chokes it into the pause
       (57, 0, 'sheet'),           # the drop
       (61, 0, 'f2'), (65, 0, 'f1'), (69, 0, 'head'),
       (71.75, 0, 'f3pair'),       # the chop that prises it open
       (73, 0, 'flywheel'),        # the octave climb
       (75, 4, 'f1'),
       (78.75, 0, 'f3pair'),
       (81, 0, 'f5'),
       (83, 0, 'head'),            # the outro's tinks
       (87, 8, 'sheet'), (91, 6, 'f1'),
       (96, 8, 'f1x')]             # pull back while it comes apart


def smoother(u):
    u = min(max(u, 0.0), 1.0)
    return u * u * u * (u * (6 * u - 15) + 10)


def camera(t):
    cur = FIG['sheet']
    for bar, beats, name in CAM:
        s = tb(bar)
        d = max(beats * BEAT, 1e-3)
        tgt = FIG[name]
        if t >= s:
            e = smoother((t - s) / d) if beats else 1.0
            cur = tuple(a + (b - a) * e for a, b in zip(cur, tgt))
    x, y, z = cur
    tt = film_t(t)
    x += 14 * math.sin(tt * 0.21)
    y += 9 * math.sin(tt * 0.17 + 1)
    sx = sy = 0.0
    if tb(57) <= t < tb(81):
        for k in E['kicks']:
            d = t - k
            if 0 <= d < 0.12:
                a = 3.0 * math.exp(-d / 0.035)
                sx += a * math.sin(k * 91.7)
                sy += a * math.cos(k * 53.3)
    return x, y, z, sx, sy


def to_screen(t, X, Y):
    x, y, z, sx, sy = camera(t)
    return (X - x) * z + W / 2 + sx, (Y - y) * z + H / 2 + sy


# --- ink -----------------------------------------------------------------------

def ink(cx, w=2.2, a=1.0, col=INK):
    cx.set_source_rgba(*col, a)
    cx.set_line_width(w)
    cx.set_line_cap(cairo.LINE_CAP_ROUND)
    cx.set_line_join(cairo.LINE_JOIN_ROUND)


def line(cx, x0, y0, x1, y1, w=2.2, a=1.0):
    cx.new_path()
    ink(cx, w, a)
    cx.move_to(x0, y0)
    cx.line_to(x1, y1)
    cx.stroke()


def rect(cx, x, y, w, h, lw=2.2, shade=True, fill=False):
    """Light from the upper left: the lower and right edges carry a heavier
    shade line."""
    cx.new_path()
    if fill:
        cx.rectangle(x, y, w, h)
        cx.set_source_rgba(*PAPER, 1)
        cx.fill()
    ink(cx, lw)
    cx.move_to(x + w, y)
    cx.line_to(x, y)
    cx.line_to(x, y + h)
    cx.stroke()
    ink(cx, lw * (2.1 if shade else 1.0))
    cx.move_to(x, y + h)
    cx.line_to(x + w, y + h)
    cx.line_to(x + w, y)
    cx.stroke()


def circle(cx, x, y, r, lw=2.2, shade=True, fill=False):
    cx.new_path()
    if fill:
        cx.arc(x, y, r, 0, 2 * math.pi)
        cx.set_source_rgba(*PAPER, 1)
        cx.fill()
    ink(cx, lw)
    cx.arc(x, y, r, 0, 2 * math.pi)
    cx.stroke()
    if shade:
        ink(cx, lw * 2.1)
        cx.arc(x, y, r, -math.pi / 4, 3 * math.pi / 4)
        cx.stroke()


def poly(cx, pts, lw=2.2, fill=True, close=True):
    cx.new_path()
    cx.move_to(*pts[0])
    for p in pts[1:]:
        cx.line_to(*p)
    if close:
        cx.close_path()
    if fill:
        cx.set_source_rgba(*PAPER, 1)
        cx.fill_preserve()
    ink(cx, lw)
    cx.stroke()


def hatch(cx, path_fn, step=10, lw=1.1, ang=45, a=0.9):
    """Section hatching, only on cut surfaces, clipped to them."""
    cx.save()
    cx.new_path()
    path_fn()
    cx.clip()
    x0, y0, x1, y1 = cx.clip_extents()
    ink(cx, lw, a)
    d = (x1 - x0) + (y1 - y0)
    k = math.tan(math.radians(ang))
    for o in np.arange(-d, d, step):
        cx.move_to(x0 + o, y1)
        cx.line_to(x0 + o + (y1 - y0) / k, y0)
    cx.stroke()
    cx.restore()


def pipe(cx, pts, r=5, lw=1.4):
    """A pipe drawn double (axis-aligned runs), with a fitting at each bend."""
    for sgn in (-1, 1):
        cx.new_path()
        for i, (x, y) in enumerate(pts):
            ox = oy = 0.0
            for j in (i - 1, i):
                if 0 <= j < len(pts) - 1:
                    dx, dy = pts[j + 1][0] - pts[j][0], pts[j + 1][1] - pts[j][1]
                    n = math.hypot(dx, dy) or 1
                    if abs(dx) > abs(dy):
                        oy = sgn * r
                    else:
                        ox = sgn * r
            (cx.move_to if i == 0 else cx.line_to)(x + ox, y + oy)
        ink(cx, lw)
        cx.stroke()
    for (x, y) in pts[1:-1]:
        rect(cx, x - r - 3, y - r - 3, 2 * r + 6, 2 * r + 6, 1.4, shade=False, fill=True)


def font(cx, size, italic=False, bold=False, face='FreeSerif'):
    cx.select_font_face(face, cairo.FONT_SLANT_ITALIC if italic else cairo.FONT_SLANT_NORMAL,
                        cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
    cx.set_font_size(size)


def text(cx, s, x, y, size, italic=False, bold=False, center=False, face='FreeSerif', a=1.0):
    cx.new_path()
    font(cx, size, italic, bold, face)
    cx.set_source_rgba(*INK, a)
    if center:
        e = cx.text_extents(s)
        x -= e.width / 2 + e.x_bearing
    cx.move_to(x, y)
    cx.show_text(s)
    cx.new_path()


def numeral(cx, n, x, y, tx, ty):
    """A reference numeral on a fine curved leader that touches its part."""
    cx.new_path()
    ink(cx, 1.2)
    mx, my = (x + tx) / 2 + (ty - y) * 0.12, (y + ty) / 2 - (tx - x) * 0.12
    cx.move_to(tx, ty)
    cx.curve_to(mx, my, mx, my, x, y)
    cx.stroke()
    text(cx, str(n), tx + (8 if tx >= x else -26), ty + 8, 30, italic=True)


def fig_label(cx, s, x, y, size=46):
    text(cx, s, x, y, size, italic=True, bold=True)


# --- the sheet -------------------------------------------------------------------

def header(cx):
    text(cx, '(No Model.)', 150, 120, 26)
    text(cx, 'OPUSTEK.', 1600, 110, 38, center=True)
    text(cx, 'ENGINE, LEARNING TO SING.', 1600, 165, 30, center=True)
    text(cx, 'No. 4.', 150, 200, 54, bold=True)
    text(cx, 'Patented Oct. 15, 2026.', 2620, 200, 34)
    text(cx, 'Application filed Oct. 14, 2026.', 1600, 205, 22, center=True, italic=True)


def signatures(cx):
    x, y = 2180, 1600
    text(cx, 'Witnesses:', x - 1000, y - 8, 30, italic=True)
    text(cx, 'a spectrogram', x - 960, y + 42, 34, face='Z003')
    text(cx, 'Mark Lundeberg', x - 960, y + 86, 34, face='Z003')          # the ears
    text(cx, 'Inventor:', x + 440, y - 8, 30, italic=True)
    text(cx, 'Opustek', x + 470, y + 50, 50, face='Z003')
    text(cx, 'drawn and played in code', x + 430, y + 92, 26, face='Z003')


def make_paper():
    """The sheet's own paper, fixed to the sheet (it moves with the camera):
    toned from its four edges, a little foxing, fibre grain that also dithers
    the tone so it cannot band."""
    w, h = 1600, 900                                   # half resolution, scaled 2x
    rng = np.random.default_rng(7)
    yy, xx = np.mgrid[0:h, 0:w]
    edge = np.minimum.reduce([xx, w - 1 - xx, yy, h - 1 - yy]).astype(float)
    tone = np.clip(1 - edge / 140, 0, 1) ** 1.6 * 0.10
    fox = np.zeros((h, w))
    for _ in range(26):
        cxp = rng.uniform(0, w)
        cyp = rng.uniform(0, 120) if rng.uniform() < 0.5 else rng.uniform(h - 120, h)
        r = rng.uniform(1.5, 4)
        fox += 0.035 * np.exp(-((xx - cxp) ** 2 + (yy - cyp) ** 2) / (2 * r * r))
    grain = rng.normal(0, 0.012, (h, w))
    dark = np.clip(tone + fox + grain, -0.03, 0.25)
    base = np.array(PAPER)
    rgb = np.clip(base[None, None, :] * (1 - dark[..., None]) - (dark + 2 * fox)[..., None] * np.array([0.0, 0.05, 0.12]), 0, 1)
    buf = np.zeros((h, w, 4), np.uint8)
    buf[..., 0] = (rgb[..., 2] * 255).astype(np.uint8)
    buf[..., 1] = (rgb[..., 1] * 255).astype(np.uint8)
    buf[..., 2] = (rgb[..., 0] * 255).astype(np.uint8)
    buf[..., 3] = 255
    surf = cairo.ImageSurface.create_for_data(memoryview(buf), cairo.FORMAT_ARGB32, w, h, w * 4)
    return surf, buf


PAPER_SURF, _PAPER_BUF = make_paper()


def sheet_paper(cx):
    cx.save()
    cx.scale(2, 2)
    cx.set_source_surface(PAPER_SURF, 0, 0)
    cx.get_source().set_filter(cairo.FILTER_BILINEAR)
    cx.rectangle(0, 0, 1600, 900)
    cx.fill()
    cx.restore()


def sheet_border(cx):
    rect(cx, 60, 60, 3080, 1680, 2.4, shade=False)


# --- Fig. 1 geometry (sheet units) ---------------------------------------------------

FW = (640, 860, 300)                 # flywheel centre and radius
RC, LROD = 140, 566                  # crank radius, rod length pin to pin: stroke 280, L/r 4
PIN_OFF, PW = 46, 150                # wrist pin from the piston's skirt end; piston length
CYL = (980, 740, 620, 240)           # barrel; its axis (860) lines up with the crank centre
WALL = 34
HEAD_X, HEAD = 1600, (1600, 700, 110, 320)   # the head: TDC crown 1450, clearance 150, CR ~2.9
GROUND = 1266
BASE = (320, 1180, 1900, 40)         # the bed, long enough to carry the chopper and thermopile
TUBE1 = (1060, 470, 1820, 34)        # resonator on the machine
CH1 = (1960, 935, 150)               # chopper disc (edge-on in Fig. 1); its beam line is y = 827
RECV_X = 2100                        # thermopile receiver
GAUGE1 = (420, 400, 70)
TANK1 = (150, 1146, 140, 120)        # drip pan on the floor, left of the bed
DRIP = (220, 1118, 1175)             # drain cock x, spout y, water surface y
MM_PER_UNIT = 2.0                    # the drawing's scale (34 cm bore, 1.2 m flywheel)
JACKET = (1000, 1440, 24, 16)        # jacket x0, x1, water space, outer wall
HOPPER = (1060, 1400, 600, 14)       # open-topped hopper over the jacket: x0, x1, top y, wall
PORTS = {'gauge': 1470, 'valve': 1520, 'feed': 1565}   # on the barrel, in the clearance volume (crown TDC 1450)
BULB = (1785, 860, 58)               # the hot bulb on the head: the one thing that glows
BOLTS = [(1460, 760), (1460, 960), (1580, 760), (1580, 960), (1622, 730), (1622, 990), (1690, 730), (1690, 990)]

EXPLODE = {'flywheel': (-260, 0), 'cylinder': (0, 0), 'head': (190, 0), 'piston': (90, 0), 'tube': (0, -170),
           'chopper': (110, 0), 'gauge': (-120, -120), 'valve': (0, -120), 'base': (0, 0), 'tank': (0, 0)}


def explode_k(t):
    return smoother((t - tb(96)) / 4.0)


def off(part, t):
    k = explode_k(t)
    dx, dy = EXPLODE.get(part, (0, 0))
    return dx * k, dy * k


def crank(th):
    """Crank pin and wrist pin positions (true slider-crank, axes aligned)."""
    fx, fy, R = FW
    cpx, cpy = fx + RC * math.cos(th), fy + RC * math.sin(th)
    wx = fx + RC * math.cos(th) + math.sqrt(LROD ** 2 - (RC * math.sin(th)) ** 2)
    return cpx, cpy, wx


def fig1(cx, t, ft):
    T = float(np.interp(ft, TC, TEMP))
    col, gb = glow(T)
    th = float(np.interp(ft, TC, THETA))
    omega = 2 * math.pi * float(np.interp(ft, TC, SPEED))
    smear = omega * 0.5 / FPS                     # radians swept while a 180-degree shutter is open
    fx, fy, R = FW
    bx, by, bw, bh = CYL
    hox = off('head', t)[0]
    jx0, jx1, ws, jw = JACKET
    # ground: a solid line at the feet, short strokes below
    line(cx, 70, GROUND, 2240, GROUND, 2.2)
    cx.new_path()
    ink(cx, 1.0)
    for k in range(70, 2226, 26):
        cx.move_to(k, GROUND + 8)
        cx.line_to(k + 14, GROUND + 20)
    cx.stroke()
    # drain from the jacket's bottom to the cock over the drip pan (the hopper's
    # head drives it, so it can drip above the pan)
    pipe(cx, [(jx0 + 30, by + bh + ws + jw), (jx0 + 30, 1168), (BASE[0] - 10, 1168), (BASE[0] - 10, 1095),
              (DRIP[0], 1095), (DRIP[0], DRIP[1] - 8)], 4)
    rect(cx, DRIP[0] - 10, DRIP[1] - 12, 20, 12, 1.6, fill=True)              # the drain cock
    line(cx, DRIP[0] - 16, DRIP[1] - 18, DRIP[0] + 16, DRIP[1] - 22, 2.0)    # its handle
    # the bed (a cut section: hatched) and its feet
    x, y, w, h = BASE
    hatch(cx, lambda: cx.rectangle(x, y, w, h), 12)
    rect(cx, x, y, w, h)
    for fxp in (x + 40, x + w - 120):
        rect(cx, fxp, y + h, 80, GROUND - (y + h), fill=True)
    # drip pan on the floor
    tx, ty, tw, th_ = TANK1
    rect(cx, tx, ty, tw, th_, 2.2, fill=True)
    cx.save()
    cx.set_dash([12, 6])
    line(cx, tx + 6, DRIP[2], tx + tw - 6, DRIP[2], 1.2)
    cx.restore()
    drip(cx, ft, DRIP[0], DRIP[1], DRIP[2])
    # barrel feet, seated on the jacket's outer wall, down to the bed
    for fxp in (1060, 1340):
        poly(cx, [(fxp, by + bh + ws + jw), (fxp + 60, by + bh + ws + jw), (fxp + 80, y), (fxp - 20, y)], 2.2)
    # the flywheel's A-frame pedestal, behind the wheel, up to the main bearing
    fox_ = off('flywheel', t)[0]
    X, Y = fx + fox_, fy
    poly(cx, [(X - 150, y), (X - 34, Y + 12), (X + 34, Y + 12), (X + 150, y)], 2.4)
    line(cx, X - 92, y, X - 20, Y + 40, 1.2)
    line(cx, X + 92, y, X + 20, Y + 40, 1.2)
    # flywheel: rim and hub opaque, spokes; spun arcs once they'd be 3 spacings long
    cx.new_path()
    cx.arc(X, Y, R, 0, 2 * math.pi)
    cx.new_sub_path()
    cx.arc_negative(X, Y, R - 34, 2 * math.pi, 0)
    cx.set_source_rgba(*PAPER, 1)
    cx.fill()
    circle(cx, X, Y, R, 2.6)
    circle(cx, X, Y, R - 34, 1.8, shade=False)
    spun = smear > 0.15
    for k in range(6):
        a = th + k * math.pi / 3
        for o in (-0.06, 0.06):
            line(cx, X + 62 * math.cos(a + o * 2), Y + 62 * math.sin(a + o * 2),
                 X + (R - 34) * math.cos(a + o * 0.35), Y + (R - 34) * math.sin(a + o * 0.35), 2.0)
        if spun:
            cx.new_path()
            ink(cx, 0.8)
            for rr in np.arange(76, R - 40, 9):
                cx.new_sub_path()
                cx.arc(X, Y, rr, a - smear, a)
            cx.stroke()
    cw = th + math.pi
    cx.new_path()
    cx.arc(X, Y, R - 34, cw - 0.7, cw + 0.7)
    cx.arc_negative(X, Y, R - 95, cw + 0.7, cw - 0.7)
    cx.close_path()
    cx.set_source_rgba(*PAPER, 1)
    cx.fill_preserve()
    ink(cx, 1.8)
    cx.stroke()
    cx.new_path()
    ink(cx, 3.6)
    cx.arc(X, Y, R - 95, cw - 0.7, cw + 0.7)
    cx.stroke()
    if spun:
        cx.new_path()
        ink(cx, 0.8)
        for rr in np.arange(R - 90, R - 38, 7):
            cx.new_sub_path()
            cx.arc(X, Y, rr, cw - 0.7 - smear, cw - 0.7)
        cx.stroke()
    # crank: a web between two bosses (shaft boss r 44, pin boss r 22), then the shaft
    cpx, cpy, wx = crank(th)
    rbx, rby = cpx, cpy                      # the rod's big end: on the crank pin until it comes apart
    cpx += fox_
    pox = off('piston', t)[0]
    wx += pox
    rbx += pox                               # the rod is rigid and leaves with the piston
    ang = math.atan2(cpy - Y, cpx - X)
    nx_, ny_ = -math.sin(ang), math.cos(ang)
    poly(cx, [(X + 44 * nx_, Y + 44 * ny_), (cpx + 22 * nx_, cpy + 22 * ny_),
              (cpx - 22 * nx_, cpy - 22 * ny_), (X - 44 * nx_, Y - 44 * ny_)], 2.0)
    circle(cx, X, Y, 44, 2.0, fill=True)
    circle(cx, X, Y, 20, 1.8, shade=False)
    # water jacket around the barrel: outer wall cut (hatched), water space open; the
    # hopper rises from it, open-topped (the hit-and-miss engine's arrangement)
    for (yy, hh) in ((by - ws - jw, jw), (by + bh + ws, jw)):
        hatch(cx, lambda yy=yy, hh=hh: cx.rectangle(jx0, yy, jx1 - jx0, hh), 10)
        rect(cx, jx0, yy, jx1 - jx0, hh, 2.0)
    for xe in (jx0, jx1 - jw):
        for (yy, hh) in ((by - ws - jw, ws + jw), (by + bh, ws + jw)):
            hatch(cx, lambda xe=xe, yy=yy, hh=hh: cx.rectangle(xe, yy, jw, hh), 10)
            rect(cx, xe, yy, jw, hh, 1.6, shade=False)
    hx0, hx1, htop, hwl = HOPPER
    jtop = by - ws - jw
    cx.new_path()
    cx.rectangle(hx0 + hwl, htop, hx1 - hx0 - 2 * hwl, jtop - htop + jw)
    cx.set_source_rgba(*PAPER, 1)
    cx.fill()                                        # the opening from the hopper into the jacket
    for xe in (hx0, hx1 - hwl):
        hatch(cx, lambda xe=xe: cx.rectangle(xe, htop, hwl, jtop - htop), 10)
        rect(cx, xe, htop, hwl, jtop - htop, 2.0)
    cx.save()
    cx.set_dash([14, 7])
    line(cx, hx0 + hwl + 4, htop + 24, hx1 - hwl - 4, htop + 24, 1.2)       # water surface
    cx.restore()
    steam(cx, ft, T, (hx0 + hx1) / 2, htop)
    # the barrel in section: walls cut (hatched), bore open
    for (yy, hh) in ((by, WALL), (by + bh - WALL, WALL)):
        hatch(cx, lambda yy=yy, hh=hh: cx.rectangle(bx, yy, bw, hh), 10)
    rect(cx, bx, by, bw, bh, 2.6)
    line(cx, bx, by + WALL, bx + bw, by + WALL, 1.8)
    line(cx, bx, by + bh - WALL, bx + bw, by + bh - WALL, 1.8)
    # ports through the barrel's top wall, in the clearance volume: passages cut in the section
    for px_ in PORTS.values():
        cx.new_path()
        cx.rectangle(px_ - 7, by - 1, 14, WALL + 2)
        cx.set_source_rgba(*PAPER, 1)
        cx.fill()
        line(cx, px_ - 7, by, px_ - 7, by + WALL, 1.6)
        line(cx, px_ + 7, by, px_ + 7, by + WALL, 1.6)
    # rod, drawn after the barrel's walls so it shows in the open bore
    ra = math.atan2(860 - rby, wx - rbx)
    rnx, rny = -math.sin(ra), math.cos(ra)
    poly(cx, [(rbx + 15 * rnx, rby + 15 * rny), (wx + 10 * rnx, 860 + 10 * rny),
              (wx - 10 * rnx, 860 - 10 * rny), (rbx - 15 * rnx, rby - 15 * rny)], 2.0)
    circle(cx, cpx, cpy, 22, 2.0, fill=True)
    circle(cx, cpx, cpy, 8, 1.4, shade=False)
    if abs(rbx - cpx) > 1:                   # apart: the big end's own eye, empty, on a centre line from its pin
        circle(cx, rbx, rby, 22, 2.0, fill=True)
        circle(cx, rbx, rby, 9, 1.4, shade=False)
        cx.save()
        cx.new_path()
        ink(cx, 1.2, 0.8 * explode_k(t))
        cx.set_dash([26, 7, 4, 7])
        cx.move_to(cpx - 40, cpy)
        cx.line_to(rbx + 40, rby)
        cx.stroke()
        cx.restore()
    # piston: not cut, drawn whole with its rings, on its wrist pin
    px = wx - PIN_OFF
    rect(cx, px, by + WALL + 3, PW, bh - 2 * WALL - 6, 2.2, fill=True)
    for k in (26, 42, 58):
        line(cx, px + PW - k, by + WALL + 3, px + PW - k, by + bh - WALL - 3, 1.2)
    circle(cx, wx, 860, 14, 1.8, shade=False, fill=True)
    # the head, cut, and the hot bulb on it: the bulb carries the heat, the one spot colour
    hx, hy, hw, hh = HEAD
    hx += hox
    hatch(cx, lambda: cx.rectangle(hx, hy, 34, hh), 10)
    rect(cx, hx, hy, hw, hh, 2.6)
    for k in range(6):
        line(cx, hx + 46 + k * 11, hy, hx + 46 + k * 11, hy + hh, 1.6)
    bxc, byc, br = BULB
    bxc += hox
    rect(cx, hx + hw, byc - 22, bxc - br - (hx + hw) + 6, 44, 2.0, fill=True)    # the neck
    circle(cx, bxc, byc, br, 2.6, fill=True)
    if gb > 0:
        cx.save()
        cx.set_operator(cairo.OPERATOR_MULTIPLY)
        dark = 0.55 + 0.45 * gb                     # dull heat is a deep, dark red
        cx.set_source_rgba(col[0] * dark, col[1] * dark, col[2] * dark, 0.35 + 0.6 * gb)
        cx.arc(bxc, byc, br - 2, 0, 2 * math.pi)
        cx.fill()
        cx.rectangle(hx + hw, byc - 21, bxc - br - (hx + hw) + 6, 42)
        cx.fill()
        cx.restore()
        circle(cx, bxc, byc, br, 2.6)
    for bxp, byp in BOLTS:
        circle(cx, bxp + (hox if bxp > 1590 else 0), byp, 7, 1.6, fill=True)
    tinks(cx, ft, hox, col)
    # gauge on its pipe (over the hopper, under the tube, clear of the wheel)
    gox, goy = off('gauge', t)
    gx, gy, gr = GAUGE1
    pipe(cx, [(gx, gy + gr), (gx, 540), (PORTS['gauge'], 540), (PORTS['gauge'], by)], 4)   # stays on its port
    gauge(cx, ft, gx + gox, gy + goy, gr)
    # relief valve on its port
    vox, voy = off('valve', t)
    vx, vy = PORTS['valve'], by + voy
    rect(cx, vx - 5, vy - 26, 10, 26, 1.6, fill=True)
    rect(cx, vx - 16, vy - 66, 32, 40, 2.0, fill=True)
    line(cx, vx - 28, vy - 66, vx + 28, vy - 66, 3.0)
    puffs(cx, t, vx, vy - 72)
    # resonator on its feed
    tox_, toy_ = off('tube', t)
    pipe(cx, [(PORTS['feed'], by), (PORTS['feed'], TUBE1[1] + TUBE1[3])], 4)          # stays on its port
    resonator(cx, ft, TUBE1[0] + tox_, TUBE1[1] + toy_, TUBE1[2] + tox_, TUBE1[3])
    # the chopper, edge-on, and the thermopile: the bulb's radiation, chopped
    chx, chy, chr_ = CH1
    cox = off('chopper', t)[0]
    chopper_edge(cx, ft, chx + cox, chy, chr_, bxc + br, col, gb, cox)
    if explode_k(t) < 0.05:
        numeral(cx, 1, fx - 225, fy - 200, fx - 330, fy - 290)
        numeral(cx, 2, 1200, by + bh + ws + jw, 1260, by + bh + 130)
        numeral(cx, 3, 1700, TUBE1[1] - TUBE1[3], 1760, TUBE1[1] - 140)
        numeral(cx, 4, chx + 6, chy + 100, chx + 60, chy + 190)
        numeral(cx, 5, gx + 50, gy - 50, gx + 140, gy - 150)
        numeral(cx, 6, vx + 16, vy - 50, vx + 90, vy - 130)
        numeral(cx, 7, tx + tw, ty + 20, tx + tw + 60, ty - 70)
        numeral(cx, 8, bxc + 30, byc - br + 8, bxc + 90, byc - br - 80)
        numeral(cx, 9, RECV_X + 70, 827 - 30, RECV_X + 120, 827 - 110)
        numeral(cx, 10, hx0 + 20, htop, hx0 - 40, htop - 70)
    else:
        exploded_lines(cx, t)
    fig_label(cx, 'Fig. 1.' if explode_k(t) < 0.5 else 'Fig. 1, exploded.', 190, 1340)
    return col, gb


def steam(cx, t, T, x, y):
    """Over a hot engine the open hopper steams: a few ink curls, full ink,
    more of them the hotter the bulb (a hopper-cooled engine boils)."""
    n = int(np.clip((T - 900) / 80, 0, 4))
    for k in range(n):
        ph = (t * 0.6 + k * 0.37) % 1.0
        x0 = x - 90 + k * 60
        cx.new_path()
        ink(cx, 1.4)
        cx.move_to(x0, y - 6)
        for j in range(1, 13):
            u = j / 12
            cx.line_to(x0 + 10 * math.sin(6 * u + k + t * 2), y - 6 - u * 70 * (0.4 + ph))
        cx.stroke()


def tinks(cx, t, hox, col):
    """The metal plucks: the hot end ticking as it contracts. A burst of short
    ink ticks at a bolt, at full ink, the strokes shrinking as it fades."""
    for tk, m in E['ks']:
        d = t - tk
        if 0 <= d < 0.4:
            bx, by_ = BOLTS[(m * 7 + int(tk * 10)) % len(BOLTS)]
            bx += hox if bx > 1590 else 0
            a = math.exp(-d / 0.12)
            r0 = 14 + 24 * (1 - a)
            r1 = r0 + 40 * a
            if r1 - r0 < 4:
                continue
            for k in range(8):
                ang = k * math.pi / 4 + 0.3
                line(cx, bx + r0 * math.cos(ang), by_ + r0 * math.sin(ang), bx + r1 * math.cos(ang), by_ + r1 * math.sin(ang), 1.6)


def exploded_lines(cx, t):
    """Dash-dot centre lines from each part's home to where it has moved."""
    k = explode_k(t)
    homes = {'flywheel': FW[:2], 'head': (HEAD_X + 55, 860), 'tube': ((TUBE1[0] + TUBE1[2]) / 2, TUBE1[1]),
             'chopper': CH1[:2], 'gauge': GAUGE1[:2], 'valve': (PORTS['valve'], CYL[1] - 46), 'piston': (1300, 860)}
    cx.save()
    cx.new_path()
    ink(cx, 1.2, 0.8 * k)
    cx.set_dash([26, 7, 4, 7])
    for part, (hx, hy) in homes.items():
        dx, dy = off(part, t)
        if abs(dx) + abs(dy) < 2:
            continue
        cx.move_to(hx - 0.15 * dx, hy - 0.15 * dy)
        cx.line_to(hx + 1.15 * dx, hy + 1.15 * dy)
        cx.stroke()
    cx.restore()


def puffs(cx, t, x, y):
    """The relief valve lifts on the clap: ink curls that shorten as they go."""
    for c in E['claps']:
        d = t - c
        if 0 <= d < 0.4:
            a = 1 - d / 0.4
            for s in (-1, 0, 1):
                cx.new_path()
                ink(cx, 1.6)
                cx.move_to(x + s * 10, y - 140 * d)
                cx.curve_to(x + s * 18, y - 140 * d - 20 * a, x + s * 4, y - 140 * d - 40 * a, x + s * 14, y - 140 * d - 60 * a)
                cx.stroke()


def gauge(cx, t, x, y, r):
    k = sum(math.exp(-(t - tk) / 0.16) for tk in E['kicks'] if 0 <= t - tk < 1.0)
    a = math.radians(-215 + 250 * min(k, 1.0) * 0.85)
    circle(cx, x, y, r, 2.4, fill=True)
    circle(cx, x, y, r - 10, 1.0, shade=False)
    for j in range(11):
        aa = math.radians(-215 + 25 * j)
        line(cx, x + (r - 22) * math.cos(aa), y + (r - 22) * math.sin(aa), x + (r - 12) * math.cos(aa), y + (r - 12) * math.sin(aa), 1.4)
    line(cx, x, y, x + (r - 24) * math.cos(a), y + (r - 24) * math.sin(a), 3.0)
    circle(cx, x, y, 6, 1.6, shade=False)


def resonator(cx, t, x0, y, x1, hh, detail=False):
    """Glass, drawn in ink (reflection dashes are the glass convention). The
    wave crests on every beat: its true rate is audio, so any visible rate is
    an alias, and the beat is the honest one to choose."""
    lvl = float(np.clip(at('blend', t) * at('env', t) * 2.4, 0, 1))
    n = int(round(np.clip(at('ratio', t), 1, 22)))
    line(cx, x0, y - hh, x1, y - hh, 2.0)
    line(cx, x0, y + hh, x1, y + hh, 4.0)
    for ex in (x0, x1):
        cx.save()
        cx.new_path()
        cx.translate(ex, y)
        cx.scale(12, hh)
        cx.arc(0, 0, 1, 0, 2 * math.pi)
        cx.restore()
        ink(cx, 2.0)
        cx.stroke()
    for k in (0.3, 0.42):
        line(cx, x0 + 30 + (x1 - x0) * k, y - hh + 7, x0 + 70 + (x1 - x0) * k, y - hh + 7, 1.0)
    if lvl > 0.01:
        A = (hh - 6) * lvl
        ph = math.cos(2 * math.pi * t / BEAT)
        for sgn in (1, -1):
            cx.new_path()
            cx.move_to(x0, y)
            for k in range(0, 401):
                u = k / 400
                cx.line_to(x0 + u * (x1 - x0), y + sgn * A * ph * math.sin(n * math.pi * u))
            ink(cx, 2.0 if detail else 1.5)
            cx.stroke()
    for k in range(n + 1):
        cx.new_path()
        cx.arc(x0 + k / n * (x1 - x0), y, 5 if detail else 3, 0, 2 * math.pi)
        cx.set_source_rgba(*INK, 1)
        cx.fill()
    return n


def current_chop(t):
    for i, (bar, beats, per, d0, d1, pat) in enumerate(E['chops']):
        t0 = (bar - 1) * BAR
        if t0 - 1.0 <= t < t0 + beats * BEAT + 0.6:
            return i, t0, beats, per
    return None, None, None, None


def chop_state(t):
    """Disc phase (revolutions), the 16 sectors' open fractions, whether the
    pyrometer is live, the gate now, and cells (sectors) per second."""
    i, t0, beats, per = current_chop(t)
    N = 16
    if i is None:
        return 0.03 * t, [1.0] * N, 0.0, 0.0, 0.0
    cell = BEAT / per
    p = (t - t0) / cell
    mine = [c for c in E['chop_cells'] if t0 - 1e-6 <= c[0] < t0 + beats * BEAT - 1e-6]
    rev = int(max(p, 0) // N)
    sec = []
    for k in range(N):
        j = rev * N + k
        if p < 0:
            sec.append(1.0)                          # before the chop: no cell has started, all open
        elif j < len(mine):
            a, o, e = mine[j]
            sec.append((o - a) / (e - a))
        else:
            sec.append(1.0)
    live = float(np.clip((t - (t0 - 0.6)) / 0.4, 0, 1) * np.clip((t0 + beats * BEAT + 0.6 - t) / 0.4, 0, 1))
    gate = at('chop', t)
    if BRK == 'no-beam':
        gate = 1.0
    return p / N, sec, live, gate, per / BEAT


def sector_angle(rot, k, N=16):
    """Start angle of sector k. The aperture is at the top (-pi/2), and sector
    k sits under it when the phase says cell k. (v1 put it half a sector off,
    which the engineer's review found; FILM_BREAK=blade-phase brings it back.)"""
    a0 = rot - math.pi / 2 + k * 2 * math.pi / N
    return a0 - (math.pi / N if BRK == 'blade-phase' else 0.0)


def rays(cx, x0, x1, y, a, col, gb, converge=False):
    """Radiation, the patent way: three fine long-dash rays with an arrowhead
    at mid-span, converging into the thermopile's cone when they reach it. A
    flat tint of the bulb's colour under them only while it glows."""
    if gb > 0:
        cx.save()
        cx.new_path()
        cx.set_source_rgba(*col, 0.4 * a * gb)
        cx.move_to(x0, y - 16)
        cx.line_to(x1, y - (6 if converge else 16))
        cx.line_to(x1, y + (6 if converge else 16))
        cx.line_to(x0, y + 16)
        cx.close_path()
        cx.fill()
        cx.restore()
    sgn = 1 if x1 > x0 else -1
    for o in (-14, 0, 14):
        o1 = o * (0.35 if converge else 1.0)
        cx.save()
        cx.set_dash([22, 8])
        line(cx, x0, y + o, x1, y + o1, 1.1)
        cx.restore()
        mx, my = (x0 + x1) / 2, y + (o + o1) / 2
        cx.new_path()
        ink(cx, 1.3)
        cx.move_to(mx - sgn * 10, my - 5)
        cx.line_to(mx, my)
        cx.line_to(mx - sgn * 10, my + 5)
        cx.stroke()


def chopper_edge(cx, t, x, y, R, source_x, col, gb, cox=0.0):
    """Fig. 1: the disc edge-on on its motor. The bulb's radiation crosses to
    the disc, and on to the thermopile (9) only through an open slot."""
    phase, sec, live, gate, rate = chop_state(t)
    by = y - R * 0.72
    rx = RECV_X + cox
    if live > 0:
        rays(cx, source_x + 6, x - 8, by, live, col, gb)
        if gate > 0.5:
            rays(cx, x + 8, rx - 2, by, live, col, gb, converge=True)
    rect(cx, x - 6, y - R, 12, 2 * R, 2.2, fill=True)
    rect(cx, x + 6, y - 22, 26, 44, 2.0, fill=True)
    rect(cx, x + 32, y - 55, 90, 110, 2.4, fill=True)
    for k in range(1, 5):
        line(cx, x + 32 + k * 18, y - 55, x + 32 + k * 18, y + 55, 1.0)
    poly(cx, [(x + 40, y + 55), (x + 114, y + 55), (x + 134, BASE[1]), (x + 20, BASE[1])], 2.2)
    # the thermopile: a collecting cone facing the disc, on a column down to the bed
    poly(cx, [(rx, by - 18), (rx + 34, by - 30), (rx + 34, by + 30), (rx, by + 18)], 2.0)
    rect(cx, rx + 34, by - 30, 46, 60, 2.2, fill=True)
    rect(cx, rx + 50, by + 30, 14, BASE[1] - by - 30, 1.8, fill=True)
    return by


def chopper_face(cx, t, ft, x, y, R):
    """Fig. 3: the disc face-on, seen from the bulb's side. The radiation goes
    into the page at the aperture (circle and cross) toward the thermopile
    behind (hidden: dashed). Blades are the gate's closed cells, with surface
    lines (not cut). Cells faster than 12 a second are drawn spun, in rings:
    sectors that fast would strobe at 30 fps."""
    phase, sec, live, gate, rate = chop_state(ft)
    N = 16
    rot = -2 * math.pi * phase
    by = y - R * 0.72
    circle(cx, x, y, R, 2.6, fill=True)
    if rate > 12:
        cx.new_path()
        ink(cx, 0.8)
        for rr in np.arange(52, R - 4, 6):
            cx.new_sub_path()
            cx.arc(x, y, rr, 0, 2 * math.pi)
        cx.stroke()
    else:
        for k in range(N):
            a0 = sector_angle(rot, k, N)
            a_open = a0 + sec[k] * 2 * math.pi / N
            a1 = a0 + 2 * math.pi / N
            if sec[k] < 0.999:
                mid = 0.5 * (a_open + a1)
                cx.save()
                cx.new_path()
                cx.move_to(x + 42 * math.cos(a_open), y + 42 * math.sin(a_open))
                cx.arc(x, y, R, a_open, a1)
                cx.arc_negative(x, y, 42, a1, a_open)
                cx.close_path()
                cx.clip()
                cx.new_path()
                ink(cx, 0.8)
                ux, uy = math.cos(mid), math.sin(mid)
                for o in np.arange(-R, R, 7):
                    cx.move_to(x - uy * o, y + ux * o)
                    cx.line_to(x - uy * o + ux * R, y + ux * o + uy * R)
                cx.stroke()
                cx.restore()
                line(cx, x + 42 * math.cos(a_open), y + 42 * math.sin(a_open), x + R * math.cos(a_open), y + R * math.sin(a_open), 1.6)
            line(cx, x + 42 * math.cos(a0), y + 42 * math.sin(a0), x + R * math.cos(a0), y + R * math.sin(a0), 1.0)
    circle(cx, x, y, R, 2.6)
    circle(cx, x, y, 42, 2.0, fill=True)
    circle(cx, x, y, 12, 1.6, shade=False)
    # hidden lines, drawn over the disc: the pedestal up to the hub, the thermopile behind
    cx.save()
    cx.set_dash([10, 6])
    for sxp in (-26, 26):
        line(cx, x + sxp, y + R + 8, x + sxp * 0.6, y + 42, 1.4)
    if live > 0:
        cx.new_path()
        ink(cx, 1.4)
        cx.rectangle(x - 46, by - 46, 92, 92)
        cx.stroke()
    cx.restore()
    T = float(np.interp(ft, TC, TEMP))
    col, gb = glow(T)
    if live > 0 and gate > 0.5 and gb > 0:
        cx.save()
        cx.new_path()
        cx.set_source_rgba(*col, 0.6 * gb)             # a flat tint, hard-edged, like a print plate
        cx.arc(x, by, 28, 0, 2 * math.pi)
        cx.fill()
        cx.restore()
    circle(cx, x, by, 15, 1.8, shade=False, fill=True)
    line(cx, x - 10, by - 10, x + 10, by + 10, 1.6)
    line(cx, x - 10, by + 10, x + 10, by - 10, 1.6)
    poly(cx, [(x - 40, y + R + 8), (x + 40, y + R + 8), (x + 26, y + R + 95), (x - 26, y + R + 95)], 2.2)
    return by


def drip(cx, t, x, y0, y1):
    """A drop leaves the drain cock from rest and falls freely at g (at the
    drawing's 2 mm a unit), landing on each doot."""
    fall_m = (y1 - y0) * MM_PER_UNIT / 1000
    T = math.sqrt(2 * fall_m / 9.81)
    for td, m, v in E['doots']:
        d = td - t
        if 0 < d <= T:
            yy = y1 - (y1 - y0) * (1 - (1 - d / T) ** 2)
            cx.new_path()
            cx.move_to(x, yy - 14)
            cx.curve_to(x + 2, yy - 8, x + 6, yy - 5, x + 6, yy - 1)
            cx.arc(x, yy - 1, 6, 0, math.pi)
            cx.curve_to(x - 6, yy - 5, x - 2, yy - 8, x, yy - 14)
            cx.set_source_rgba(*INK, 1)
            cx.fill()


# --- the detail figures ----------------------------------------------------------------



def fig2(cx, t, ft):
    x0, y, x1, hh = 2150, 520, 3040, 70
    n = resonator(cx, ft, x0, y, x1, hh, detail=True)
    fig_label(cx, 'Fig. 2.', 2150, 380)
    text(cx, f'n = {n}', 2900, 400, 34, italic=True)
    numeral(cx, 3, 2500, y - hh, 2560, y - hh - 90)


def fig3(cx, t, ft):
    x, y, R = 2560, 1130, 290
    chopper_face(cx, t, ft, x, y, R)
    fig_label(cx, 'Fig. 3.', 2860, 1530)
    numeral(cx, 4, x + 205, y + 205, x + 280, y + 280)


def fig4(cx, t, ft):
    """The drip pan in plan: each drop rings out from under the cock; rings
    thin as they fade (full ink: a patent has one ink)."""
    x, y, r = 760, 1500, 165
    circle(cx, x, y, r, 2.6, fill=True)
    circle(cx, x, y, r - 18, 1.4, shade=False)
    circle(cx, x, y, 7, 1.4, shade=False)
    cx.save()
    cx.new_path()
    cx.arc(x, y, r - 18, 0, 2 * math.pi)
    cx.clip()
    for td, m, v in E['doots']:
        if v < 0.85 and not tb(49) <= td < tb(57):
            continue
        for dt, g in ((0, 1.0), (0.5 * BEAT, 0.6), (BEAT, 0.35)):
            d = ft - td - dt
            if 0 <= d < 1.6:
                lw = 1.8 * v * g * (1 - d / 1.6)
                if lw < 0.4:
                    continue
                cx.new_path()
                ink(cx, lw)
                cx.arc(x, y, 10 + 110 * d, 0, 2 * math.pi)
                cx.stroke()
    cx.restore()
    fig_label(cx, 'Fig. 4.', 440, 1400)
    numeral(cx, 7, x + 150, y - 70, x + 240, y - 90)


def fig5(cx, t, ft):
    x, y, r = 1580, 1480, 120
    gauge(cx, ft, x, y, r)
    text(cx, 'P', x - 10, y + 60, 30, italic=True)
    fig_label(cx, 'Fig. 5.', 1300, 1400)
    numeral(cx, 5, x + 102, y - 63, x + 180, y - 80)


# --- the intro: the sheet is inked part by part ------------------------------------------

REVEAL = ['header', 'border', 'fig1', 'fig2', 'fig3', 'fig4', 'fig5', 'sign']




def reveal_times():
    acc = [td for td, m, v in E['doots'] if td < tb(8.5) and v > 0.85]
    acc = acc[::max(1, len(acc) // len(REVEAL))][:len(REVEAL)]
    while len(acc) < len(REVEAL):
        acc.append(tb(8))
    return dict(zip(REVEAL, acc))


RT = reveal_times()


def revealed(name, t, cx, bbox):
    u = (t - RT[name]) / 0.9
    if u <= 0:
        return False
    if u < 1:
        x0, y0, x1, y1 = bbox
        cx.rectangle(x0, y0, (x1 - x0) * smoother(u), y1 - y0)
        cx.clip()
    return True


# --- a frame -----------------------------------------------------------------------

def draw(t, path):
    ft = film_t(t)
    s = cairo.ImageSurface(cairo.FORMAT_RGB24, W, H)
    cx = cairo.Context(s)
    cx.set_source_rgb(*[c * 0.9 for c in PAPER])        # the desk beyond the sheet's edge
    cx.paint()
    x, y, z, sx, sy = camera(t)
    cx.save()
    cx.translate(W / 2 + sx, H / 2 + sy)
    cx.scale(z, z)
    cx.translate(-x, -y)
    sheet_paper(cx)
    parts = [('header', (0, 60, 3200, 230), header), ('border', (0, 0, 3200, 1800), sheet_border),
             ('fig1', (60, 300, 2350, 1420), lambda c: fig1(c, t, ft)), ('fig2', (2100, 330, 3100, 650), lambda c: fig2(c, t, ft)),
             ('fig3', (2100, 760, 3100, 1580), lambda c: fig3(c, t, ft)), ('fig4', (400, 1340, 1300, 1700), lambda c: fig4(c, t, ft)),
             ('fig5', (1250, 1340, 1900, 1700), lambda c: fig5(c, t, ft)), ('sign', (1100, 1560, 3100, 1730), signatures)]
    for name, bbox, fn in parts:
        cx.new_path()
        cx.save()
        if revealed(name, t, cx, bbox):
            fn(cx)
        cx.restore()
    cx.restore()
    a = max(0.0, 1 - t / 0.6) + max(0.0, (t - (DUR - 1.5)) / 1.5)
    if a > 0:
        cx.set_source_rgba(*PAPER, min(a, 1))
        cx.paint()
    s.write_to_png(path)


def job(args):
    k, t0, fr = args
    draw(t0 + k / FPS, os.path.join(fr, f'{k:05d}.png'))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--from', dest='t0', type=float, default=0.0)
    ap.add_argument('--to', dest='t1', type=float, default=DUR)
    ap.add_argument('--name', default='film')
    ap.add_argument('--workers', type=int, default=4)
    a = ap.parse_args()
    fr = os.path.join(OUT, a.name + '_frames')
    os.makedirs(fr, exist_ok=True)
    for f in os.listdir(fr):
        os.remove(os.path.join(fr, f))
    n = int(round((a.t1 - a.t0) * FPS))
    with Pool(a.workers) as p:
        p.map(job, [(k, a.t0, fr) for k in range(n)], chunksize=16)
    wav = os.path.join(OUT, '..', 'piece4.wav')
    mp4 = os.path.join(OUT, a.name + '.mp4')
    subprocess.check_call(['ffmpeg', '-v', 'error', '-y', '-framerate', str(FPS), '-i', os.path.join(fr, '%05d.png'),
                           '-ss', str(a.t0), '-t', str(a.t1 - a.t0), '-i', wav, '-map', '0:v', '-map', '1:a',
                           '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-preset', 'slow',
                           '-c:a', 'aac', '-b:a', '256k', '-shortest', mp4])
    print('wrote', mp4, n, 'frames')


if __name__ == '__main__':
    main()
