"""Review kit facts, generated from what the film is actually driven by
(events.json and the curves), not from intentions in comments: the editor's
review found the timeline said "one note at 97.6 s" where the events had
nothing until 100.24 s.

  python3 video/kit.py   -> out/video/review_kit/TIMELINE.md, state.csv
"""
import csv
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import film

K = os.path.join(film.OUT, 'review_kit')
os.makedirs(K, exist_ok=True)
SECTIONS = [(1, 'intro'), (9, 'groove'), (17, 'engine wakes'), (33, 'engine solo'), (49, 'seam: engine stops'),
            (51, 'breakdown'), (53, 'engine wakes again'), (56, 'pause'), (57, 'drop / climax'),
            (73, 'octave climb'), (75, 'climax'), (81, 'outro'), (93, 'switch-off'), (96, 'tail, exploded view')]


def count(ts, a, b):
    return sum(1 for t in ts if a <= t < b)


def main():
    E, tb = film.E, film.tb
    L = ['# Timeline, generated from the exported events and curves (video/kit.py)', '',
         '123 bpm, 1 bar = 1.951 s. Counts are real onsets in each section.', '',
         '| from (s) | bar | section | doots | kicks | claps | tinks | sync level max | head T max (K) | flywheel max (rev/s) |',
         '|---|---|---|---|---|---|---|---|---|---|']
    doots = [d[0] for d in E['doots']]
    tinks = [k[0] for k in E['ks']]
    for i, (bar, name) in enumerate(SECTIONS):
        a = tb(bar)
        b = tb(SECTIONS[i + 1][0]) if i + 1 < len(SECTIONS) else film.DUR
        m = (film.TC >= a) & (film.TC < b)
        lvl = np.clip(film.C['blend'][m] * film.C['env'][m] * 2.4, 0, 1).max()
        L.append(f'| {a:6.1f} | {bar} | {name} | {count(doots, a, b)} | {count(E["kicks"], a, b)} | {count(E["claps"], a, b)} | '
                 f'{count(tinks, a, b)} | {lvl:.2f} | {film.TEMP[m].max():.0f} | {film.SPEED[m].max():.2f} |')
    L += ['', '## First doots after the seam', '']
    after = [t for t in doots if t >= tb(49)][:8]
    L.append(', '.join(f'{t:.2f}' for t in after))
    L += ['', '## Chops', '']
    for bar, beats, per, d0, d1, pat in E['chops']:
        rate = per / film.BEAT
        L.append(f'- {tb(bar):6.1f} s (bar {bar}): {beats} beats, {rate:.1f} cells/s, '
                 f'{"spun (drawn as rings)" if rate > 12 else "bladed"}')
    L += ['', '## Camera (cuts on beats; smooth moves under 30 px/frame)', '']
    for bar, beats, name in film.CAM:
        L.append(f'- {tb(bar):6.1f} s (bar {bar}): {"cut" if beats == 0 else f"{beats}-beat move"} to {name}')
    open(os.path.join(K, 'TIMELINE.md'), 'w').write('\n'.join(L) + '\n')
    # per-frame driven state
    with open(os.path.join(K, 'state.csv'), 'w', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['t', 'film_t', 'T_K', 'rev_s', 'crank_deg', 'gate', 'sector_under_aperture_open', 'sync_n',
                    'sync_level', 'cam_x', 'cam_y', 'cam_z'])
        for k in range(int(film.DUR * film.FPS)):
            t = k / film.FPS
            ft = film.film_t(t)
            phase, sec, live, gate, rate = film.chop_state(ft)
            under = ''
            if live > 0 and rate <= 12:
                rot = -2 * math.pi * phase
                for j in range(16):
                    a0 = film.sector_angle(rot, j)
                    u = (-math.pi / 2 - a0) % (2 * math.pi)
                    if u < 2 * math.pi / 16:
                        under = int(u < sec[j] * 2 * math.pi / 16)
                        break
            cx_, cy_, cz, _, _ = film.camera(t)
            w.writerow([f'{t:.3f}', f'{ft:.3f}', f'{np.interp(ft, film.TC, film.TEMP):.0f}',
                        f'{np.interp(ft, film.TC, film.SPEED):.3f}', f'{math.degrees(np.interp(ft, film.TC, film.THETA)) % 360:.1f}',
                        f'{gate:.2f}', under, int(round(np.clip(film.at("ratio", ft), 1, 22))),
                        f'{np.clip(film.at("blend", ft) * film.at("env", ft) * 2.4, 0, 1):.2f}', f'{cx_:.0f}', f'{cy_:.0f}', f'{cz:.3f}'])
    print('wrote TIMELINE.md and state.csv')


if __name__ == '__main__':
    main()
