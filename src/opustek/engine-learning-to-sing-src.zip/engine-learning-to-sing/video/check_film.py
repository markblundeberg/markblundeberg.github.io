"""Checks on the film. Frame checks read rendered pixels; the geometry check
compares the drawn mechanism with the audio itself (a check on what the
mechanism produces can pass a mechanism drawn wrong).

  python3 video/check_film.py FRAMES_DIR T0        frame checks + geometry + camera
  python3 video/check_film.py --selftest-camera | --selftest-geometry

  spark:    the spark is drawn at the gap in exactly the frames that catch a
            gate opening, and never two frames from one (>= 95%)
  strobe:   in those frames the piston is drawn solid at the crank angle of
            the spark's instant (its crown a continuous line, >= 85% of its
            length, in >= 90% of sampled frames), and in the next frame that
            line is no longer solid (back to phantom)
  flash:    no more than 3 general flashes a second (WCAG 2.3.1: a flash is a
            pair of opposing changes of relative luminance >= 0.1, the darker
            below 0.8, over >= 25% of any 640 x 360 window); the same for
            saturated red
  heat:     the hot bulb's most saturated pixel has a blackbody hue at the model
            temperature (median within 2 degrees) and its saturation follows
            the glow strength (r >= 0.6), when T > 950 K
  freeze:   the one-bar pause holds still
  geometry: the drawn blade under the aperture agrees with the gate (>= 95%) in
            every chop the disc is drawn bladed (not spun)
  camera:   smooth moves under 30 px a frame; cuts on beats
"""
import colorsys
import math
import os
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import film

FPS = film.FPS


def frame(fr, t0, t):
    k = int(round((t - t0) * FPS))
    p = os.path.join(fr, f'{k:05d}.png')
    return np.asarray(Image.open(p).convert('RGB')).astype(float) / 255 if os.path.exists(p) else None


def onscreen(t, X, Y, m=8):
    x, y = film.to_screen(t, X, Y)
    return (x, y) if (m <= x < film.W - m and m <= y < film.H - m) else None


def darkness(im, x, y, r=1):
    px = im[int(y) - r:int(y) + r + 1, int(x) - r:int(x) + r + 1].mean(axis=(0, 1))
    return 1 - px.mean()


def engine_screen(t, X, Y):
    return onscreen(t, *film.engine_point(t, X, Y))


def spark(fr, t0, t1):
    gx, gy, g = film.GAP
    ok = n = 0
    marks = set(int(ts * FPS + 1e-9) for ts in film.E_SPARKS if t0 <= ts < t1)
    cands = [(k, True) for k in marks] + [(k + 2, False) for k in marks if k + 2 not in marks and k + 1 not in marks]
    for k, want in cands:
        tt = k / FPS
        im = frame(fr, t0, tt)
        if im is None:
            continue
        pts = [onscreen(tt, X, Y) for X in range(gx - 10, gx + 11, 2) for Y in range(gy - 8, gy + 9, 4)]
        pts = [p for p in pts if p]
        if len(pts) < 20:
            continue
        d = max(darkness(im, x, y, r=0) for x, y in pts)
        n += 1
        ok += ((d > 0.35) == want)
    return n > 10 and ok >= 0.95 * n, f'{ok}/{n} frames: spark drawn exactly when one is caught'


def strobe(fr, t0, t1):
    ok = n = 0
    later = 0
    edges = (1020, 1170, 1300, 1450)
    for ts in film.E_SPARKS:
        if not (t0 <= ts < t1):
            continue
        k = int(ts * FPS + 1e-9)
        tt = k / FPS
        if not film.running(tt):
            continue
        c = film.crown(film.theta_at(ts))
        if min(abs(c - e) for e in edges) < 25:
            continue
        pts = [engine_screen(tt, c, Y) for Y in range(800, 925, 5)]
        if not all(pts):
            continue
        im = frame(fr, t0, tt)
        im2 = frame(fr, t0, tt + 1 / FPS)
        if im is None or im2 is None:
            continue
        dark = np.mean([max(darkness(im, x + dx, y, r=0) for dx in (-2, -1, 0, 1, 2)) > 0.3 for x, y in pts])
        pts2 = [engine_screen(tt + 1 / FPS, c, Y) for Y in range(800, 925, 5)]
        dark2 = np.mean([max(darkness(im2, x + dx, y, r=0) for dx in (-2, -1, 0, 1, 2)) > 0.3 for x, y in pts2 if (x, y)])
        n += 1
        ok += dark >= 0.85
        # back to phantom: no solid line there (a dashed ghost landing near the same place covers ~80%;
        # the solid crown covers >= 85%)
        later += (dark2 < 0.85 or film.spark_in_frame(tt + 1 / FPS) is not None)
    return n >= 10 and ok >= 0.9 * n and later >= 0.9 * n, f'{ok}/{n} spark frames show the crown solid at the spark angle; {later}/{n} next frames back to phantom'


def _lum(path):
    im = np.asarray(Image.open(path).convert('RGB')).astype(float) / 255
    lin = np.where(im <= 0.04045, im / 12.92, ((im + 0.055) / 1.055) ** 2.4)
    Y = lin @ np.array([0.2126, 0.7152, 0.0722])
    s = im.sum(2) + 1e-9
    red = (im[..., 0] / s >= 0.8) & (im[..., 0] > 0.5)
    h, w = Y.shape
    B = 20
    Yb = Y[:h // B * B, :w // B * B].reshape(h // B, B, w // B, B).mean((1, 3))
    Rb = red[:h // B * B, :w // B * B].reshape(h // B, B, w // B, B).mean((1, 3)) > 0.5
    return Yb, Rb


def flash(fr, t0, t1, workers=4):
    from multiprocessing import Pool
    files = sorted(os.listdir(fr))
    with Pool(workers) as p:
        L = p.map(_lum, [os.path.join(fr, f) for f in files], chunksize=32)
    wy, wx = 18, 32                                    # 640 x 360 px window in 20 px blocks
    trans_g, trans_r = [], []
    for i in range(1, len(L)):
        (y0, r0), (y1, r1) = L[i - 1], L[i]
        dY = y1 - y0
        dark = np.minimum(y0, y1) < 0.8
        sg = sr = 0
        # an area changing one way: lines that merely move brighten some blocks and darken their
        # neighbours in the same frame (the engine rocking at close zoom), which is motion, not a flash
        for sign, m in ((1, (dY >= 0.1) & dark), (-1, (dY <= -0.1) & dark), (0, r0 != r1)):
            cs = np.pad(m.astype(float).cumsum(0).cumsum(1), ((1, 0), (1, 0)))
            win = cs[wy:, wx:] - cs[:-wy, wx:] - cs[wy:, :-wx] + cs[:-wy, :-wx]
            if (win >= 0.25 * wy * wx).any():
                if sign:
                    sg = sign
                else:
                    sr = 1
        trans_g.append(sg)
        trans_r.append(sr)

    def worst(tr):
        ev, last = [], 0
        for i, s_ in enumerate(tr):
            if s_ and s_ == -last:
                ev.append(i)                           # a flash: this transition opposes the last
            if s_:
                last = s_
        return max((sum(1 for e in ev if a <= e < a + FPS) for a in range(0, len(tr), 5)), default=0)
    g = worst(trans_g)
    r = max((sum(trans_r[a:a + FPS]) // 2 for a in range(0, len(trans_r), 5)), default=0)   # two red changes make a red flash
    return g <= 3 and r <= 3, f'most flashes in any second: general {g}, red {r} (limit 3)'


def heat(fr, t0, t1):
    errs, sats, strength, n = [], [], [], 0
    for tt in np.arange(t0 + 0.5, t1, 0.25):
        T = float(np.interp(film.film_t(tt), film.TC, film.TEMP))
        if T < 950:
            continue
        im = frame(fr, t0, tt)
        if im is None:
            continue
        p = engine_screen(tt, film.BULB[0] + film.off('head', tt)[0] + 20, film.BULB[1])
        if not p:
            continue
        x, y = p
        px = im[int(y) - 3:int(y) + 4, int(x) - 3:int(x) + 4].reshape(-1, 3)
        px = px[np.argmax(px.max(1) - px.min(1))]
        h = colorsys.rgb_to_hsv(*px)[0] * 360
        want = film.blackbody(T)[0]
        w = np.array(want) * np.array(film.PAPER)
        hw = colorsys.rgb_to_hsv(*w)[0] * 360
        errs.append(abs((h - hw + 180) % 360 - 180))
        sats.append(colorsys.rgb_to_hsv(*px)[1])
        strength.append(math.log10(film.blackbody(T)[1]) - math.log10(film.Y_DRAPER))
        n += 1
    if n < 5:
        return False, 'too few hot frames sampled'
    e = np.array(errs)
    r = np.corrcoef(sats, strength)[0, 1]
    return np.median(e) <= 2.0 and r >= 0.6, f'{n} hot frames, median hue error {np.median(e):.1f} deg; saturation follows temperature r = {r:.2f}'


def freeze(fr, t0, t1):
    a, b = film.PAUSE
    if not (t0 <= a and b <= t1):
        return True, 'pause not in range'
    f1, f2 = frame(fr, t0, a + 0.1), frame(fr, t0, b - 0.1)
    d = np.abs(f1 - f2).mean()
    return d < 0.004, f'mean change across the pause {d:.4f}'


def geometry():
    """For each chop drawn with blades: is the blade under the aperture (the
    top, -pi/2) open exactly when the gate is open?"""
    res = []
    for bar, beats, per, d0, d1, pat in film.E['chops']:
        t0 = film.tb(bar)
        agree, n = 0, 0
        for t in np.arange(t0 - 0.55, t0 + beats * film.BEAT - 0.005, 0.004):   # includes the lead-in
            phase, sec, live, gate, rate = film.chop_state(t)
            if rate > 12:
                break                                # drawn spun: no blades to be wrong
            rot = -2 * math.pi * phase
            for k in range(16):
                a0 = film.sector_angle(rot, k)
                u = (-math.pi / 2 - a0) % (2 * math.pi)
                if u < 2 * math.pi / 16:
                    drawn_open = u < sec[k] * 2 * math.pi / 16
                    break
            n += 1
            agree += (drawn_open == (gate > 0.5))
        if n:
            res.append(round(100 * agree / n))
    return all(r >= 95 for r in res) and len(res) > 0, f'blade under the aperture matches the gate: {res} % (bladed chops)'


def camera_smooth(cam_list=None):
    if cam_list is not None:
        film.CAM = cam_list
    ts = np.arange(0, film.DUR, 1 / FPS)
    cam = np.array([film.camera(t)[:3] for t in ts])
    d = np.hypot(np.diff(cam[:, 0]) * cam[1:, 2], np.diff(cam[:, 1]) * cam[1:, 2]) + np.abs(np.diff(cam[:, 2])) / cam[1:, 2] * 1000
    cuts = [film.tb(b) for b, bt, n in film.CAM if bt == 0]
    sm = [d[i] for i in range(len(d)) if min(abs(ts[i + 1] - c) for c in cuts) > 0.04]
    on_beat = all(abs((c / film.BEAT) - round(c / film.BEAT)) < 1e-6 for c in cuts)
    return max(sm) <= 30 and on_beat, f'fastest smooth move {max(sm):.1f} px/frame; {len(cuts)} cuts, all on beats: {on_beat}'


if __name__ == '__main__':
    if sys.argv[1] == '--selftest-camera':
        bad = [c if c[0] != 52 else (51.5, 2, 'f4') for c in film.CAM]
        r = camera_smooth(bad)
        print('whip pan:', 'caught' if not r[0] else 'NOT CAUGHT', r[1])
        sys.exit(0)
    if sys.argv[1] == '--selftest-geometry':
        r = geometry()
        print(f"blade-phase ({film.BRK or 'no break'}):", 'FAIL' if not r[0] else 'pass', r[1])
        sys.exit(0)
    fr, t0 = sys.argv[1], float(sys.argv[2])
    t1 = t0 + len(os.listdir(fr)) / FPS
    res = [('spark when the gate opens', *spark(fr, t0, t1)), ('strobe freezes the crank', *strobe(fr, t0, t1)),
           ('no flashing (WCAG 2.3.1)', *flash(fr, t0, t1)), ('heat is blackbody', *heat(fr, t0, t1)),
           ('pause freezes', *freeze(fr, t0, t1)), ('geometry matches the audio', *geometry()),
           ('camera smooth', *camera_smooth())]
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    print('ALL PASS' if all(r[1] for r in res) else 'SOME FAIL')
