"""Checks on the film (v2). Frame checks read rendered pixels; the geometry
check compares the drawn mechanism with the audio, which the beam check can't
(the engineer's review found the v1 disc half a sector out of phase, and the
beam check passed it by construction).

  python3 video/check_film.py FRAMES_DIR T0        frame checks + geometry + camera
  python3 video/check_film.py --selftest-camera | --selftest-geometry

  beam:     between the disc and the thermopile (Fig. 1), the ink rays are there
            exactly when the gate is open (>= 90% of samples)
  heat:     the hot bulb's most saturated pixel has a blackbody hue at the model
            temperature (median within 2 degrees) and its saturation follows
            the glow strength (r >= 0.6), when T > 950 K
  freeze:   the one-bar pause holds still
  geometry: the drawn blade under the aperture agrees with the gate (>= 95%) in
            every chop the disc is drawn bladed (not spun)
  camera:   smooth moves under 30 px a frame; cuts on beats
"""
import colorsys
import math
import os
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import film

FPS = film.FPS


def frame(fr, t0, t):
    k = int(round((t - t0) * FPS))
    p = os.path.join(fr, f'{k:05d}.png')
    return np.asarray(Image.open(p).convert('RGB')).astype(float) / 255 if os.path.exists(p) else None


def onscreen(t, X, Y, m=8):
    x, y = film.to_screen(t, X, Y)
    return (x, y) if (m <= x < film.W - m and m <= y < film.H - m) else None


def darkness(im, x, y, r=1):
    px = im[int(y) - r:int(y) + r + 1, int(x) - r:int(x) + r + 1].mean(axis=(0, 1))
    return 1 - px.mean()


def beam(fr, t0, t1):
    """Fig. 1: along the middle ray between the disc and the thermopile, ink is
    there exactly when the gate is open (the rays are long-dashed, so the
    darkest pixel along the run is taken)."""
    ok, n = 0, 0
    by = film.CH1[1] - film.CH1[2] * 0.72
    for a, o, e in film.E['chop_cells']:
        for tt, want in (((a + o) / 2, True), ((o + e) / 2, False)):
            if not (t0 <= tt < t1) or (o - a < 0.03 and want) or (e - o < 0.03 and not want):
                continue
            im = frame(fr, t0, tt)
            if im is None:
                continue
            cox = film.off('chopper', tt)[0]
            xs = np.arange(film.CH1[0] + cox + 30, film.RECV_X + cox - 20, 3)
            pts = [onscreen(tt, X, by) for X in xs]
            pts = [p for p in pts if p]
            if len(pts) < 8:
                continue
            d = max(darkness(im, x, y, r=0) for x, y in pts)
            base = np.median([darkness(im, x, y - 30, r=0) for x, y in pts])
            lit = d - base > 0.25
            n += 1
            ok += (lit == want)
    return n > 0 and ok >= 0.9 * n, f'{ok}/{n} beam samples match the gate'


def heat(fr, t0, t1):
    errs, sats, strength, n = [], [], [], 0
    for tt in np.arange(t0 + 0.5, t1, 0.25):
        T = float(np.interp(film.film_t(tt), film.TC, film.TEMP))
        if T < 950:
            continue
        im = frame(fr, t0, tt)
        if im is None:
            continue
        p = onscreen(tt, film.BULB[0] + film.off('head', tt)[0] + 20, film.BULB[1])
        if not p:
            continue
        x, y = p
        px = im[int(y) - 3:int(y) + 4, int(x) - 3:int(x) + 4].reshape(-1, 3)
        px = px[np.argmax(px.max(1) - px.min(1))]
        h = colorsys.rgb_to_hsv(*px)[0] * 360
        want = film.blackbody(T)[0]
        w = np.array(want) * np.array(film.PAPER)
        hw = colorsys.rgb_to_hsv(*w)[0] * 360
        errs.append(abs((h - hw + 180) % 360 - 180))
        sats.append(colorsys.rgb_to_hsv(*px)[1])
        strength.append(math.log10(film.blackbody(T)[1]) - math.log10(film.Y_DRAPER))
        n += 1
    if n < 5:
        return False, 'too few hot frames sampled'
    e = np.array(errs)
    r = np.corrcoef(sats, strength)[0, 1]
    return np.median(e) <= 2.0 and r >= 0.6, f'{n} hot frames, median hue error {np.median(e):.1f} deg; saturation follows temperature r = {r:.2f}'


def freeze(fr, t0, t1):
    a, b = film.PAUSE
    if not (t0 <= a and b <= t1):
        return True, 'pause not in range'
    f1, f2 = frame(fr, t0, a + 0.1), frame(fr, t0, b - 0.1)
    d = np.abs(f1 - f2).mean()
    return d < 0.004, f'mean change across the pause {d:.4f}'


def geometry():
    """For each chop drawn with blades: is the blade under the aperture (the
    top, -pi/2) open exactly when the gate is open?"""
    res = []
    for bar, beats, per, d0, d1, pat in film.E['chops']:
        t0 = film.tb(bar)
        agree, n = 0, 0
        for t in np.arange(t0 - 0.55, t0 + beats * film.BEAT - 0.005, 0.004):   # includes the lead-in
            phase, sec, live, gate, rate = film.chop_state(t)
            if rate > 12:
                break                                # drawn spun: no blades to be wrong
            rot = -2 * math.pi * phase
            for k in range(16):
                a0 = film.sector_angle(rot, k)
                u = (-math.pi / 2 - a0) % (2 * math.pi)
                if u < 2 * math.pi / 16:
                    drawn_open = u < sec[k] * 2 * math.pi / 16
                    break
            n += 1
            agree += (drawn_open == (gate > 0.5))
        if n:
            res.append(round(100 * agree / n))
    return all(r >= 95 for r in res) and len(res) > 0, f'blade under the aperture matches the gate: {res} % (bladed chops)'


def camera_smooth(cam_list=None):
    if cam_list is not None:
        film.CAM = cam_list
    ts = np.arange(0, film.DUR, 1 / FPS)
    cam = np.array([film.camera(t)[:3] for t in ts])
    d = np.hypot(np.diff(cam[:, 0]) * cam[1:, 2], np.diff(cam[:, 1]) * cam[1:, 2]) + np.abs(np.diff(cam[:, 2])) / cam[1:, 2] * 1000
    cuts = [film.tb(b) for b, bt, n in film.CAM if bt == 0]
    sm = [d[i] for i in range(len(d)) if min(abs(ts[i + 1] - c) for c in cuts) > 0.04]
    on_beat = all(abs((c / film.BEAT) - round(c / film.BEAT)) < 1e-6 for c in cuts)
    return max(sm) <= 30 and on_beat, f'fastest smooth move {max(sm):.1f} px/frame; {len(cuts)} cuts, all on beats: {on_beat}'


if __name__ == '__main__':
    if sys.argv[1] == '--selftest-camera':
        bad = [c if c[0] != 52 else (51.5, 2, 'f4') for c in film.CAM]
        r = camera_smooth(bad)
        print('whip pan:', 'caught' if not r[0] else 'NOT CAUGHT', r[1])
        sys.exit(0)
    if sys.argv[1] == '--selftest-geometry':
        r = geometry()
        print(f"blade-phase ({film.BRK or 'no break'}):", 'FAIL' if not r[0] else 'pass', r[1])
        sys.exit(0)
    fr, t0 = sys.argv[1], float(sys.argv[2])
    t1 = t0 + len(os.listdir(fr)) / FPS
    res = [('beam follows the gate', *beam(fr, t0, t1)), ('heat is blackbody', *heat(fr, t0, t1)),
           ('pause freezes', *freeze(fr, t0, t1)), ('geometry matches the audio', *geometry()),
           ('camera smooth', *camera_smooth())]
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    print('ALL PASS' if all(r[1] for r in res) else 'SOME FAIL')
