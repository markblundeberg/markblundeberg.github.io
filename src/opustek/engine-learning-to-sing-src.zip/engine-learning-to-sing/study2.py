"""Study 2: the same engine, two ways for it to sing, and less cheese.

Mark's notes on study 1: the drone works; the other instruments are cheesy
synth; the whistle doesn't work. So the drone is study 1's, unchanged, and
everything around it is rebuilt.

  python3 study2.py --lead talk     A: vowel formants move over the drone itself
  python3 study2.py --lead scream   B: a resonant, driven saw lead with glide
"""
import argparse
import json
import os
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import study1 as s1
from study1 import (SR, OS, BEAT, BAR, NBARS, N, CR, BLOCKS, DRONE, SING, t_bar,
                    bar_env, up, place, sidechain, drift)

HZ = s1.HZ
KICK_BARS, HAT_BARS, CLAP_BARS = s1.KICK_BARS, s1.HAT_BARS, s1.CLAP_BARS
LEAD_FROM = 9
ARP_BARS = list(range(13, 25)) + list(range(29, 33))

# vowel formants (F1, F2, F3) in Hz, a male-ish voice
VOWELS = {'a': (750, 1150, 2800), 'o': (480, 820, 2700), 'u': (330, 720, 2600),
          'e': (430, 1700, 2600), 'i': (290, 2100, 2900)}
VOWEL_OF_N = {6: 'u', 8: 'o', 9: 'a', 10: 'e', 12: 'i'}   # higher note, brighter vowel

# the background arp: chord tones in eighths, gated by a sparse pattern
ARP = {'Fsm': [66, 69, 73, 76], 'D': [62, 66, 69, 73], 'A': [69, 73, 76, 80], 'E': [64, 68, 71, 76]}
ARP_GATE = [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0]   # 3+3+2 feel, twice per bar


def drone(tc, f0):
    """Study 1's drone body, unchanged: three detuned saws, ladder, motor
    roughness, saturation. Returns the body and the raw unison saw (both at
    the oversampled rate) so the talking lead can shape the same source."""
    nos, sro = N * OS, SR * OS
    voices = []
    for v, dc in enumerate([-7.0, 0.0, 6.0]):
        cents = dc + drift(len(tc), CR, 3.5, seed=10 + v)
        voices.append(dsp.saw(up(f0 * 2 ** (cents / 1200), tc, nos, sro), sro, phase=0.31 * v))
    mono = sum(voices) / 3
    sect = (300 + 500 * bar_env(tc, range(5, 9), 1.5) + 1100 * bar_env(tc, range(9, 25), 2.0)
            + 300 * bar_env(tc, range(17, 25), 3.0) + 250 * bar_env(tc, range(29, 33), 0.5))
    lfo = 1 + 0.25 * np.sin(2 * np.pi * tc / (8 * BAR))
    cut = sect * (f0 / 55.0) ** 1.4 * lfo * 2 ** (drift(len(tc), CR, 80, seed=20) / 1200)
    body = dsp.ladder(mono, up(cut, tc, nos, sro), sro, res=0.42, drive=1.6)
    ph = 2 * np.pi * np.cumsum(up(f0, tc, nos, sro) / 2) / sro
    body *= 1 + 0.10 * np.sin(ph)
    body = np.tanh(1.3 * body) / np.tanh(1.3)
    return body, mono


def lead_events(tc):
    ev = []
    for k, ch in enumerate(BLOCKS):
        b0 = t_bar(1 + 4 * k)
        if b0 < t_bar(LEAD_FROM):
            continue
        for beat, n in SING[ch]:
            ev.append((b0 + beat * BEAT, n, ch))
    return ev


def lead_talk(tc, f0, mono, ev):
    """The engine forms vowels: three resonances at the vowel's formants,
    moving smoothly from vowel to vowel, applied to the drone's own saw."""
    nos, sro = N * OS, SR * OS
    F = np.zeros((3, len(tc)))
    amp = np.zeros(len(tc))
    cur = VOWELS['u']
    for i in range(3):
        F[i][:] = cur[i]
    for te, n, ch in ev:
        m = tc >= te
        if n == 0:
            amp[m] = 0.3
            continue
        v = VOWELS[VOWEL_OF_N[n]]
        for i in range(3):
            F[i][m] = v[i]
        amp[m] = 1.0
    F = np.stack([s1.onepole_lag(F[i], 0.06, 0.06, CR) for i in range(3)])
    amp = s1.onepole_lag(amp, 0.05, 0.2, CR) * np.clip((tc - t_bar(LEAD_FROM)) / (2 * BAR), 0, 1)
    amp *= np.clip(1 - (tc - t_bar(NBARS + 1)) / 2.0, 0, 1)
    out = np.zeros(nos)
    for i, (q, g) in enumerate([(6.0, 1.0), (9.0, 0.7), (12.0, 0.35)]):
        out += g * dsp.svf_bp(mono, up(F[i], tc, nos, sro), sro, q)
    out = dsp.ladder(out, 5000.0, sro, res=0.1, drive=1.4)
    out *= up(amp, tc, nos, sro) * 2.2
    return signal.resample_poly(out, 1, OS)[:N]


def lead_scream(tc, f0, ev, detune=0.0):
    """A separate lead: two detuned saws, portamento, a resonant driven ladder
    whose cutoff swells with each note and breathes slowly over the phrase.
    Pitches are the same harmonics of each block's root, held (not riding the
    revs), so the lead stays in tune with the drone."""
    nos, sro = N * OS, SR * OS
    ptgt = np.full(len(tc), np.log(440.0))
    gate = np.zeros(len(tc))
    swell = np.zeros(len(tc))
    for te, n, ch in ev:
        m = tc >= te
        if n == 0:
            gate[m] = 0.0
            continue
        ptgt[m] = np.log(n * DRONE[ch])
        gate[m] = 1.0
        d = np.clip(tc - te, 0, None)
        swell = np.where(m, np.exp(-d / 0.45), swell)
    lp = s1.onepole_lag(ptgt, 0.045, 0.045, CR)   # glide
    vib = 1 + 0.0035 * np.sin(2 * np.pi * 5.2 * tc) * np.clip((swell < 0.4) * 1.0, 0, 1)
    f = np.exp(lp) * vib * 2 ** (detune / 1200)
    amp = s1.onepole_lag(gate, 0.02, 0.25, CR) * np.clip((tc - t_bar(LEAD_FROM)) / (2 * BAR), 0, 1)
    amp *= np.clip(1 - (tc - t_bar(NBARS + 1)) / 2.0, 0, 1)
    x = sum(dsp.saw(up(f * 2 ** ((c + drift(len(tc), CR, 3, seed=40 + i)) / 1200), tc, nos, sro), sro, 0.2 * i)
            for i, c in enumerate([-8.0, 7.0])) / 2
    breathe = 1 + 0.35 * np.sin(2 * np.pi * tc / (4 * BAR) - 1.0)
    cut = (900 + 2600 * swell) * breathe
    y = dsp.ladder(x, up(cut, tc, nos, sro), sro, res=0.62, drive=2.4)
    y = np.tanh(1.6 * y) / np.tanh(1.6)
    y *= up(amp, tc, nos, sro) * 0.9
    return signal.resample_poly(y, 1, OS)[:N]


def kick_hit(sr):
    """Tuned to A1: a pitch sweep that settles on 55 Hz, a short click,
    saturation for weight."""
    t = np.arange(int(0.45 * sr)) / sr
    f = 55 + 140 * np.exp(-t / 0.022) + 20 * np.exp(-t / 0.12)
    x = np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-t / 0.26) * np.clip(t / 0.0007, 0, 1)
    rng = np.random.default_rng(1)
    click = dsp.butter(rng.standard_normal(len(t)), (1800, 6000), sr, 'band') * np.exp(-t / 0.003)
    return np.tanh(2.2 * (x + 0.12 * click)) / np.tanh(2.2)


def hat_hit(sr, decay, seed):
    """808-style metal: six square waves at inharmonic ratios, band-limited
    to the top octave, with a little noise."""
    t = np.arange(int((decay * 6) * sr)) / sr
    fr = np.array([205.3, 304.4, 369.6, 522.7, 540.0, 800.0]) * 1.7
    x = sum(np.sign(np.sin(2 * np.pi * f * t + i)) for i, f in enumerate(fr))
    x += 0.8 * np.random.default_rng(seed).standard_normal(len(t))
    x = dsp.butter(dsp.butter(x, (7000, 14000), sr, 'band'), 6500, sr, 'high')
    return x * np.exp(-t / decay) * 0.25


def clap_hit(sr):
    """Four quick bursts then a diffuse tail, band-limited around 1.2 kHz."""
    t = np.arange(int(0.45 * sr)) / sr
    n = np.random.default_rng(4).standard_normal(len(t))
    env = np.zeros(len(t))
    for k, o in enumerate((0.0, 0.011, 0.021, 0.034)):
        d = np.clip(t - o, 0, None)
        env += (t >= o) * np.exp(-d / (0.006 if k < 3 else 0.16))
    x = dsp.butter(n, (800, 2600), sr, 'band') * env
    return x / np.abs(x).max()


def arp_pluck(sr, hz):
    """Saw pluck: two detuned saws, the ladder's cutoff snapping shut."""
    t = np.arange(int(0.9 * sr)) / sr
    x = (dsp.saw(np.full(len(t), hz * 2 ** (-5 / 1200)), sr) + dsp.saw(np.full(len(t), hz * 2 ** (5 / 1200)), sr, 0.4)) / 2
    cut = 300 + 3200 * np.exp(-t / 0.09)
    y = dsp.ladder(x, cut, sr, res=0.35, drive=1.2)
    return y * np.exp(-t / 0.5) * np.clip(t / 0.002, 0, 1)


def render(lead, brk=None):
    t0 = time.time()

    class A:   # study 1's score, unbroken
        brk = None
    tc, f0, _, _, _ = s1.score(A)
    body, mono = drone(tc, f0)
    ev = lead_events(tc)
    ld = lead_talk(tc, f0, mono, ev) if lead == 'talk' else lead_scream(tc, f0, ev, detune=-30.0 if brk == 'flat-lead' else 0.0)
    body = signal.resample_poly(body, 1, OS)[:N]
    body *= up(np.clip(tc / 2.0, 0, 1) * np.clip(1 - (tc - t_bar(NBARS + 1) - 1.0) / 2.5, 0, 1), tc, N, SR)

    kicks = [t_bar(b) + i * BEAT for b in KICK_BARS for i in range(4)]
    kick = np.zeros(N)
    place(kick, kick_hit(SR), [(k, 1.0) for k in kicks], SR, gain=0.9)
    hats = np.zeros(N)
    place(hats, hat_hit(SR, 0.07, 2), [(t_bar(b) + (i + 0.5) * BEAT, 1.0) for b in HAT_BARS for i in range(4)], SR, 0.5)
    place(hats, hat_hit(SR, 0.018, 3), [(t_bar(b) + i * BEAT / 4, (0.0, 0.35, 0.0, 0.55)[i % 4])
                                        for b in list(range(13, 25)) + list(range(29, 33)) for i in range(16)], SR, 0.35)
    clap = np.zeros(N)
    place(clap, clap_hit(SR), [(t_bar(b) + i * BEAT, 1.0) for b in CLAP_BARS for i in (1, 3)], SR, 0.16)

    arp = np.zeros(N)
    cache = {}
    for k, ch in enumerate(BLOCKS):
        for b in range(4):
            bar = 1 + 4 * k + b
            if bar not in ARP_BARS:
                continue
            for i, g in enumerate(ARP_GATE):
                if g:
                    m = ARP[ch][i % 4]
                    if m not in cache:
                        cache[m] = arp_pluck(SR, HZ(m))
                    place(arp, cache[m], [(t_bar(bar) + i * BEAT / 4, 0.8 + 0.2 * (i % 3 == 0))], SR)
    arp *= 0.07

    body *= sidechain(kicks, N, SR, 0.55) * 0.42
    ld *= sidechain(kicks, N, SR, 0.25) * 0.32
    arp *= sidechain(kicks, N, SR, 0.4)
    L = body + kick + hats * 0.85 + clap + ld + arp * 0.6
    R = body + kick + hats * 1.15 + clap + ld + arp * 1.4
    dL, dR = dsp.pingpong(arp * 0.6 + ld * 0.12, ld * 0.04, 0.75 * BEAT, SR, fb=0.45, damp_hz=2800)
    sL = ld * 0.28 + arp * 0.5 + clap * 0.5 + body * 0.04 + dL * 0.5
    sR = ld * 0.28 + arp * 0.5 + clap * 0.5 + body * 0.04 + dR * 0.5
    rL, rR = dsp.reverb(sL, sR, SR, rt60=4.5, damp_hz=4200)
    L, R = L + dL + rL, R + dR + rR
    L, R = np.tanh(1.1 * L) / 1.1, np.tanh(1.1 * R) / 1.1
    mix = np.stack([L, R], axis=1)
    mix -= mix.mean(axis=0)
    for _ in range(3):
        g = 10 ** ((-10.5 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.5)
    print(f'render {time.time() - t0:.1f} s')
    return mix, {'kick': kick, 'lead': ld, 'body': body}, kicks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lead', choices=['talk', 'scream'], required=True)
    ap.add_argument('--break', dest='brk', choices=['flat-lead'])
    a = ap.parse_args()
    mix, stems, kicks = render(a.lead, a.brk)
    name = f'study2_{a.lead}' + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, **stems)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'kicks': kicks}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
