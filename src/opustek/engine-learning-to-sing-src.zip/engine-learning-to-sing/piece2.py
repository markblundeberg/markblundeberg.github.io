"""Engine, Learning to Sing (v2). Piece 1's music, with Mark's notes acted on
and the cloog given a voice.

Mark on piece 1: the high-pitched shriek is too strong at times (the octave
flips and/or the squelch; both tamed); the clap is too long; the kick is too
loud or the rest too quiet (measured: low/mid +12..+15 dB vs the references' +10..+13, and
the hats 2-5 dB hot); the drone sometimes too strong (1:59: a fold, a squelch
and a 1.6-octave sweep stacked); the switch-off too quiet; "the drone still
needs a bit something to make it really cool. Be creative here."

The something: hard sync. A second saw restarts every time the engine's own
cycle does, so its pitch is the engine's, and what moves is a resonant peak
walking across the engine's harmonics, the physics of overtone singing, built
into the waveform. Study 1 laid a whistle on top; this sings from inside.
The sync ratio revs: each rise in the bass line kicks it up, and it settles
back. Plus a slow stereo phaser (a turbine swirl) and a sub-octave for weight.

  python3 piece2.py [--break no-sync|no-leveler|muffled|late-clap|no-decor]
"""
import argparse
import json
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import piece1 as p1
import study1 as s1
import study4 as s4
import study5 as s5
from piece1 import R, mask, ramp, NBARS, TAIL, KICK, CLAP, HATS, HAT16, DOOTS, BASS, SWEEPS, ENGINE_IDLE
from study4 import SR, OS, CR, BEAT, BAR, HZ, tb

# fewer flips than piece 1 (22 -> 11), darker and quieter when they happen
FLIPS = {b: 2.5 for b in (38, 44, 50, 54, 58, 62, 78, 84, 88, 92)}
FLIPS[96] = 3.5
# piece 1's decorations, two squelches dropped, the rest kept
DECOR = [d for d in p1.DECOR if not (d[2] == 'squelch' and d[0] in (56, 91))]
SQ_RES, SQ_LIFT = 0.78, 0.6            # piece 1: 0.92 and 1.5

GAIN = dict(kick=0.82, engine=0.46, doots=0.135, hats=0.36, clap=0.11)


def sync_ratio(tc, f_line, brk=None):
    """How far the second oscillator runs ahead of the engine. The peak it
    makes sits at ratio x f0, and the engine is low (46-92 Hz), so to sing in
    the 400-2000 Hz range the ratio has to reach ~4-22: 1 while idle, climbing
    to 5 as the engine wakes (it learns to sing), to 8 in the climax; each
    rise in the bass line revs it up by up to 9 and it settles over ~1.6 s;
    a slow 8-bar breath of up to 3 on top."""
    if brk == 'no-sync':
        return np.ones(len(tc)), np.zeros(len(tc))
    learn = ramp(tc, tb(33), tb(49), 1.0, 5.0) + ramp(tc, tb(73), tb(85), 0.0, 3.0)
    lf = np.log(f_line)
    rise = np.maximum(np.gradient(lf) * CR, 0)          # octaves-ish per second, only upward
    k = np.exp(-np.arange(int(3 * CR)) / (1.6 * CR))
    rev = np.convolve(rise, k)[:len(tc)] / CR
    rev = 9.0 * rev / max(rev.max(), 1e-9)
    breath = 3.0 * (0.5 - 0.5 * np.cos(2 * np.pi * tc / (8 * BAR)))
    ratio = np.clip(learn + rev + breath * (tc >= tb(33)), 1.0, 22.0)
    # how much of the sync voice is in the engine
    blend = (0.12 * mask(tc, R(33, 48), 2) + 0.32 * mask(tc, R(49, 64), 1) + 0.22 * mask(tc, R(66, 71), 1)
             + 0.42 * mask(tc, R(73, 96), 1) + 0.2 * mask(tc, R(97, 104), 2))
    return ratio, blend


def cloog(tc, f0, f_line, cut, amp, dc, ratio, blend, flipping):
    """The engine: three detuned saws plus the hard-sync voice, through the
    ladder; decorations as in study 5 (tube after the filter, growl, fold,
    a gentler squelch); a slow stereo phaser on the upper part; a sub-octave
    sine under the mono low end."""
    nos, sro = int(len(tc) / CR * SR) * OS, SR * OS
    n = nos // OS
    U = lambda c: s1.up(c, tc, nos, sro)
    vs = []
    for v, dct in enumerate([-7.0, 0.0, 6.0]):
        cents = dct + s1.drift(len(tc), CR, 3.5, seed=10 + v)
        vs.append(dsp.saw(U(f0 * 2 ** (cents / 1200)), sro, phase=0.31 * v))
    sync = dsp.syncsaw(U(f0 * 2 ** (s1.drift(len(tc), CR, 2.5, seed=31) / 1200)), U(ratio), sro, 0.13)
    bl = U(blend)
    sq = dc['squelch']
    cut_os = U(cut * (1 + SQ_LIFT * sq) * (1 - 0.3 * flipping))
    sqo = U(sq)
    drive, fold, growl = U(dc['drive']), U(dc['fold']), U(0.10 + 0.75 * dc['growl'])
    fold_gain = 1.5 + 4.5 * fold
    ph = 2 * np.pi * np.cumsum(U(f0) / 2) / sro
    out = []
    for w in ((0.55, 0.3, 0.15), (0.15, 0.3, 0.55)):
        x = sum(a * v for a, v in zip(w, vs)) * (1 - 0.5 * bl) + sync * bl * 1.1
        b = dsp.ladder(x, cut_os, sro, res=0.42, drive=1.6)
        if sq.max() > 0:
            b = b * (1 - sqo) + dsp.ladder(x, cut_os, sro, res=SQ_RES, drive=1.6) * sqo
        b = b * (1 + growl * np.sin(ph)) / (1 + 0.5 * growl)
        y = s5.tube(b, drive)
        y = y * (1 - fold) + np.sin(fold_gain * b) * fold
        out.append(signal.resample_poly(y, 1, OS)[:n])
    L, Rr = out
    low = dsp.butter((L + Rr) / 2, 150, SR, 'low', 4)
    sub = np.sin(2 * np.pi * np.cumsum(s1.up(f_line / 2, tc, n, SR)) / SR)
    low = low + 0.35 * dsp.butter(sub, 120, SR, 'low', 2)
    hiL = dsp.phaser(dsp.butter(L, 150, SR, 'high', 4), SR, rate=0.045, fmin=250, fmax=2600, stages=6, fb=0.5, phase=0.0)
    hiR = dsp.phaser(dsp.butter(Rr, 150, SR, 'high', 4), SR, rate=0.045, fmin=250, fmax=2600, stages=6, fb=0.5, phase=1.9)
    a = s1.up(amp, tc, n, SR)
    return (low + hiL) * a, (low + hiR) * a


def leveler(L, Rr, sr, ratio=3.0, att=0.03, rel=0.35):
    """Keeps the engine from jumping out (Mark: too strong at 1:59): an RMS
    compressor on the engine alone, threshold 3 dB over its typical awake level."""
    p = (L ** 2 + Rr ** 2) / 2
    b, a = signal.butter(1, 1 / (2 * np.pi * 0.15), fs=sr)
    env = np.sqrt(np.maximum(signal.lfilter(b, a, p), 1e-20))
    awake = env[env > 0.05 * env.max()]
    thr = np.median(awake) * 10 ** (3 / 20)
    g = np.minimum(1.0, (thr / env) ** (1 - 1 / ratio))
    # attack/release smoothing of the gain (dB domain)
    gd = 20 * np.log10(g)
    s = 0.0
    gd_ds = gd[::48]
    sm = np.empty_like(gd_ds)
    ka, kr = 1 - np.exp(-48 / (att * sr)), 1 - np.exp(-48 / (rel * sr))
    for i, v in enumerate(gd_ds):
        s += (ka if v < s else kr) * (v - s)
        sm[i] = s
    gs = 10 ** (np.interp(np.arange(len(gd)), np.arange(len(sm)) * 48, sm) / 20)
    return L * gs, Rr * gs


def clap_hit(sr):
    """Shorter and drier than piece 1's: three quick bursts and a 50 ms tail."""
    t = np.arange(int(0.2 * sr)) / sr
    nz = np.random.default_rng(4).standard_normal(len(t))
    env = np.zeros(len(t))
    for k, o in enumerate((0.0, 0.009, 0.018)):
        d = np.clip(t - o, 0, None)
        env += (t >= o) * np.exp(-d / (0.005 if k < 2 else 0.05))
    x = dsp.butter(nz, (900, 2800), sr, 'band') * env
    return x / np.abs(x).max()


def engine(tc, brk=None):
    f_line = s4.glide_curve(tc, BASS, s4.GLIDE)
    fl = np.zeros(len(tc))
    for bar, beat in FLIPS.items():
        s = tb(bar, beat)
        fl[(tc >= s) & (tc < s + 0.5 * BEAT)] = 1.0
    fl = np.convolve(fl, np.ones(12) / 12, mode='same')
    f0 = f_line * 2 ** fl
    idle = mask(tc, R(*ENGINE_IDLE), 2.0) * 0.6
    awake = mask(tc, R(33, 64) + R(73, 96), 0.5) * ramp(tc, tb(33), tb(35))
    wake2 = mask(tc, R(66, 71), 0.5) * ramp(tc, tb(66), tb(71), 0.0, 0.9)
    outro = mask(tc, R(97, 112), 0.5) * ramp(tc, tb(97), tb(109), 1.0, 0.75)
    lvl = np.maximum.reduce([idle, awake, wake2, outro]) * (1 - 0.3 * fl)
    base = (220 + 300 * mask(tc, R(33, 48), 2) + 700 * mask(tc, R(49, 64), 2) + 300 * mask(tc, R(66, 71), 2)
            * ramp(tc, tb(66), tb(71)) + 1000 * mask(tc, R(73, 96), 1) * ramp(tc, tb(73), tb(85), 0.5, 1.0)
            + 400 * mask(tc, R(97, 112), 2) * ramp(tc, tb(97), tb(109), 1, 0))
    base *= 1 + 0.2 * np.sin(2 * np.pi * tc / (16 * BAR) + 1.3)
    sw = np.zeros(len(tc))
    for bar, up_, dn, octv in SWEEPS:
        a, p, z = tb(bar), tb(bar + up_), tb(bar + up_ + dn)
        sw += octv * np.where(tc < p, ramp(tc, a, p), 1 - ramp(tc, p, z)) * (tc >= a) * (tc < z)
    depth = s5.womp_depth(tc) * mask(tc, R(33, 96), 4)
    w = s5.womp_curve(tc, depth)
    cut = base * 2 ** sw * (0.6 + 0.4 * w) * (f_line / HZ(30)) ** 0.8
    tend = tb(NBARS - 3)
    off = tc >= tend
    dk = np.exp(-np.clip(tc - tend, 0, None) / 1.6)
    f0 = np.where(off, f0 * dk + 24 * (1 - dk), f0)
    f_line = np.where(off, f_line * dk + 24 * (1 - dk), f_line)
    lvl = lvl * np.where(off, np.clip(1 - (tc - tend) / 5.0, 0, 1), 1)
    dc = {k: np.zeros(len(tc)) for k in s5.KINDS}
    if brk != 'no-decor':
        for bar, beat, kind, att, hold, dec, amt in DECOR:
            dc[kind] = np.maximum(dc[kind], amt * s5.analog_env(tc, tb(bar, beat), att, hold, dec))
    ratio, blend = sync_ratio(tc, s4.glide_curve(tc, BASS, s4.GLIDE), brk)
    return f0, f_line, cut, lvl * w, dc, ratio, blend, fl


def render(brk=None):
    t0 = time.time()
    dur = NBARS * BAR + TAIL
    N = int(dur * SR)
    tc = np.arange(int(dur * CR)) / CR
    pad = lambda z: np.pad(z, (0, max(0, N - len(z))))[:N]

    f0, f_line, cut, amp, dc, ratio, blend, fl = engine(tc, brk)
    eL, eR = (pad(z) for z in cloog(tc, f0, f_line, cut, amp, dc, ratio, blend, fl))
    if brk != 'no-leveler':
        eL, eR = leveler(eL, eR, SR)

    cl = p1.clarity(tc, brk)
    doots = np.zeros(N)
    cache = {}
    for bar in DOOTS:
        pat = p1.DOOT_B if bar % 4 == 0 else p1.DOOT_A
        for i, m in enumerate(pat):
            te = tb(bar) + i * BEAT / 4
            o = round(float(np.interp(te, tc, cl)), 2)
            key = (m, o, p1.ACCENT[i])
            if key not in cache:
                cache[key] = p1.doot(SR, HZ(m), o, p1.ACCENT[i])
            s1.place(doots, cache[key], [(te, 0.75 + 0.25 * p1.ACCENT[i])], SR)
    groove_lift = 1 + 0.45 * mask(tc, R(17, 32), 1.0)        # fill the bed under the first kicks
    doots *= s1.up(ramp(tc, 0, tb(3), 0.3, 1.0) * ramp(tc, tb(105), tb(109), 1.0, 0.0) * groove_lift, tc, N, SR) * GAIN['doots']
    eL8 = dsp.tapedelay(doots, SR, 0.5 * BEAT, wow_ms=1.5, wow_hz=0.4, fb=0.5, damp_hz=2600, phase=0.0)
    eR8 = dsp.tapedelay(doots, SR, 0.5 * BEAT + 0.011, wow_ms=1.8, wow_hz=0.47, fb=0.5, damp_hz=2400, phase=1.7)
    wl = dsp.tapedelay(doots, SR, 0.75 * BEAT, wow_ms=3.5, wow_hz=0.55, fb=0.6, damp_hz=2200, phase=0.4)
    wr = dsp.tapedelay(doots, SR, 1.0 * BEAT, wow_ms=4.0, wow_hz=0.71, fb=0.58, damp_hz=2000, phase=2.3)
    rl, rr = dsp.reverb(wl * 0.8 + doots * 0.2, wr * 0.8 + doots * 0.2, SR, rt60=6.5, damp_hz=3500)

    kicks = [tb(b, i) for b in KICK for i in range(4)]
    kick = np.zeros(N)
    s1.place(kick, p1.kick_hit(SR), [(k, 1.0) for k in kicks], SR, GAIN['kick'])
    claps = [tb(b, i) + (0.012 if brk == 'late-clap' else 0.0) for b in CLAP for i in (1, 3)]
    clap = np.zeros(N)
    s1.place(clap, clap_hit(SR), [(c, 1.0) for c in claps], SR, GAIN['clap'])
    rng = np.random.default_rng(5)
    hL, hR = np.zeros(N), np.zeros(N)
    for b in HATS:
        lv = 0.6 if b < 17 else 1.0
        for i in range(8):
            h = s4.spaghetti(SR, rng)
            g = (0.5, 1.0)[i % 2] * rng.uniform(0.85, 1.0) * lv
            p = 0.5 + rng.uniform(-0.25, 0.25)
            s1.place(hL, h, [(tb(b, i / 2), g * (1 - p))], SR)
            s1.place(hR, h, [(tb(b, i / 2), g * p)], SR)
    for b in HAT16:
        for i in range(16):
            if i % 2 == 1 and rng.uniform() < 0.7:
                h = s4.spaghetti(SR, rng) * 0.3
                p = 0.5 + rng.uniform(-0.4, 0.4)
                s1.place(hL, h, [(tb(b, i / 4), 1 - p)], SR)
                s1.place(hR, h, [(tb(b, i / 4), p)], SR)

    sc = s1.sidechain(kicks, N, SR, 0.55, rel=0.18)
    eL, eR = eL * sc * GAIN['engine'], eR * sc * GAIN['engine']
    dt = doots * s1.sidechain(kicks, N, SR, 0.25)
    echo = s1.sidechain(kicks, N, SR, 0.35)
    L = kick + eL + dt * 0.9 + (eL8 * 0.45 + wl * 0.3 + rl * 0.5) * echo + hL * GAIN['hats'] + clap
    Rr = kick + eR + dt * 1.1 + (eR8 * 0.45 + wr * 0.3 + rr * 0.5) * echo + hR * GAIN['hats'] + clap
    cl_, cr_ = dsp.reverb(clap * 0.25 + eL * 0.04 + hL * 0.06, clap * 0.25 + eR * 0.04 + hR * 0.06, SR, rt60=1.5, damp_hz=7000)
    mix = np.stack([L + cl_, Rr + cr_], 1)
    mix -= mix.mean(0)
    for _ in range(6):
        g = 10 ** ((-10.0 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.2, rel_ms=60)
    mix *= s1.up(np.clip((dur - tc) / 1.5, 0, 1), tc, N, SR)[:, None]
    print(f'render {time.time() - t0:.1f} s')
    stems = {'kick': kick, 'clap': clap, 'droneL': eL, 'droneR': eR, 'doots': doots}
    return mix, stems, kicks, claps, tc, f0, ratio, blend


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--break', dest='brk', choices=['no-sync', 'no-leveler', 'muffled', 'late-clap', 'no-decor'])
    a = ap.parse_args()
    mix, stems, kicks, claps, tc, f0, ratio, blend = render(a.brk)
    name = 'piece2' + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, tc=tc, f0=f0, ratio=ratio, blend=blend, **stems)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'kicks': kicks, 'claps': claps}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
