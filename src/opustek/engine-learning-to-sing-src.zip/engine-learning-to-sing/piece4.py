"""Engine, Learning to Sing (v4): the form tightened, the chopper, less mud.

Mark on v3 (earbuds: "it sounds awesome"): the intro goes on too long, the
engine is only prominent at 1:10; at 2:05 the doots come in suddenly as the
engine stops, like a new song: layer them under the engine first (or leave a
short silence); the 2:20 drop is nice; an idea: a full chopper (near-square
amplitude modulation to zero).
Argon, blind, on v3: its timeline was compressed (~0.6x) and it described
things that aren't there (no sidechain, "16th-note rolling bass from 0:00",
a pad), so its timestamps are discounted; two claims held when measured
against the references: low-mid mud (our 120-300 Hz share -7..-8 dB of the
total vs the references' -8.4..-12.3) and upper-mid harshness, in our climax
(2.5-6 kHz -15.9 dB vs -22 at the references' brightest).

Form, 96 bars (~3:13): intro 1-8 | groove 9-16 (kick, clap, the engine idling)
| the engine wakes 17-32 (0:31) | engine solo 33-48, the doots creeping back
under it from 45 | breakdown 49-55, pause 56 | climax 57-80 (the octave climb
at 73) | outro 81-96, the engine switches off. Piece 3's bars map as: 1-8 stay,
9-24 are cut, 25 onward move up 16.

  python3 piece4.py [--break no-chop|no-overlap|muddy|harsh]
"""
import argparse
import json
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import piece1 as p1
import piece2 as p2
import piece3 as p3
import study1 as s1
import study4 as s4
import study5 as s5
from piece1 import R, mask, ramp
from study4 import SR, OS, CR, BEAT, BAR, HZ, tb

NBARS = 96
TAIL = 7.0


def mp(b):
    """Piece 3's bar -> piece 4's bar (None if cut)."""
    return b if b <= 8 else (None if b <= 24 else b - 16)


def mpl(bars):
    return sorted({mp(b) for b in bars if mp(b) is not None})


BASS = [(mp(b), bt, m) for b, bt, m in p3.BASS if mp(b) is not None]
BASS[0] = (9, 0, 30)                                   # idling from the groove
DECOR = [(mp(b),) + d[1:] for d in p3.DECOR for b in [d[0]] if mp(b)]
SWEEPS = [(mp(b),) + s[1:] for s in p1.SWEEPS for b in [s[0]] if mp(b)]
KICK = mpl(p1.KICK)
CLAP = [b for b in mpl(p1.CLAP) if b not in (16, 32, 48, 80)]
HATS = list(range(5, 9)) + mpl(p1.HATS)
HAT16 = mpl(p1.HAT16)
DOOTS = list(range(1, 9)) + list(range(9, 33)) + list(range(51, 56)) + list(range(57, 93))
MECH_BARS = list(range(13, 17)) + mpl(range(49, 65)) + mpl(range(81, 97))
KS_NOTES = [(mp(b), bt, m) for b, bt, m in p3.KS_NOTES if mp(b) and not 49 <= mp(b) <= 50]
# the seam (Mark): after the solo, only the metal plucks for two bars, then the doots, then the engine
KS_NOTES += [(49, 0, 85), (49, 1.5, 81), (49, 2.5, 83), (49, 3.5, 88), (50, 0.5, 85), (50, 2, 90), (50, 3, 88)]
KS_NOTES.sort()
SECTION_ENDS = (8, 16, 32, 48, 80)
PAUSE = 56
FLIPS = {}
# the chopper, each one different (Mark: "maybe too many of the same ... double
# the rate and/or vary the duty cycle"): (bar, beats, cells per beat, duty at
# start, duty at end, pattern of open cells or None for all)
CHOPS = [(40, 4, 4, 0.55, 0.55, [1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0]),   # 16ths, a 3+3+2 pattern
         (44, 2, 8, 0.5, 0.5, None),                                              # 32nds, square
         (55, 4, 8, 0.8, 0.15, None),         # 32nds closing down: the engine choked into the pause
         (72, 4, 2, 0.3, 0.95, None),         # eighths opening up into the octave climb (32nds were scratchy against the grit)
         (79, 2, 3, 0.6, 0.35, None)]         # triplets, thinning into the outro
p3.BASS = BASS                                        # the cloog's sub follows this line


# the return after the seam builds from one note (Mark: "like a wall of sound
# instead of starting with one note"), filling in the figure the engine wakes
# to (bar 53's: steps 1 4 6 9 12 14) a half-bar at a time: 1, 1, 2, 3, then 6.
# (v4.2 filtered each bar's own figure, whose steps differ: bar 51 played
# nothing and bar 52 one note. The 'old-build' break restores it.)
BUILD = {51: {1, 9}, 52: {1, 6, 9, 12, 14}}
OLD_BUILD = {51: {0}, 52: {0, 6, 11}}


def doot_pattern(bar, brk=None):
    old = bar if bar <= 8 else bar + 16                # reuse piece 3's evolution by its bar numbers
    if brk == 'old-build' and bar in OLD_BUILD:
        return [n for n in p3.doot_pattern(old, None) if n[0] in OLD_BUILD[bar]]
    if bar in BUILD and brk != 'wall':
        return [n for n in p3.doot_pattern(53 + 16, None) if n[0] in BUILD[bar]]
    return p3.doot_pattern(old, None)


def peq(x, sr, f0, gain_db, q):
    """RBJ peaking EQ."""
    A = 10 ** (gain_db / 40)
    w = 2 * np.pi * f0 / sr
    al = np.sin(w) / (2 * q)
    b = [1 + al * A, -2 * np.cos(w), 1 - al * A]
    a = [1 + al / A, -2 * np.cos(w), 1 - al / A]
    return signal.lfilter(np.array(b) / a[0], np.array(a) / a[0], x)


def kick_hit(sr, brk=None):
    """Piece 1's kick, cleaned of mud (it was 95% of the groove's 120-300 Hz
    energy): a quicker sweep through the low mids, less saturation (fewer odd
    harmonics at 139 and 231 Hz), and a gentle dip at 180 Hz."""
    if brk == 'muddy':
        return p1.kick_hit(sr)
    t = np.arange(int(0.4 * sr)) / sr
    f = HZ(30) + 150 * np.exp(-t / 0.011) + 22 * np.exp(-t / 0.06)
    env = np.exp(-np.clip(t - 0.03, 0, None) / 0.09) * np.clip(t / 0.0006, 0, 1)
    x = np.sin(2 * np.pi * np.cumsum(f) / sr) * env
    click = dsp.butter(np.random.default_rng(1).standard_normal(len(t)), (2000, 7000), sr, 'band') * np.exp(-t / 0.0025)
    y = np.tanh(0.8 * (x + 0.18 * click)) / np.tanh(0.8)
    return peq(y, sr, 180, -4.0, 0.8)


def chop_cells():
    """Every gate cell: (open start, open end, cell end) in seconds."""
    out = []
    for bar, beats, per, d0, d1, pat in CHOPS:
        n = int(beats * per)
        cell = BEAT / per
        for k in range(n):
            if pat is not None and not pat[k % len(pat)]:
                out.append((tb(bar) + k * cell, tb(bar) + k * cell, tb(bar) + (k + 1) * cell))
                continue
            duty = d0 + (d1 - d0) * k / max(n - 1, 1)
            a = tb(bar) + k * cell
            out.append((a, a + duty * cell, a + cell))
    return out


def chopper(n, sr, brk=None):
    """Gain at audio rate: 1, except in the chop cells, where it drops to
    -30 dB for the closed part of each cell, with 2 ms ramps so edges don't click."""
    g = np.ones(n)
    if brk == 'no-chop':
        return g
    r = int(0.002 * sr)
    for a, o, e in chop_cells():
        i, j = int(o * sr), int(e * sr)
        if j - i < 3 * r:
            continue
        g[i:j] = 0.03
        g[i:i + r] = np.linspace(1, 0.03, r)
        g[j - r:j] = np.linspace(0.03, 1, r)
    return g


def engine(tc, brk=None):
    f_line = s4.glide_curve(tc, BASS, s4.GLIDE)
    f0 = f_line.copy()
    idle = mask(tc, R(9, 16), 1.0) * 0.6
    awake = mask(tc, R(17, 48) + R(57, 80), 0.5) * ramp(tc, tb(17), tb(19))
    wake2 = mask(tc, R(53, 55), 0.5) * ramp(tc, tb(53), tb(55), 0.0, 0.9)
    outro = mask(tc, R(81, 96), 0.5) * ramp(tc, tb(81), tb(93), 1.0, 0.75)
    lvl = np.maximum.reduce([idle, awake, wake2, outro])
    base = (220 + 180 * mask(tc, R(9, 16), 1) + 300 * mask(tc, R(17, 32), 2) + 800 * mask(tc, R(33, 48), 2) + 300 * mask(tc, R(53, 55), 2)
            * ramp(tc, tb(53), tb(55)) + 2600 * mask(tc, R(57, 80), 1) * ramp(tc, tb(57), tb(73), 0.4, 1.0)
            + 400 * mask(tc, R(81, 96), 2) * ramp(tc, tb(81), tb(93), 1, 0))
    base *= 1 + 0.2 * np.sin(2 * np.pi * tc / (16 * BAR) + 1.3)
    sw = np.zeros(len(tc))
    for bar, up_, dn, octv in SWEEPS:
        a, p, z = tb(bar), tb(bar + up_), tb(bar + up_ + dn)
        sw += octv * np.where(tc < p, ramp(tc, a, p), 1 - ramp(tc, p, z)) * (tc >= a) * (tc < z)
    depth = s5.womp_depth(tc) * mask(tc, R(17, 80), 4)
    w = s5.womp_curve(tc, depth)
    cut = base * 2 ** sw * (0.6 + 0.4 * w) * (np.minimum(f_line, HZ(42)) / HZ(30)) ** 0.8
    tend = tb(NBARS - 3)
    off = tc >= tend
    dk = np.exp(-np.clip(tc - tend, 0, None) / 1.6)
    f0 = np.where(off, f0 * dk + 24 * (1 - dk), f0)
    lvl = lvl * np.where(off, np.clip(1 - (tc - tend) / 5.0, 0, 1), 1)
    dc = {k: np.zeros(len(tc)) for k in s5.KINDS}
    for bar, beat, kind, att, hold, dec, amt in DECOR:
        dc[kind] = np.maximum(dc[kind], amt * s5.analog_env(tc, tb(bar, beat), att, hold, dec))
    dc['drive'] = np.maximum(dc['drive'], 0.25 * mask(tc, R(61, 80), 4))
    # sync: piece 2's curve, its "learning" moved to the new bars
    learn = ramp(tc, tb(17), tb(33), 1.0, 5.0) + ramp(tc, tb(57), tb(69), 0.0, 3.0)
    rise = np.maximum(np.gradient(np.log(f_line)) * CR, 0)
    k = np.exp(-np.arange(int(3 * CR)) / (1.6 * CR))
    rev = np.convolve(rise, k)[:len(tc)] / CR
    rev = 9.0 * rev / max(rev.max(), 1e-9)
    breath = 3.0 * (0.5 - 0.5 * np.cos(2 * np.pi * tc / (8 * BAR)))
    ratio = np.clip(learn + rev + breath * (tc >= tb(17)), 1.0, 22.0)
    ratio = np.minimum(ratio, np.maximum(1.0, p3.SYNC_PEAK_MAX / f0))
    blend = (0.12 * mask(tc, R(17, 32), 2) + 0.32 * mask(tc, R(33, 48), 1) + 0.22 * mask(tc, R(53, 55), 1)
             + 0.42 * mask(tc, R(57, 80), 1) + 0.2 * mask(tc, R(81, 88), 2))
    dist = 0.08 * mask(tc, R(17, 32), 2) + 0.2 * mask(tc, R(33, 48), 1) + 0.2 * mask(tc, R(61, 80), 2)
    return f0, cut, lvl * w, dc, ratio, blend, dist


def render(brk=None):
    t0 = time.time()
    dur = NBARS * BAR + TAIL
    N = int(dur * SR)
    tc = np.arange(int(dur * CR)) / CR
    pad = lambda z: np.pad(z, (0, max(0, N - len(z))))[:N]
    rng = np.random.default_rng(5)

    f0, cut, amp, dc, ratio, blend, dist = engine(tc, brk)
    p3.GRIT_BAND = (300, 4000) if brk == 'harsh' else (300, 2500)   # keep the grit out of 2.5-6 kHz
    eL, eR = (pad(z) for z in p3.cloog(tc, f0, cut, amp, dc, ratio, blend, dist))
    eL, eR = p2.leveler(eL, eR, SR)
    if brk != 'muddy':
        eL, eR = peq(eL, SR, 210, -3.5, 0.9), peq(eR, SR, 210, -3.5, 0.9)
    if brk != 'harsh':
        # de-harsh the climax: a dip at 3.5 kHz, faded in over the climax only
        cx = s1.up(mask(tc, R(57, 80), 2), tc, N, SR)
        tame = lambda z: peq(peq(peq(z, SR, 3500, -7.0, 0.7), SR, 2600, -3.0, 1.0), SR, 9000, -2.5, 0.5)
        eL = eL * (1 - cx) + tame(eL) * cx
        eR = eR * (1 - cx) + tame(eR) * cx
    chop = chopper(N, SR, brk)
    eL, eR = eL * chop, eR * chop

    # doots
    cl = np.clip(ramp(tc, tb(2), tb(12)) * 0.85 + ramp(tc, tb(57), tb(61)) * 0.15 - ramp(tc, tb(81), tb(93)) * 0.9, 0, 1)
    doots = np.zeros(N)
    cache = {}
    bars = DOOTS + ([47, 48, 49, 50] if brk == 'cold-seam' else [])
    for bar in bars:
        for i, m, acc, v in doot_pattern(bar, brk):
            te = tb(bar) + i * BEAT / 4
            o = round(float(np.interp(te, tc, cl)), 2)
            key = (m, o, acc)
            if key not in cache:
                cache[key] = p1.doot(SR, HZ(m), o, acc)
            s1.place(doots, cache[key], [(te, v)], SR)
    lift = 1 + 0.45 * mask(tc, R(9, 16), 1.0)
    arrive = 1.0
    doots *= s1.up(ramp(tc, 0, tb(2), 0.3, 1.0) * ramp(tc, tb(89), tb(93), 1.0, 0.0) * lift * arrive, tc, N, SR) * p3.GAIN['doots']
    if brk != 'muddy':
        doots = peq(doots, SR, 220, -3.0, 1.0)
    bright = s1.up(np.clip(ramp(tc, tb(1), tb(73)) - ramp(tc, tb(81), tb(93)), 0, 1), tc, N, SR)
    ech = {}
    for tag, damp in (('d', 1200), ('b', 4500)):
        ech[tag] = (dsp.tapedelay(doots, SR, 0.5 * BEAT, wow_ms=1.5, wow_hz=0.4, fb=0.5, damp_hz=damp, phase=0.0),
                    dsp.tapedelay(doots, SR, 0.5 * BEAT + 0.011, wow_ms=1.8, wow_hz=0.47, fb=0.5, damp_hz=damp, phase=1.7))
    eL8 = ech['d'][0] * (1 - bright) + ech['b'][0] * bright
    eR8 = ech['d'][1] * (1 - bright) + ech['b'][1] * bright
    wl = dsp.tapedelay(doots, SR, 0.75 * BEAT, wow_ms=3.5, wow_hz=0.55, fb=0.6, damp_hz=2200, phase=0.4)
    wr = dsp.tapedelay(doots, SR, 1.0 * BEAT, wow_ms=4.0, wow_hz=0.71, fb=0.58, damp_hz=2000, phase=2.3)

    shim = np.zeros(N)
    for bar in R(53, 55):
        for i, m, acc, v in doot_pattern(bar):
            te = tb(bar) + i * BEAT / 4
            for mult, g in ((2.0, 0.6), (1.5, 0.4)):
                s1.place(shim, p1.doot(SR, HZ(m) * mult, 0.6, 1), [(te, v * g)], SR)
    shim = dsp.butter(shim, 2800, SR, 'low', 2) * p3.GAIN['doots'] * 0.8 * s1.up(ramp(tc, tb(53), tb(55)), tc, N, SR)

    ksig = np.zeros(N)
    kc = {}
    for bar, beat, m in KS_NOTES:
        if m not in kc:
            kc[m] = p3.ks_note(SR, HZ(m))
        s1.place(ksig, kc[m], [(tb(bar, beat), rng.uniform(0.7, 1.0))], SR)
    ksig *= 0.05 * s1.up(1 + 0.7 * np.where(tc < tb(51), mask(tc, R(49, 50), 0.3), ramp(tc, tb(51), tb(53), 1.0, 0.0)), tc, N, SR)
    kL, kR = dsp.pingpong(ksig * 0.7, ksig * 0.3, 0.75 * BEAT, SR, fb=0.45, damp_hz=5000)

    mv, mg = np.zeros(N), np.zeros(N)
    for b in MECH_BARS:
        for e in range(8):
            g = (b - 1) * 8 + e
            t = tb(b, e / 2)
            if g % 3 == 0 and not (b % 4 == 0 and e >= 6):
                s1.place(mv, p3.mech(SR, 'valve', rng), [(t, rng.uniform(0.7, 1.0))], SR)
            if g % 3 == 1 and b >= 33:
                s1.place(mg, p3.mech(SR, 'gear', rng), [(t, rng.uniform(0.6, 1.0))], SR)
    mv *= 0.045
    mg *= 0.03
    gL, gR = dsp.pingpong(mg, mg * 0.2, 0.25 * BEAT, SR, fb=0.35, damp_hz=7000)

    kicks = [tb(b, i) for b in KICK for i in range(4)]
    kick = np.zeros(N)
    s1.place(kick, kick_hit(SR, brk), [(k, 1.0) for k in kicks], SR, p3.GAIN['kick'])
    claps = [tb(b, i) for b in CLAP for i in (1, 3)]
    clap = np.zeros(N)
    s1.place(clap, p2.clap_hit(SR), [(c, 1.0) for c in claps], SR, p3.GAIN['clap'])
    s1.place(clap, p2.clap_hit(SR), [(tb(b, 3.75), 0.35) for b in CLAP if b % 4 == 2], SR, p3.GAIN['clap'])
    hL, hR = np.zeros(N), np.zeros(N)
    for b in HATS:
        lv = 0.6 if b < 9 else 1.0
        for i in range(8):
            if b in SECTION_ENDS and i >= 6:
                continue
            h = s4.spaghetti(SR, rng)
            if b % 2 == 0 and i == 7:
                h = np.concatenate([h, np.zeros(len(h))])
                h = h * np.exp(-np.arange(len(h)) / SR / 0.25) * 2.2
            g = (0.5, 1.0)[i % 2] * rng.uniform(0.8, 1.0) * lv
            p = 0.5 + rng.uniform(-0.25, 0.25)
            s1.place(hL, h, [(tb(b, i / 2), g * (1 - p))], SR)
            s1.place(hR, h, [(tb(b, i / 2), g * p)], SR)
    for b in HAT16:
        for i in range(16):
            if i % 2 == 1 and rng.uniform() < 0.7:
                h = s4.spaghetti(SR, rng) * 0.3
                p = 0.5 + rng.uniform(-0.4, 0.4)
                s1.place(hL, h, [(tb(b, i / 4) + 0.006, 1 - p)], SR)
                s1.place(hR, h, [(tb(b, i / 4) + 0.006, p)], SR)

    sc = s1.sidechain(kicks, N, SR, 0.55, rel=0.18)
    eL, eR = eL * sc * p3.GAIN['engine'], eR * sc * p3.GAIN['engine']
    dt = doots * s1.sidechain(kicks, N, SR, 0.25)
    echo = s1.sidechain(kicks, N, SR, 0.35)
    rl, rr = dsp.reverb(wl * 0.8 + doots * 0.2 + kL * 0.5 + eL * 0.05, wr * 0.8 + doots * 0.2 + kR * 0.5 + eR * 0.05,
                        SR, rt60=6.5, damp_hz=3500)
    sl, sr_ = dsp.reverb(shim, shim, SR, rt60=8.0, damp_hz=5000, mod=6.0)
    hg = p3.GAIN['hats'] * s1.up(1 - 0.5 * mask(tc, R(57, 80), 2), tc, N, SR)
    L = (kick + eL + dt * 0.9 + (eL8 * 0.45 + wl * 0.3 + rl * 0.5) * echo + hL * hg + clap
         + ksig * 0.5 + kL + sl * 0.9 + mv * 0.8 + gL)
    Rr = (kick + eR + dt * 1.1 + (eR8 * 0.45 + wr * 0.3 + rr * 0.5) * echo + hR * hg + clap
          + ksig * 0.5 + kR + sr_ * 0.9 + mv * 1.2 + gR)
    cl_, cr_ = dsp.reverb(clap * 0.25 + hL * 0.06 + mv * 0.3, clap * 0.25 + hR * 0.06 + mv * 0.3, SR, rt60=1.5, damp_hz=7000)
    mix = np.stack([L + cl_, Rr + cr_], 1)
    mix -= mix.mean(0)
    for _ in range(6):
        g = 10 ** ((-10.0 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.2, rel_ms=60)
    mix *= s1.up(np.clip((dur - tc) / 1.5, 0, 1), tc, N, SR)[:, None]
    print(f'render {time.time() - t0:.1f} s')
    stems = {'kick': kick, 'clap': clap, 'droneL': eL, 'droneR': eR, 'doots': doots, 'ks': ksig, 'chop': chop[::48]}
    return mix, stems, kicks, claps, tc, f0, ratio, blend


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--break', dest='brk', choices=['no-chop', 'cold-seam', 'muddy', 'harsh', 'wall', 'old-build'])
    a = ap.parse_args()
    mix, stems, kicks, claps, tc, f0, ratio, blend = render(a.brk)
    name = 'piece4' + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, tc=tc, f0=f0, ratio=ratio, blend=blend, **stems)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'kicks': kicks, 'claps': claps}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
