"""Engine, Learning to Sing. The first full piece, on the cloog.

Mark, after study 5: "you've passed the main hurdle ... it's less about
copying and more about trying to make your cloog sound awesome in its own way,
so have fun." So this one is ours. Borrowed from a reference track: fast
sixteenth doots that echo in eighths and start muffled, clearing over the
intro (its centroid ~245 -> 360 Hz by 0:36); kick-clap-kick-clap. The rest
comes from studies 1-5: the engine, its glides, flips, womp and decorations,
and study 1's ending, where the engine switches off.

F# Dorian, 123 bpm, 112 bars (~3:45).

  python3 piece1.py [--break muffled|late-clap|no-decor]
"""
import argparse
import json
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import study1 as s1
import study2 as s2
import study4 as s4
import study5 as s5
from study4 import SR, CR, BEAT, BAR, HZ, tb

NBARS = 112
TAIL = 7.0

# --- form (bars, inclusive) -------------------------------------------------
# A intro 1-16 | B groove 17-32 | C wake 33-48 | D engine solo 49-64
# E breakdown 65-71, pause 72 | F climax 73-96 | G outro 97-112
R = lambda a, b: list(range(a, b + 1))
KICK = R(17, 64) + R(73, 104)
CLAP = R(21, 64) + R(73, 100)
HATS = R(9, 48) + R(57, 64) + R(73, 104)
HAT16 = R(41, 48) + R(81, 96)              # ghost sixteenths
DOOTS = R(1, 48) + R(65, 71) + R(73, 108)
ENGINE_IDLE = (25, 32)                     # engine turning over, quiet, closed
PAUSE = 72

# the engine's line: (bar, beat, MIDI). F#1=30 G#1=32 A1=33 B1=35 C#2=37 D#2=39 E2=40 F#2=42
BASS = [(25, 0, 30),
        (33, 0, 30), (37, 0, 33), (39, 2, 35), (41, 0, 30), (45, 0, 37), (47, 2, 33),
        (49, 0, 30), (51, 3, 37), (53, 0, 40), (55, 0, 35), (57, 0, 30), (59, 2, 33), (61, 0, 37), (63, 3, 30),
        (66, 0, 30), (69, 0, 33), (71, 0, 30),
        (73, 0, 30), (75, 2, 35), (77, 0, 37), (79, 0, 39), (81, 0, 40), (83, 2, 42), (85, 0, 30),
        (87, 0, 33), (89, 0, 35), (91, 0, 37), (92, 2, 39), (93, 0, 40), (95, 0, 42), (96, 3, 30),
        (97, 0, 30), (105, 0, 33), (107, 0, 30)]
FLIPS = {b: 2.5 for b in (36, 38, 42, 44, 46, 50, 52, 54, 56, 58, 60, 62, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94)}
FLIPS.update({40: 3.5, 48: 3.5, 64: 3.5, 96: 3.5})

DECOR = [  # (bar, beat, kind, attack, hold, decay, amount)
    (36, 0, 'drive', 0.3, 0.8, 1.0, 0.8), (40, 2, 'growl', 0.3, 1.0, 1.0, 0.7),
    (44, 1, 'squelch', 0.2, 0.5, 0.9, 0.8), (47, 0, 'fold', 0.35, 0.8, 1.2, 0.7),
    (50, 0, 'growl', 0.25, 1.4, 1.0, 1.0), (52, 2, 'drive', 0.15, 0.5, 0.7, 1.0),
    (54, 1, 'fold', 0.3, 1.0, 1.0, 0.9), (56, 3, 'squelch', 0.15, 0.3, 0.8, 1.0),
    (58, 0, 'growl', 0.4, 1.8, 1.2, 0.9), (60, 2, 'drive', 0.2, 0.6, 0.9, 0.9),
    (62, 0, 'fold', 0.25, 1.2, 1.0, 1.0), (63, 2, 'squelch', 0.2, 0.4, 1.0, 0.9),
    (76, 2, 'growl', 0.3, 1.0, 0.9, 0.8), (79, 0, 'drive', 0.2, 0.7, 1.0, 1.0),
    (82, 1, 'squelch', 0.15, 0.4, 0.8, 1.0), (85, 0, 'fold', 0.3, 1.0, 1.2, 0.9),
    (87, 2, 'growl', 0.25, 1.6, 1.0, 1.0), (89, 0, 'drive', 0.15, 0.5, 0.6, 1.0),
    (91, 1, 'squelch', 0.2, 0.3, 1.0, 0.9), (93, 0, 'fold', 0.25, 0.9, 0.8, 1.0),
    (94, 2, 'growl', 0.3, 1.2, 1.2, 0.9), (95, 3, 'drive', 0.2, 0.7, 1.0, 0.9),
]
# filter sweeps on the engine: (bar, bars up, bars down, octaves)
SWEEPS = [(43, 2, 2, 1.2), (51, 1, 3, 1.5), (55, 2, 2, 1.0), (59, 1, 1, 1.4), (61, 2, 2, 1.6),
          (80, 2, 2, 1.0), (88, 1, 3, 1.5), (92, 2, 2, 1.3)]

# doots: one bar of sixteenths, grouped 3-3-2-3-3-2 (MIDI); a second bar varies the tail
DOOT_A = [66, 61, 57, 66, 61, 57, 64, 61, 66, 61, 57, 66, 61, 57, 69, 64]
DOOT_B = [66, 61, 57, 66, 61, 57, 64, 61, 66, 61, 57, 66, 71, 69, 64, 61]
ACCENT = [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0]


def ramp(tc, a, b, lo=0.0, hi=1.0):
    """Linear from lo at time a to hi at time b, held outside."""
    return lo + (hi - lo) * np.clip((tc - a) / max(b - a, 1e-9), 0, 1)


def clarity(tc, brk=None):
    """How open the doots' filter is: muffled through the intro, clearing
    over bars 5-20, dark again in the outro."""
    if brk == 'muffled':
        return np.zeros(len(tc))
    c = ramp(tc, tb(5), tb(21)) * 0.85 + ramp(tc, tb(73), tb(77)) * 0.15
    c = c - ramp(tc, tb(97), tb(109)) * 0.9
    return np.clip(c, 0, 1)


def mask(tc, bars, ramp_s=0.03):
    m = np.zeros(len(tc))
    for b in bars:
        m[(tc >= tb(b)) & (tc < tb(b + 1))] = 1
    k = max(1, int(ramp_s * CR))
    return np.convolve(m, np.ones(k) / k, mode='same')


def kick_hit(sr):
    """Study 3's kick (fitted to reference A's decay), its tail tuned to F#1."""
    t = np.arange(int(0.4 * sr)) / sr
    f = HZ(30) + 150 * np.exp(-t / 0.018) + 28 * np.exp(-t / 0.08)
    env = np.exp(-np.clip(t - 0.03, 0, None) / 0.09) * np.clip(t / 0.0006, 0, 1)
    x = np.sin(2 * np.pi * np.cumsum(f) / sr) * env
    click = dsp.butter(np.random.default_rng(1).standard_normal(len(t)), (2000, 7000), sr, 'band') * np.exp(-t / 0.0025)
    return np.tanh(1.2 * (x + 0.15 * click)) / np.tanh(1.2)


def doot(sr, hz, open_, accent):
    """Study 4's round pluck, its filter set by how clear the doots are."""
    t = np.arange(int(0.5 * sr)) / sr
    x = 0.7 * dsp.saw(np.full(len(t), hz), sr) + 0.3 * np.sign(np.sin(np.pi * hz * t))
    cut = 260 + open_ * 1900 + (500 + 1800 * open_) * np.exp(-t / 0.04) * (0.6 + 0.4 * accent)
    y = dsp.ladder(x, cut, sr, res=0.22 + 0.15 * open_, drive=1.3)
    return y * np.exp(-np.clip(t - 0.005, 0, None) / 0.12) * np.clip(t / 0.002, 0, 1)


def engine(tc, brk=None):
    f_line = s4.glide_curve(tc, BASS, s4.GLIDE)
    flips = np.ones(len(tc))
    for bar, beat in FLIPS.items():
        s = tb(bar, beat)
        flips[(tc >= s) & (tc < s + 0.5 * BEAT)] = 2.0
    flips = np.exp(np.convolve(np.log(flips), np.ones(12) / 12, mode='same'))
    f0 = f_line * flips
    # engine level: idle (quiet, closed) 25-32, awake 33-64, breakdown wake
    # 66-71, climax 73-96, fade 97-108, switch-off after
    idle = mask(tc, R(*ENGINE_IDLE), 2.0) * 0.35
    awake = mask(tc, R(33, 64) + R(73, 96), 0.5) * ramp(tc, tb(33), tb(35))
    wake2 = mask(tc, R(66, 71), 0.5) * ramp(tc, tb(66), tb(71), 0.0, 0.9)
    outro = mask(tc, R(97, 112), 0.5) * ramp(tc, tb(97), tb(109), 1.0, 0.3)
    lvl = np.maximum.reduce([idle, awake, wake2, outro])
    # filter: base opening per section, slow drift, sweeps
    base = (220 + 300 * mask(tc, R(33, 48), 2) + 700 * mask(tc, R(49, 64), 2) + 300 * mask(tc, R(66, 71), 2)
            * ramp(tc, tb(66), tb(71)) + 1000 * mask(tc, R(73, 96), 1) * ramp(tc, tb(73), tb(85), 0.5, 1.0)
            + 400 * mask(tc, R(97, 112), 2) * ramp(tc, tb(97), tb(109), 1, 0))
    base *= 1 + 0.2 * np.sin(2 * np.pi * tc / (16 * BAR) + 1.3)
    sw = np.zeros(len(tc))
    for bar, up_, dn, octv in SWEEPS:
        a, p, z = tb(bar), tb(bar + up_), tb(bar + up_ + dn)
        sw += octv * np.where(tc < p, ramp(tc, a, p), 1 - ramp(tc, p, z)) * (tc >= a) * (tc < z)
    depth = s5.womp_depth(tc) * mask(tc, R(33, 96), 4)
    w = s5.womp_curve(tc, depth)
    cut = base * 2 ** sw * (0.6 + 0.4 * w) * (f_line / HZ(30)) ** 0.8
    # switch-off: after the last bar, the pitch falls to 24 Hz and the engine dies
    tend = tb(NBARS - 3)
    off = tc >= tend
    f0 = np.where(off, f0 * np.exp(-np.clip(tc - tend, 0, None) / 1.6) + 24 * (1 - np.exp(-np.clip(tc - tend, 0, None) / 1.6)), f0)
    lvl = lvl * np.where(off, np.clip(1 - (tc - tend) / 5.0, 0, 1), 1)
    dc = {k: np.zeros(len(tc)) for k in s5.KINDS}
    if brk != 'no-decor':
        for bar, beat, kind, att, hold, dec, amt in DECOR:
            dc[kind] = np.maximum(dc[kind], amt * s5.analog_env(tc, tb(bar, beat), att, hold, dec))
    return f0, cut, lvl * w, dc


def render(brk=None):
    t0 = time.time()
    dur = NBARS * BAR + TAIL
    N = int(dur * SR)
    tc = np.arange(int(dur * CR)) / CR
    pad = lambda z: np.pad(z, (0, max(0, N - len(z))))[:N]

    f0, cut, amp, dc = engine(tc, brk)
    eL, eR = (pad(z) for z in s5.drone(tc, f0, cut, amp, dc))

    # doots: continuous sixteenths, eighth-note echo, a warbling wash
    cl = clarity(tc, brk)
    doots = np.zeros(N)
    cache = {}
    dm = mask(tc, DOOTS)
    for bar in DOOTS:
        pat = DOOT_B if bar % 4 == 0 else DOOT_A
        for i, m in enumerate(pat):
            te = tb(bar) + i * BEAT / 4
            o = round(float(np.interp(te, tc, cl)), 2)
            key = (m, o, ACCENT[i])
            if key not in cache:
                cache[key] = doot(SR, HZ(m), o, ACCENT[i])
            s1.place(doots, cache[key], [(te, 0.75 + 0.25 * ACCENT[i])], SR)
    # fade the doots in over the first bars and out at the end
    doots *= s1.up(ramp(tc, 0, tb(3), 0.3, 1.0) * ramp(tc, tb(105), tb(109), 1.0, 0.0), tc, N, SR) * 0.11
    eL8 = dsp.tapedelay(doots, SR, 0.5 * BEAT, wow_ms=1.5, wow_hz=0.4, fb=0.5, damp_hz=2600, phase=0.0)
    eR8 = dsp.tapedelay(doots, SR, 0.5 * BEAT + 0.011, wow_ms=1.8, wow_hz=0.47, fb=0.5, damp_hz=2400, phase=1.7)
    wl = dsp.tapedelay(doots, SR, 0.75 * BEAT, wow_ms=3.5, wow_hz=0.55, fb=0.6, damp_hz=2200, phase=0.4)
    wr = dsp.tapedelay(doots, SR, 1.0 * BEAT, wow_ms=4.0, wow_hz=0.71, fb=0.58, damp_hz=2000, phase=2.3)
    rl, rr = dsp.reverb(wl * 0.8 + doots * 0.2, wr * 0.8 + doots * 0.2, SR, rt60=6.5, damp_hz=3500)

    # drums
    kicks = [tb(b, i) for b in KICK for i in range(4)]
    kick = np.zeros(N)
    s1.place(kick, kick_hit(SR), [(k, 1.0) for k in kicks], SR)
    claps = [tb(b, i) + (0.012 if brk == 'late-clap' else 0.0) for b in CLAP for i in (1, 3)]
    clap = np.zeros(N)
    s1.place(clap, s2.clap_hit(SR), [(c, 1.0) for c in claps], SR, 0.14)
    rng = np.random.default_rng(5)
    hL, hR = np.zeros(N), np.zeros(N)
    for b in HATS:
        lvl = 0.6 if b < 17 else 1.0
        for i in range(8):
            h = s4.spaghetti(SR, rng)
            g = (0.5, 1.0)[i % 2] * rng.uniform(0.85, 1.0) * lvl
            p = 0.5 + rng.uniform(-0.25, 0.25)
            s1.place(hL, h, [(tb(b, i / 2), g * (1 - p))], SR)
            s1.place(hR, h, [(tb(b, i / 2), g * p)], SR)
    for b in HAT16:
        for i in range(16):
            if i % 2 == 1 and rng.uniform() < 0.7:
                h = s4.spaghetti(SR, rng) * 0.3
                p = 0.5 + rng.uniform(-0.4, 0.4)
                s1.place(hL, h, [(tb(b, i / 4), 1 - p)], SR)
                s1.place(hR, h, [(tb(b, i / 4), p)], SR)

    # mix
    sc = s1.sidechain(kicks, N, SR, 0.6, rel=0.18)
    eL, eR = eL * sc * 0.40, eR * sc * 0.40
    dt = doots * s1.sidechain(kicks, N, SR, 0.25)
    echo = s1.sidechain(kicks, N, SR, 0.35)
    L = kick + eL + dt * 0.9 + (eL8 * 0.45 + wl * 0.3 + rl * 0.5) * echo + hL * 0.45 + clap
    Rr = kick + eR + dt * 1.1 + (eR8 * 0.45 + wr * 0.3 + rr * 0.5) * echo + hR * 0.45 + clap
    cl_, cr_ = dsp.reverb(clap * 0.6 + eL * 0.04 + hL * 0.08, clap * 0.6 + eR * 0.04 + hR * 0.08, SR, rt60=2.2, damp_hz=7000)
    mix = np.stack([L + cl_, Rr + cr_], 1)
    mix -= mix.mean(0)
    for _ in range(6):
        g = 10 ** ((-10.0 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.2, rel_ms=60)
    fade = s1.up(np.clip((dur - tc) / 1.5, 0, 1), tc, N, SR)
    mix *= fade[:, None]
    print(f'render {time.time() - t0:.1f} s')
    stems = {'kick': kick, 'clap': clap, 'droneL': eL, 'droneR': eR, 'doots': doots}
    return mix, stems, kicks, claps, tc, f0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--break', dest='brk', choices=['muffled', 'late-clap', 'no-decor'])
    a = ap.parse_args()
    mix, stems, kicks, claps, tc, f0 = render(a.brk)
    name = 'piece1' + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, tc=tc, f0=f0, **stems)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'kicks': kicks, 'claps': claps}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
