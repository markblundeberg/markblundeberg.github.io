"""Study 5: study 4's arc, with the engine played the way the reference track plays its own.

Mark on study 4: the dotted womp, but never that strong, and it comes and
goes; brief decorations, distortions switched in and out with analog-feeling
attack and decay, an amplitude modulator that turns the drone into a growl;
and the drone sometimes kicks up an octave for a moment.
Measured on reference A's solo drone (2:41-3:05): 8 flips in 25 s, each about one
octave, one eighth long (0.22-0.27 s), mostly starting on the "and" of beat 3
and landing as the next kick hits; the low fundamental vanishes meanwhile.

  python3 study5.py [--break no-flips|no-decor|steady-womp]
"""
import argparse
import json
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

import dsp
import study1 as s1
import study3 as s3
import study4 as s4
from study4 import SR, OS, CR, BEAT, BAR, NBARS, TAIL, HZ, tb

# octave flips: bar -> start beat (0-based, "and" of 3 is 2.5); one eighth long
FLIPS = {14: 2.5, 16: 2.5, 18: 3.5, 20: 2.5, 21: 2.5, 23: 2.5, 24: 3.0, 25: 2.5, 29: 2.5, 30: 2.5, 31: 3.5}
FLIP_LEN = 0.5   # beats

# decorations: (bar, beat, kind, attack s, hold s, decay s, amount)
DECOR = [
    (14, 0, 'drive', 0.25, 0.6, 0.9, 1.0),
    (16, 2, 'growl', 0.3, 1.0, 1.0, 0.8),
    (18, 1, 'squelch', 0.15, 0.4, 0.8, 1.0),
    (20, 0, 'fold', 0.35, 0.8, 1.2, 0.8),
    (22, 2, 'growl', 0.2, 1.4, 0.9, 1.0),
    (24, 1, 'drive', 0.15, 0.5, 0.6, 1.0),
    (25, 2, 'squelch', 0.2, 0.3, 1.0, 0.9),
    (26, 0, 'fold', 0.25, 0.9, 0.7, 1.0),
    (29, 2, 'growl', 0.4, 1.2, 1.2, 0.9),
    (30, 3, 'drive', 0.2, 0.7, 1.0, 0.9),
]
KINDS = ('drive', 'growl', 'squelch', 'fold')


def analog_env(tc, t0, att, hold, dec):
    """Rises like a charging capacitor, holds, discharges: no hard edges."""
    a = 1 - np.exp(-np.clip(tc - t0, 0, None) / (att / 3))
    a *= tc >= t0
    t1 = t0 + att + hold
    d = np.exp(-np.clip(tc - t1, 0, None) / (dec / 3))
    return a * np.where(tc >= t1, d, 1.0)


def decor_curves(tc, enabled=True):
    c = {k: np.zeros(len(tc)) for k in KINDS}
    if enabled:
        for bar, beat, kind, att, hold, dec, amt in DECOR:
            c[kind] = np.maximum(c[kind], amt * analog_env(tc, tb(bar, beat), att, hold, dec))
    return c


def womp_depth(tc, steady=False):
    """Depth in dB that wanders between 0 and ~8 over phrases: the womp comes
    and goes. A smooth random curve, so no two phrases match."""
    if steady:
        return np.full(len(tc), 8.0)
    r = np.random.default_rng(11).standard_normal(int(len(tc) / CR / BAR) + 3)
    knots = np.arange(len(r)) * BAR * 1.5
    d = np.interp(tc, knots, r)
    d = signal.savgol_filter(d, 2001, 3) if len(d) > 2001 else d
    d = (d - d.min()) / (d.max() - d.min() + 1e-9)
    return 8.0 * np.clip(d * 1.4 - 0.25, 0, 1)


def womp_curve(tc, depth_db):
    cyc = 0.75 * BEAT
    u = (tc / cyc) % 1
    shape = np.sin(np.pi * np.clip(u / 0.85, 0, 1)) ** 1.3
    floor = 10 ** (-depth_db / 20)
    return floor + (1 - floor) * shape


def flip_curve(tc, enabled=True):
    """Multiplier on f0: 2 during each flip, with a 12 ms slew."""
    m = np.ones(len(tc))
    if enabled:
        for bar, beat in FLIPS.items():
            s = tb(bar, beat)
            m[(tc >= s) & (tc < s + FLIP_LEN * BEAT)] = 2.0
    k = 12
    return np.exp(np.convolve(np.log(m), np.ones(k) / k, mode='same'))


def tube(x, d):
    """Asymmetric soft clip after the filter, like a valve stage or a pedal:
    the bias makes it clip one side first, adding even harmonics. d in 0..1
    turns it from study 4's gentle tanh into a hot, lopsided one."""
    k = 1.3 * (1 + 3.0 * d)
    bias = 0.25 * d
    y = (np.tanh(k * (x + bias)) - np.tanh(k * bias)) / np.tanh(1.3)
    return y / (1 + 1.2 * d)


def drone(tc, f0, cut, amp, dc):
    """The engine with its decorations. drive: more input drive into the
    ladder and a hotter tanh; fold: a sine wavefolder blended in; growl: deep
    amplitude modulation at f0/2; squelch: resonance pushed near
    self-oscillation with the cutoff lifted."""
    nos, sro = int(len(tc) / CR * SR) * OS, SR * OS
    n = nos // OS
    U = lambda c: s1.up(c, tc, nos, sro)
    vs = []
    for v, dct in enumerate([-7.0, 0.0, 6.0]):
        cents = dct + s1.drift(len(tc), CR, 3.5, seed=10 + v)
        vs.append(dsp.saw(U(f0 * 2 ** (cents / 1200)), sro, phase=0.31 * v))
    sq = dc['squelch']
    cut_os = U(cut * (1 + 1.5 * sq))
    drive = U(dc['drive'])
    fold = U(dc['fold'])
    fold_gain_max = 6.0
    fold_gain = 1.5 + 4.5 * fold
    growl = U(0.10 + 0.75 * dc['growl'])
    ph = 2 * np.pi * np.cumsum(U(f0) / 2) / sro
    out = []
    # resonance can't vary per sample in the kernel, so the squelch is a
    # crossfade between a normal and a near-oscillating ladder
    sqo = U(sq)
    for w in ((0.55, 0.3, 0.15), (0.15, 0.3, 0.55)):
        x = sum(a * v for a, v in zip(w, vs))
        b = dsp.ladder(x, cut_os, sro, res=0.42, drive=1.6)
        if sq.max() > 0:
            bq = dsp.ladder(x, cut_os, sro, res=0.92, drive=1.6)
            b = b * (1 - sqo) + bq * sqo
        b = b * (1 + growl * np.sin(ph)) / (1 + 0.5 * growl)
        y = tube(b, drive)
        folded = np.sin(fold_gain * b) / np.sin(min(fold_gain_max, np.pi / 2))
        y = y * (1 - fold) + folded * fold
        out.append(signal.resample_poly(y, 1, OS)[:n])
    L, R = out
    low = dsp.butter((L + R) / 2, 150, SR, 'low', 4)
    a = s1.up(amp, tc, n, SR)
    return (low + dsp.butter(L, 150, SR, 'high', 4)) * a, (low + dsp.butter(R, 150, SR, 'high', 4)) * a


def render(brk=None):
    t0 = time.time()
    dur = NBARS * BAR + TAIL
    N = int(dur * SR)
    tc = np.arange(int(dur * CR)) / CR

    f0 = s4.glide_curve(tc, s4.BASS, s4.GLIDE) * flip_curve(tc, brk != 'no-flips')
    wake = np.clip((tc - tb(s4.DRONE_FROM)) / (2 * BAR), 0, 1)
    opened = np.clip((tc - tb(s4.OPEN_AT - 1)) / (2 * BAR), 0, 1)
    climb = np.clip((tc - tb(19)) / (8 * BAR), 0, 1)
    depth = womp_depth(tc, steady=brk == 'steady-womp')
    w = womp_curve(tc, depth)
    base = s4.glide_curve(tc, s4.BASS, s4.GLIDE)       # cutoff tracks the line, not the flips
    cut = (220 + 500 * wake + 900 * opened + 700 * climb) * (0.6 + 0.4 * w) * (base / HZ(30)) ** 0.8
    present = (tc >= tb(s4.DRONE_FROM)) & ~((tc >= tb(s4.PAUSE)) & (tc < tb(s4.PAUSE + 1)))
    pres = np.convolve(present.astype(float), np.ones(40) / 40, mode='same')
    end = np.clip(1 - (tc - tb(NBARS + 1)) / 3.0, 0, 1)
    amp = wake ** 1.5 * w * pres * end
    dc = decor_curves(tc, brk != 'no-decor')
    dL, dR = (np.pad(z, (0, max(0, N - len(z))))[:N] for z in drone(tc, f0, cut, amp, dc))

    # everything else is study 4's
    doots = np.zeros(N)
    cache = {}
    for bar in s4.DOOTS:
        for st, m in s4.DOOT:
            if (st >= 16) != ((bar - 1) % 2 == 1):
                continue
            te = tb(bar) + (st % 16) * BEAT / 4
            br = 0.35 + 0.65 * float(np.interp(te, tc, opened)) + 0.15 * (st % 8 == 0)
            key = (m, round(br, 2))
            if key not in cache:
                cache[key] = s4.doot(SR, HZ(m), min(br, 1.0))
            s1.place(doots, cache[key], [(te, 0.9 + 0.1 * (st % 3 == 0))], SR)
    doots *= 0.16
    wl = dsp.tapedelay(doots, SR, 0.75 * BEAT, wow_ms=3.5, wow_hz=0.55, fb=0.62, damp_hz=2400, phase=0.0)
    wr = dsp.tapedelay(doots, SR, 1.0 * BEAT, wow_ms=4.0, wow_hz=0.71, fb=0.6, damp_hz=2200, phase=2.0)
    rl, rr = dsp.reverb(wl * 0.8 + doots * 0.2, wr * 0.8 + doots * 0.2, SR, rt60=6.0, damp_hz=3500)
    washL, washR = wl * 0.55 + rl, wr * 0.55 + rr
    kicks = [tb(b, i) for b in s4.KICK for i in range(4)]
    kick = np.zeros(N)
    s1.place(kick, s3.kick_hit(SR), [(k, 1.0) for k in kicks], SR)
    rng = np.random.default_rng(5)
    hL, hR = np.zeros(N), np.zeros(N)
    for b in s4.HATS:
        for i in range(8):
            h = s4.spaghetti(SR, rng)
            g = (0.55, 1.0)[i % 2] * rng.uniform(0.85, 1.0)
            p = 0.5 + rng.uniform(-0.2, 0.2)
            s1.place(hL, h, [(tb(b, i / 2), g * (1 - p))], SR)
            s1.place(hR, h, [(tb(b, i / 2), g * p)], SR)
    sc = s1.sidechain(kicks, N, SR, 0.6, rel=0.18)
    dL, dR = dL * sc * 0.42, dR * sc * 0.42
    dt = doots * s1.sidechain(kicks, N, SR, 0.25)
    L = kick + dL + dt * 0.95 + washL * 0.5 + hL * 0.5
    R = kick + dR + dt * 1.05 + washR * 0.5 + hR * 0.5
    rL, rR = dsp.reverb(dL * 0.05 + hL * 0.1, dR * 0.05 + hR * 0.1, SR, rt60=2.5, damp_hz=8000)
    mix = np.stack([L + rL, R + rR], 1)
    mix -= mix.mean(0)
    for _ in range(6):
        g = 10 ** ((-10.0 - dsp.lufs(mix, SR)) / 20)
        mix = dsp.limiter(mix * g, SR, ceiling_db=-1.2, rel_ms=60)
    print(f'render {time.time() - t0:.1f} s')
    return mix, {'kick': kick, 'droneL': dL, 'droneR': dR}, kicks, tc, f0, depth


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--break', dest='brk', choices=['no-flips', 'no-decor', 'steady-womp'])
    a = ap.parse_args()
    mix, stems, kicks, tc, f0, depth = render(a.brk)
    name = 'study5' + (f'_BROKEN-{a.brk}' if a.brk else '')
    wavfile.write(f'out/{name}.wav', SR, mix.astype(np.float32))
    np.savez_compressed(f'out/{name}_stems.npz', sr=SR, tc=tc, f0=f0, depth=depth, **stems)
    with open(f'out/{name}_score.json', 'w') as fh:
        json.dump({'kicks': kicks, 'womp': 'dotted'}, fh)
    print('wrote', f'out/{name}.wav')


if __name__ == '__main__':
    main()
