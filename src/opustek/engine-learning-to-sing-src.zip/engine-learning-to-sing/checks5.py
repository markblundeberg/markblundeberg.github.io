"""Checks for study 5.  python3 checks5.py   (renders the no-decor twin, then
compares), or --selftest."""
import json
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

import checks4
import dsp
import study5 as s5
from study4 import BEAT, BAR, HZ, tb


def f0_at(x, sr, a, b, want):
    """Harmonic-sum pitch near `want` (+/-0.6 octave), on a short window."""
    seg = x[int(a * sr):int(b * sr)]
    y = signal.resample_poly(seg, 1, 4)
    nf = 1 << 17
    X = np.log(np.abs(np.fft.rfft(y * np.hanning(len(y)), nf)) + 1e-12)
    f = np.fft.rfftfreq(nf, 4 / sr)
    c = want * 2 ** np.linspace(-0.6, 0.6, 1441)
    H = [sum(X[min(len(X) - 1, int(round(cc * h / f[1])))] for h in (1, 2, 3)) for cc in c]
    return c[int(np.argmax(H))]


def flips(st):
    """Each flip in a drone bar reads an octave (+/-60 c) above the eighth before it."""
    sr, x = int(st['sr']), (st['droneL'] + st['droneR']) / 2
    tc, f0 = st['tc'], st['f0']
    ok, n, bad = 0, 0, []
    for bar, beat in s5.FLIPS.items():
        s = tb(bar, beat)
        base = float(np.interp(s - 0.15, tc, f0))
        if np.abs(x[int((s - 0.3) * sr):int(s * sr)]).max() < 1e-3:
            continue
        n += 1
        fb = f0_at(x, sr, s - 0.26, s - 0.02, base)
        ff = f0_at(x, sr, s + 0.03, s + s5.FLIP_LEN * BEAT - 0.02, base * 2)
        c = 1200 * np.log2(ff / fb)
        if abs(c - 1200) <= 60:
            ok += 1
        else:
            bad.append(f'bar {bar}: {c:+.0f} c')
    return ok >= 0.8 * n and n >= 6, f'{ok}/{n} flips an octave up' + ('' if not bad else '; ' + ', '.join(bad[:3]))


def womp_varies(st):
    """The womp comes and goes: the dotted-eighth modulation index of the
    drone's level, per two-bar window, spans at least 2x (6 dB) between
    phrases, and never exceeds 0.6 (Mark: never that strong)."""
    sr, x = int(st['sr']), (st['droneL'] + st['droneR']) / 2
    fd = 1 / (0.75 * BEAT)
    mi = []
    for b in (13, 15, 17, 19, 21, 23, 25, 28, 30):
        e = checks4.env(x[int(tb(b) * sr):int(tb(b + 2) * sr)], sr, 30, 2000)
        if e.mean() < 1e-4:
            continue
        w = np.hanning(len(e))
        E = np.fft.rfft((e - e.mean()) * w, 1 << 17)
        f = np.fft.rfftfreq(1 << 17, 1 / 1000)
        mi.append(2 * np.abs(E[np.argmin(np.abs(f - fd))]) / w.sum() / e.mean())
    mi = np.array(mi)
    ok = mi.max() / max(mi.min(), 1e-3) >= 2 and mi.max() <= 0.6
    return ok, f'dotted modulation index per phrase {np.round(mi, 2)}'


def features(x, sr, a, b, f0):
    seg = x[int(a * sr):int(b * sr)]
    f, P = signal.welch(seg, sr, nperseg=4096)
    hi = 10 * np.log10(P[(f > 2000) & (f < 8000)].sum() / P[(f > 30) & (f < 8000)].sum())
    half = sum(P[np.argmin(np.abs(f - (k + 0.5) * f0))] for k in range(1, 12))
    whole = sum(P[np.argmin(np.abs(f - k * f0))] for k in range(1, 12))
    even = sum(P[np.argmin(np.abs(f - k * f0))] for k in range(2, 13, 2))
    odd = sum(P[np.argmin(np.abs(f - k * f0))] for k in range(1, 12, 2))
    return hi, 10 * np.log10(half / whole), 10 * np.log10(even / odd)


def spec_change(x, y, sr, a, b):
    """Mean absolute level difference over third-octave bands 100 Hz-10 kHz."""
    f, P = signal.welch(x[int(a * sr):int(b * sr)], sr, nperseg=4096)
    _, Q = signal.welch(y[int(a * sr):int(b * sr)], sr, nperseg=4096)
    cf = 100 * 2 ** (np.arange(0, 20) / 3)
    d = [10 * np.log10(P[(f >= c / 2 ** (1 / 6)) & (f < c * 2 ** (1 / 6))].sum() /
                       Q[(f >= c / 2 ** (1 / 6)) & (f < c * 2 ** (1 / 6))].sum()) for c in cf]
    return float(np.mean(np.abs(d)))


def decorations(st, twin):
    """Against the no-decor twin, on a steady-pitch window at each
    decoration's peak: growl raises half-harmonic sidebands >= 6 dB; drive,
    fold and squelch change the spectrum by >= 1.5 dB on average across
    third-octave bands (in a bright passage they change texture more than
    any one feature, so no single feature is a fair test)."""
    sr = int(st['sr'])
    x = (st['droneL'] + st['droneR']) / 2
    y = (twin['droneL'] + twin['droneR']) / 2
    out, ok = [], 0
    for bar, beat, kind, att, hold, dec, amt in s5.DECOR:
        a, b = None, None
        for s0 in np.arange(tb(bar, beat) + att * 0.7, tb(bar, beat) + att + hold + 0.2, 0.02):
            m = (twin['tc'] >= s0) & (twin['tc'] < s0 + 0.3)
            if np.ptp(np.log(twin['f0'][m])) < 0.01:
                a, b = s0, s0 + 0.3
                break
        if a is None:
            out.append(f'{kind}@{bar}:no steady window')
            continue
        f0 = float(np.interp(a, st['tc'], twin['f0']))
        hx, gx, ex = features(x, sr, a, b, f0)
        hy, gy, ey = features(y, sr, a, b, f0)
        # what each effect adds: growl -> half-harmonic sidebands; the tube's
        # bias -> even harmonics; fold and squelch -> upper-band energy
        if kind == 'growl':
            d, good = gx - gy, gx - gy >= 6
        else:
            d = spec_change(x, y, sr, a, b)
            good = d >= 1.5
        ok += good
        out.append(f'{kind}@{bar}:{d:+.1f}')
    return ok == len(s5.DECOR), ' '.join(out)


def soft_edges():
    """Decoration envelopes have no hard edges: 10-90% rise >= 40% of the
    nominal attack, and no step bigger than 2% per millisecond."""
    tc = np.arange(0, 5, 0.001)
    worst = 0
    for att in (0.15, 0.25, 0.4):
        e = s5.analog_env(tc, 1.0, att, 0.5, 0.8)
        r = tc[np.argmax(e > 0.9)] - tc[np.argmax(e > 0.1)]
        worst = max(worst, np.abs(np.diff(e)).max())
        if r < 0.4 * att:
            return False, f'rise {r * 1000:.0f} ms for attack {att * 1000:.0f} ms'
    return worst < 0.02, f'largest step {worst * 100:.2f}% per ms'


def run(stem, twin_stem='out/study5_BROKEN-no-decor'):
    st = np.load(stem + '_stems.npz')
    tw = np.load(twin_stem + '_stems.npz')
    res = [('flips', *flips(st)), ('womp comes and goes', *womp_varies(st)),
           ('decorations audible', *decorations(st, tw)), ('soft edges', *soft_edges())]
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    print(' -- shared checks:')
    r4 = checks4.run(stem)
    return {**{n: ok for n, ok, _ in res}, **r4}


def render(brk=None):
    subprocess.check_call([sys.executable, 'study5.py'] + (['--break', brk] if brk else []), stdout=subprocess.DEVNULL)


if __name__ == '__main__':
    render('no-decor')
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        for brk, which in (('no-flips', 'flips'), ('steady-womp', 'womp comes and goes')):
            render(brk)
            r = run(f'out/study5_BROKEN-{brk}')
            print(f'== {brk}: {which}', 'caught' if not r[which] else 'NOT CAUGHT')
        r = run('out/study5_BROKEN-no-decor')
        print('== no-decor (vs itself): decorations audible', 'caught' if not r['decorations audible'] else 'NOT CAUGHT')
    else:
        r = run('out/study5')
        print('ALL PASS' if all(r.values()) else 'SOME FAIL: ' + ', '.join(k for k, v in r.items() if not v))
