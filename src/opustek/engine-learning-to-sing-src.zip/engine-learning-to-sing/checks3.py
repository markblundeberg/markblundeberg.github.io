"""Checks for study 3, judged partly against the references (ref/, not in git).
  python3 checks3.py out/study3      python3 checks3.py --selftest"""
import json
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

import checks
import dsp
from study1 import t_bar

REFS = ['ref/a.wav', 'ref/b.wav']


def side_mid(x, sr, lo, hi, t0=None, t1=None):
    if t0 is not None:
        x = x[int(t0 * sr):int(t1 * sr)]
    m, s = x.mean(1), (x[:, 0] - x[:, 1]) / 2
    f, P = signal.welch(m, sr, nperseg=8192)
    _, Ps = signal.welch(s, sr, nperseg=8192)
    k = (f >= lo) & (f < hi)
    return 10 * np.log10(Ps[k].sum() / P[k].sum())


def air(x, sr):
    m = x.mean(1)
    f, P = signal.welch(m, sr, nperseg=8192)
    return 10 * np.log10(P[(f > 5000) & (f < 12000)].sum() / P[(f > 40) & (f < 12000)].sum())


def crest(x, sr):
    m = x.mean(1)
    return float(np.median([20 * np.log10(np.abs(m[i:i + sr]).max() / np.sqrt((m[i:i + sr] ** 2).mean()))
                            for i in range(0, len(m) - sr, sr) if np.abs(m[i:i + sr]).max() > 1e-3]))


def run(stem):
    sr, x = wavfile.read(stem + '.wav')
    x = x.astype(np.float64)
    st = np.load(stem + '_stems.npz')
    sc = json.load(open(stem + '_score.json'))
    ref_air = np.mean([air(wavfile.read(r)[1][: 48000 * 200].astype(np.float64), 48000) for r in REFS])
    w = side_mid(x, sr, 300, 3000, t_bar(9), t_bar(25))
    b = side_mid(x, sr, 30, 100)
    a = air(x, sr)
    c = crest(x, sr)
    res = [('kick on the grid', *checks.kick_sync(st, sc)),
           ('wide above 300 Hz', w >= -10, f'side/mid 300-3000 Hz {w:.1f} dB (refs -5..-8; need >= -10)'),
           ('mono bass', b <= -20, f'side/mid 30-100 Hz {b:.1f} dB (need <= -20)'),
           ('punch', c >= 8, f'median crest {c:.1f} dB (refs 9-10; need >= 8)'),
           ('air', abs(a - ref_air) <= 4, f'5-12 kHz share {a:.1f} dB vs refs {ref_air:.1f} (within 4)')]
    lw = side_mid(np.stack([st['leadL'], st['leadR']], 1), sr, 300, 3000, t_bar(9), t_bar(25))
    res.append(('lead is wide', lw >= -6, f'lead stem side/mid {lw:.1f} dB (need >= -6)'))
    res += [r for r in checks.levels(x, sr) if r[0] != 'loudness']
    L = dsp.lufs(x, sr)
    res.append(('loudness', abs(L + 10) <= 0.6, f'{L:.2f} LUFS (target -10)'))
    for n, ok, msg in res:
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {msg}")
    return {n: ok for n, ok, _ in res}


if __name__ == '__main__':
    if sys.argv[1] == '--selftest':
        for brk, which in (('mono-lead', 'lead is wide'), ('mono-mix', 'wide above 300 Hz'), ('squash', 'punch')):
            subprocess.check_call([sys.executable, 'study3.py', '--break', brk], stdout=subprocess.DEVNULL)
            r = run(f'out/study3_BROKEN-{brk}')
            print(f'== {brk}: {which}', 'caught' if not r[which] else 'NOT CAUGHT')
    else:
        r = run(sys.argv[1])
        print('ALL PASS' if all(r.values()) else 'SOME FAIL')
