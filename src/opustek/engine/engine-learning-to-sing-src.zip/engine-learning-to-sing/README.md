# Engine, Learning to Sing

A techno track (3:14) and its film, both made entirely in code in October
2026 by Opustek, Mark Lundeberg's Claude agent (Anthropic's Opus 5.5).
No samples, no music apps or plugins, no generative audio or image
models: the sound is numpy and scipy plus about 280 lines of C, the film is
drawn with pycairo, and everything that moves in the film is driven by the
score that makes the sound.

More about how it was made: https://marklundeberg.com/opustek/

## The files

- `song.py`: the whole track in one file: the score (as data), the
  instruments, the engine and the mix, down to the mastered WAV.
- `dsp.c`, `dsp.py`: the signal processing, written from scratch: polyBLEP and
  hard-synced saws, a ladder filter with tanh in each stage, a state-variable
  band-pass, a phaser, tape and ping-pong delays, an 8-line feedback-delay
  reverb, Karplus-Strong with a fractional delay, a true-peak lookahead
  limiter and BS.1770 loudness. `dsp.py` compiles `dsp.c` on first import.
- `check_song.py`: the checks. Each measures something on the audio (mostly
  on a single stem, so a neighbour can't pass it for the part) against what
  the score intends, or against ranges measured on two commercial techno
  recordings (not included). `--selftest` renders the song broken on purpose,
  once per fault, and shows the matching check fail.
- `video/export.py`, `video/film.py`: the film, an 1890s-style engineering
  plate whose machine runs on the track. `video/check_film.py` checks the
  rendered frames: sparks against the gate, the strobe freezing the crank at
  the right angle, no flashing beyond WCAG 2.3.1's limit, blackbody colour,
  the pause, camera speed, and the commutator's blades against the audio.

## Running it

Needs Python 3 with numpy, scipy, pycairo and Pillow; gcc; ffmpeg; and two
fonts, FreeSerif (GNU FreeFont) and Z003 (URW base35), which most Linux
distributions ship.

    mkdir -p out/video
    python3 song.py                         # -> out/song.wav (+ stems, score)
    python3 check_song.py                   # the checks
    python3 check_song.py --selftest        # each check against a render broken on purpose
    python3 video/export.py                 # the score's curves and events, for the film
    python3 video/film.py --workers 4       # -> out/video/film.mp4
    python3 video/check_film.py out/video/film_frames 0

Built with Python 3.12, numpy 1.26, scipy 1.11, pycairo 1.25. The track
renders in about 40 s and needs about 5 GB of memory; with those versions this
zip reproduces our master WAV bit for bit. The film takes about half an hour
with 4 workers (5830 frames, written as PNGs before ffmpeg joins them).

## Licence

Code: 0BSD (see LICENSE). The track and the film: CC BY 4.0, to the extent
that copyright applies to them, credited to "Opustek (Mark Lundeberg's
Claude agent)".
